
<?php


session_start();

require_once __DIR__ . '/config/database.php';

/*
|--------------------------------------------------------------------------
| Helper: safe HTML output
|--------------------------------------------------------------------------
*/
function registerEscape(mixed $value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Redirect authenticated users
|--------------------------------------------------------------------------
*/
if (isset($_SESSION['user_id'], $_SESSION['role'])) {
    $currentRole = strtolower(
        trim((string) $_SESSION['role'])
    );

    if ($currentRole === 'student') {
        header('Location: student/dashboard.php');
        exit;
    }

    if ($currentRole === 'company') {
        header('Location: company/dashboard.php');
        exit;
    }
}

/*
|--------------------------------------------------------------------------
| CSRF token
|--------------------------------------------------------------------------
*/
if (empty($_SESSION['register_csrf_token'])) {
    $_SESSION['register_csrf_token'] = bin2hex(
        random_bytes(32)
    );
}

/*
|--------------------------------------------------------------------------
| Form defaults
|--------------------------------------------------------------------------
*/
$errors = [];
$success = '';

$name = '';
$email = '';
$role = 'student';

$phone = '';
$college = '';
$course = '';
$skills = '';

$companyName = '';
$companyDescription = '';
$website = '';
$location = '';

/*
|--------------------------------------------------------------------------
| Process registration
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim((string) ($_POST['name'] ?? ''));
    $email = strtolower(
        trim((string) ($_POST['email'] ?? ''))
    );

    $role = strtolower(
        trim((string) ($_POST['role'] ?? 'student'))
    );

    $password = (string) ($_POST['password'] ?? '');
    $confirmPassword = (string) (
        $_POST['confirm_password'] ?? ''
    );

    $phone = trim((string) ($_POST['phone'] ?? ''));
    $college = trim((string) ($_POST['college'] ?? ''));
    $course = trim((string) ($_POST['course'] ?? ''));
    $skills = trim((string) ($_POST['skills'] ?? ''));

    $companyName = trim(
        (string) ($_POST['company_name'] ?? '')
    );

    $companyDescription = trim(
        (string) ($_POST['company_description'] ?? '')
    );

    $website = trim(
        (string) ($_POST['website'] ?? '')
    );

    $location = trim(
        (string) ($_POST['location'] ?? '')
    );

    $postedToken = $_POST['csrf_token'] ?? '';

    /*
    |--------------------------------------------------------------------------
    | Validate CSRF token
    |--------------------------------------------------------------------------
    */
    if (
        !is_string($postedToken) ||
        !isset($_SESSION['register_csrf_token']) ||
        !hash_equals(
            $_SESSION['register_csrf_token'],
            $postedToken
        )
    ) {
        $errors[] =
            'Your session expired. Refresh the page and try again.';
    }

    /*
    |--------------------------------------------------------------------------
    | Validate common fields
    |--------------------------------------------------------------------------
    */
    if (
        $name === '' ||
        strlen($name) > 100 ||
        !preg_match('/^.{2,100}$/us', $name)
    ) {
        $errors[] =
            'Enter a name between 2 and 100 characters.';
    }

    if (
        $email === '' ||
        !filter_var($email, FILTER_VALIDATE_EMAIL) ||
        strlen($email) > 150
    ) {
        $errors[] = 'Enter a valid email address.';
    }

    if (!in_array($role, ['student', 'company'], true)) {
        $errors[] = 'Select a valid account type.';
    }

    if (
        strlen($password) < 8 ||
        strlen($password) > 72
    ) {
        $errors[] =
            'Password must contain between 8 and 72 characters.';
    } elseif (
        !preg_match('/[A-Z]/', $password) ||
        !preg_match('/[a-z]/', $password) ||
        !preg_match('/[0-9]/', $password)
    ) {
        $errors[] =
            'Password must contain an uppercase letter, a lowercase letter, and a number.';
    }

    if ($password !== $confirmPassword) {
        $errors[] = 'Passwords do not match.';
    }

    /*
    |--------------------------------------------------------------------------
    | Validate student fields
    |--------------------------------------------------------------------------
    */
    if ($role === 'student') {
        if (strlen($phone) > 20) {
            $errors[] =
                'Phone number cannot exceed 20 characters.';
        }

        if (strlen($college) > 150) {
            $errors[] =
                'College name cannot exceed 150 characters.';
        }

        if (strlen($course) > 100) {
            $errors[] =
                'Course cannot exceed 100 characters.';
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Validate company fields
    |--------------------------------------------------------------------------
    */
    if ($role === 'company') {
        if (
            $companyName === '' ||
            strlen($companyName) > 150
        ) {
            $errors[] =
                'Company name is required and must not exceed 150 characters.';
        }

        if (strlen($location) > 150) {
            $errors[] =
                'Company location cannot exceed 150 characters.';
        }

        if (strlen($website) > 255) {
            $errors[] =
                'Website URL cannot exceed 255 characters.';
        } elseif (
            $website !== '' &&
            (
                !filter_var($website, FILTER_VALIDATE_URL) ||
                !preg_match('/^https?:\/\//i', $website)
            )
        ) {
            $errors[] =
                'Enter a valid website URL starting with https:// or http://.';
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Create account
    |--------------------------------------------------------------------------
    */
    if (empty($errors)) {
        try {
            /*
            | Check duplicate email first.
            */
            $check = $pdo->prepare(
                'SELECT id
                 FROM users
                 WHERE email = :email
                 LIMIT 1'
            );

            $check->execute([
                'email' => $email
            ]);

            if ($check->fetch(PDO::FETCH_ASSOC)) {
                $errors[] =
                    'An account with this email already exists.';
            } else {
                $pdo->beginTransaction();

                /*
                | Passwords must be stored as secure hashes.
                */
                $passwordHash = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                if ($passwordHash === false) {
                    throw new RuntimeException(
                        'Password hashing failed.'
                    );
                }

                /*
                | IMPORTANT:
                | The database role ENUM uses Student and Company.
                */
                $databaseRole = (
                    $role === 'company'
                ) ? 'Company' : 'Student';

                $userStmt = $pdo->prepare(
                    'INSERT INTO users
                        (name, email, password, role)
                     VALUES
                        (:name, :email, :password, :role)'
                );

                $userStmt->execute([
                    'name' => $name,
                    'email' => $email,
                    'password' => $passwordHash,
                    'role' => $databaseRole
                ]);

                $userId = (int) $pdo->lastInsertId();

                /*
                | Create the matching student or company profile.
                */
                if ($role === 'student') {
                    $profileStmt = $pdo->prepare(
                        'INSERT INTO students
                            (user_id, phone, college, course, skills)
                         VALUES
                            (:user_id, :phone, :college, :course, :skills)'
                    );

                    $profileStmt->execute([
                        'user_id' => $userId,
                        'phone' => $phone !== '' ? $phone : null,
                        'college' => $college !== '' ? $college : null,
                        'course' => $course !== '' ? $course : null,
                        'skills' => $skills !== '' ? $skills : null
                    ]);
                } else {
                    $profileStmt = $pdo->prepare(
                        'INSERT INTO companies
                            (
                                user_id,
                                company_name,
                                company_description,
                                website,
                                location
                            )
                         VALUES
                            (
                                :user_id,
                                :company_name,
                                :company_description,
                                :website,
                                :location
                            )'
                    );

                    $profileStmt->execute([
                        'user_id' => $userId,
                        'company_name' => $companyName,
                        'company_description' =>
                            $companyDescription !== ''
                                ? $companyDescription
                                : null,
                        'website' =>
                            $website !== ''
                                ? $website
                                : null,
                        'location' =>
                            $location !== ''
                                ? $location
                                : null
                    ]);
                }

                $pdo->commit();

                /*
                | Rotate the registration CSRF token after success.
                */
                $_SESSION['register_csrf_token'] = bin2hex(
                    random_bytes(32)
                );

                $success =
                    'Account created successfully. You can now log in.';

                /*
                | Clear the sensitive and personal form data.
                */
                $name = '';
                $email = '';
                $role = 'student';

                $phone = '';
                $college = '';
                $course = '';
                $skills = '';

                $companyName = '';
                $companyDescription = '';
                $website = '';
                $location = '';
            }
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log(
                'Registration error: ' .
                $exception->getMessage()
            );

            $errors[] =
                'Registration could not be completed. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta name="theme-color" content="#070b14">

    <title>Create Account | Internship Portal</title>

    <link
        rel="stylesheet"
        href="css/style.css?v=20261010"
    >
    <link rel="stylesheet" href="css/neon-glass.css?v=4">

    <style>
        html,
        body {
            min-height: 100%;
            margin: 0;
        }

        body.register-page {
            min-height: 100vh;
            overflow-x: hidden;

            color: #f5f8ff;

            background:
                radial-gradient(
                    ellipse at 12% 12%,
                    rgba(30, 125, 255, 0.17),
                    transparent 38%
                ),
                radial-gradient(
                    ellipse at 88% 88%,
                    rgba(255, 49, 151, 0.12),
                    transparent 36%
                ),
                #050914;
        }

        .register-wrapper {
            min-height: 100vh;
            box-sizing: border-box;

            display: flex;
            justify-content: center;
            align-items: center;

            padding: 32px 18px;
        }

        .register-container {
            width: min(100%, 740px);
            margin: 0 auto;
        }

        .register-intro {
            margin-bottom: 24px;
            text-align: center;
        }

        .register-brand {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;

            margin-bottom: 25px;

            color: #f5f8ff;
            font-size: 16px;
            font-weight: 850;
            letter-spacing: 0.5px;
            text-decoration: none;
        }

        .register-brand-mark {
            width: 42px;
            height: 42px;

            display: grid;
            place-items: center;

            border-radius: 12px;

            color: #fff;
            background: linear-gradient(
                135deg,
                #218fff,
                #7555ff,
                #ff398a
            );

            box-shadow:
                0 0 20px rgba(66, 186, 255, 0.20);
        }

        .register-kicker {
            margin: 0 0 10px;

            color: #8bdcff;
            font-size: 11px;
            font-weight: 850;
            letter-spacing: 2px;
            text-transform: uppercase;
        }

        .register-intro h1 {
            margin: 0;

            color: #f5f8ff;
            font-size: clamp(32px, 6vw, 48px);
            font-weight: 900;
            letter-spacing: -1.8px;
            line-height: 1.08;
        }

        .register-intro p {
            max-width: 510px;
            margin: 13px auto 0;

            color: #aebed8;
            font-size: 13px;
            line-height: 1.8;
        }

        .register-card {
            position: relative;
            overflow: hidden;

            width: 100%;
            box-sizing: border-box;
            padding: clamp(20px, 4vw, 34px);

            border: 1px solid rgba(66, 156, 255, 0.38);
            border-radius: 22px;

            background: linear-gradient(
                145deg,
                rgba(15, 27, 52, 0.96),
                rgba(7, 11, 25, 0.98)
            );

            box-shadow:
                0 0 35px rgba(0, 100, 255, 0.10),
                0 0 70px rgba(255, 35, 120, 0.06),
                0 24px 75px rgba(0, 0, 0, 0.30);

            animation: registerFadeUp 0.5s ease both;
        }

        .register-card::before {
            content: "";

            position: absolute;
            top: 0;
            left: 0;
            right: 0;

            height: 3px;

            background: linear-gradient(
                90deg,
                #2b8cff,
                #7655ff,
                #ff398a,
                #2b8cff
            );

            background-size: 250% 100%;
            animation: registerLine 5s linear infinite;
        }

        @keyframes registerLine {
            from {
                background-position: 0% 50%;
            }

            to {
                background-position: 250% 50%;
            }
        }

        @keyframes registerFadeUp {
            from {
                opacity: 0;
                transform: translateY(12px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .register-header {
            margin-bottom: 26px;
            text-align: center;
        }

        .register-header h2 {
            margin: 0;

            color: #f5f8ff;
            font-size: clamp(25px, 4vw, 32px);
            font-weight: 850;
            letter-spacing: -0.5px;
        }

        .register-header p {
            margin: 9px 0 0;

            color: #aebed8;
            font-size: 13px;
            line-height: 1.7;
        }

        .register-message {
            margin-bottom: 20px;
            padding: 13px 15px;

            border-radius: 11px;
            font-size: 13px;
            line-height: 1.65;
        }

        .register-message ul {
            margin: 0;
            padding-left: 19px;
        }

        .register-error {
            color: #ffb1c0;
            background: rgba(255, 40, 80, 0.08);
            border: 1px solid rgba(255, 55, 90, 0.30);
        }

        .register-success {
            color: #77f4bd;
            background: rgba(72, 240, 179, 0.08);
            border: 1px solid rgba(72, 240, 179, 0.28);
        }

        .register-form {
            width: 100%;
        }

        .register-field {
            min-width: 0;
            margin-bottom: 18px;
        }

        .register-field label {
            display: block;
            margin-bottom: 8px;

            color: #e1eaff;
            font-size: 12px;
            font-weight: 750;
        }

        .register-field input,
        .register-field select,
        .register-field textarea {
            display: block;

            width: 100%;
            min-height: 50px;
            box-sizing: border-box;
            padding: 12px 14px;

            color: #f5f8ff;
            background: rgba(7, 15, 33, 0.94);

            border: 1px solid rgba(95, 140, 195, 0.27);
            border-radius: 11px;

            outline: none;
            font: inherit;
            font-size: 13px;

            transition:
                border-color 0.2s ease,
                box-shadow 0.2s ease;
        }

        .register-field textarea {
            min-height: 100px;
            resize: vertical;
            line-height: 1.6;
        }

        .register-field input::placeholder,
        .register-field textarea::placeholder {
            color: rgba(190, 201, 225, 0.48);
        }

        .register-field select option {
            color: #f5f8ff;
            background: #0a1224;
        }

        .register-field input:focus,
        .register-field select:focus,
        .register-field textarea:focus {
            border-color: rgba(66, 186, 255, 0.88);

            box-shadow:
                0 0 0 3px rgba(45, 137, 255, 0.10),
                0 0 22px rgba(45, 137, 255, 0.10);
        }

        .register-field .input-error {
            border-color: #ff648d;
        }

        /* Password controls — JS is provided by validation.js. */

        .password-wrap {
            position: relative;
            width: 100%;
        }

        .password-wrap input {
            padding-right: 80px;
        }

        .password-toggle {
            position: absolute;
            top: 50%;
            right: 9px;
            transform: translateY(-50%);

            min-width: 50px;
            padding: 8px 9px;

            color: #8bdcff;
            background: rgba(66, 186, 255, 0.08);

            border: 1px solid rgba(66, 186, 255, 0.19);
            border-radius: 8px;

            font-size: 11px;
            font-weight: 850;

            cursor: pointer;

            transition:
                color 0.2s ease,
                background 0.2s ease,
                border-color 0.2s ease;
        }

        .password-toggle:hover {
            color: #fff;
            background: rgba(66, 186, 255, 0.18);
            border-color: rgba(66, 186, 255, 0.55);
        }

        .password-toggle:active {
            transform: translateY(-50%) scale(0.96);
        }

        .register-section {
            margin-top: 25px;
            padding: 18px;

            border: 1px solid rgba(84, 157, 255, 0.16);
            border-radius: 15px;

            background: rgba(5, 11, 23, 0.38);
        }

        .register-section-title {
            margin: 0 0 18px;

            color: #8bdcff;
            font-size: 11px;
            font-weight: 850;
            letter-spacing: 1.3px;
            text-transform: uppercase;
        }

        .register-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 0 14px;
        }

        .register-grid .register-field {
            min-width: 0;
        }

        .register-submit {
            width: 100%;
            min-height: 52px;
            margin-top: 22px;
            padding: 13px 18px;

            color: #fff;

            border: 1px solid rgba(126, 194, 255, 0.30);
            border-radius: 12px;

            background: linear-gradient(
                100deg,
                #176fff,
                #6550ff,
                #e82f82
            );

            background-size: 200% 100%;

            box-shadow:
                0 8px 25px rgba(40, 100, 255, 0.18),
                0 0 20px rgba(235, 45, 120, 0.08);

            font: inherit;
            font-size: 14px;
            font-weight: 850;

            cursor: pointer;

            transition:
                transform 0.2s ease,
                box-shadow 0.2s ease,
                background-position 0.4s ease;
        }

        .register-submit:hover {
            transform: translateY(-2px);
            background-position: 100% 50%;

            box-shadow:
                0 12px 30px rgba(40, 100, 255, 0.25),
                0 0 25px rgba(235, 45, 120, 0.15);
        }

        .register-submit:active {
            transform: scale(0.98);
        }

        .register-submit:disabled {
            opacity: 0.7;
            cursor: wait;
            transform: none;
        }

        .register-bottom {
            margin-top: 24px;
            text-align: center;
        }

        .register-bottom p {
            margin: 0;

            color: #aebed8;
            font-size: 13px;
            line-height: 1.9;
        }

        .register-bottom a {
            color: #8bdcff;
            font-weight: 800;
            text-decoration: none;
        }

        .register-bottom a:hover {
            color: #ff86c2;
        }

        .register-home {
            display: block;
            margin-top: 17px;

            color: #aebed8;
            text-align: center;
            text-decoration: none;
            font-size: 12px;
        }

        .register-home:hover {
            color: #fff;
        }

        a:focus-visible,
        button:focus-visible,
        input:focus-visible,
        select:focus-visible,
        textarea:focus-visible {
            outline: 2px solid #8bdcff;
            outline-offset: 3px;
        }

        @media (max-width: 560px) {
            .register-wrapper {
                padding: 20px 12px;
                align-items: flex-start;
            }

            .register-card {
                padding: 24px 17px;
                border-radius: 18px;
            }

            .register-grid {
                grid-template-columns: 1fr;
            }

            .register-section {
                padding: 14px;
            }

            .register-intro h1 {
                letter-spacing: -1px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: 0.01ms !important;
                transition-duration: 0.01ms !important;
            }
        }
    </style>
</head>

<body class="register-page">

<div class="register-wrapper">

    <main class="register-container">

        <header class="register-intro">

            <a href="index.php" class="register-brand">
                <span class="register-brand-mark">IP</span>
                <span>INTERNSHIP PORTAL</span>
            </a>

            <p class="register-kicker">
                Start Your Journey
            </p>

            <h1>Create Your Account</h1>

            <p>
                Join the portal to explore opportunities, build your profile,
                or connect your company with talented students.
            </p>

        </header>

        <section class="register-card">

            <div class="register-header">
                <h2>Join the Portal</h2>
                <p>
                    Enter your details below to create an account.
                </p>
            </div>

            <?php if (!empty($errors)): ?>

                <div class="register-message register-error" role="alert">
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?= registerEscape($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>

            <?php endif; ?>

            <?php if ($success !== ''): ?>

                <div class="register-message register-success" role="status">
                    <?= registerEscape($success) ?>

                    <div style="margin-top: 10px;">
                        <a
                            href="login.php"
                            style="color: #8bdcff; font-weight: 800;"
                        >
                            Go to Login
                        </a>
                    </div>
                </div>

            <?php endif; ?>

            <form
                method="POST"
                action="register.php"
                class="register-form"
                id="registerForm"
                data-validate
            >

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= registerEscape(
                        $_SESSION['register_csrf_token']
                    ) ?>"
                >

                <!-- Basic information -->

                <div class="register-field">

                    <label for="name">Full Name</label>

                    <input
                        type="text"
                        id="name"
                        name="name"
                        value="<?= registerEscape($name) ?>"
                        placeholder="Enter your full name"
                        autocomplete="name"
                        maxlength="100"
                        required
                    >

                </div>

                <div class="register-field">

                    <label for="email">Email Address</label>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        value="<?= registerEscape($email) ?>"
                        placeholder="Enter your email address"
                        autocomplete="email"
                        maxlength="150"
                        required
                    >

                </div>

                <div class="register-field">

                    <label for="role">Account Type</label>

                    <select
                        id="role"
                        name="role"
                        required
                    >

                        <option
                            value="student"
                            <?= $role === 'student' ? 'selected' : '' ?>
                        >
                            Student
                        </option>

                        <option
                            value="company"
                            <?= $role === 'company' ? 'selected' : '' ?>
                        >
                            Company
                        </option>

                    </select>

                </div>

                <!-- Password -->

                <div class="register-field">

                    <label for="password">Password</label>

                    <div class="password-wrap">

                        <input
                            type="password"
                            id="password"
                            name="password"
                            placeholder="At least 8 characters"
                            autocomplete="new-password"
                            minlength="8"
                            maxlength="72"
                            required
                        >

                        <button
                            type="button"
                            class="password-toggle"
                            data-password-toggle="password"
                            aria-controls="password"
                            aria-label="Show password"
                        >
                            Show
                        </button>

                    </div>

                    <small style="
                        display:block;
                        margin-top:8px;
                        color:#879bb9;
                        font-size:11px;
                        line-height:1.7;
                    ">
                        Use uppercase and lowercase letters and at least one number.
                    </small>

                </div>

                <!-- Confirm password -->

                <div class="register-field">

                    <label for="confirm_password">
                        Confirm Password
                    </label>

                    <div class="password-wrap">

                        <input
                            type="password"
                            id="confirm_password"
                            name="confirm_password"
                            placeholder="Enter the same password again"
                            autocomplete="new-password"
                            minlength="8"
                            maxlength="72"
                            required
                        >

                        <button
                            type="button"
                            class="password-toggle"
                            data-password-toggle="confirm_password"
                            aria-controls="confirm_password"
                            aria-label="Show confirmation password"
                        >
                            Show
                        </button>

                    </div>

                </div>

                <!-- Student information -->

                <section
                    id="studentFields"
                    class="register-section"
                >

                    <p class="register-section-title">
                        Student Information
                    </p>

                    <div class="register-grid">

                        <div class="register-field">

                            <label for="phone">Phone</label>

                            <input
                                type="tel"
                                id="phone"
                                name="phone"
                                value="<?= registerEscape($phone) ?>"
                                placeholder="Phone number"
                                maxlength="20"
                                autocomplete="tel"
                            >

                        </div>

                        <div class="register-field">

                            <label for="college">College</label>

                            <input
                                type="text"
                                id="college"
                                name="college"
                                value="<?= registerEscape($college) ?>"
                                placeholder="College name"
                                maxlength="150"
                            >

                        </div>

                        <div class="register-field">

                            <label for="course">Course</label>

                            <input
                                type="text"
                                id="course"
                                name="course"
                                value="<?= registerEscape($course) ?>"
                                placeholder="B.E. CSE"
                                maxlength="100"
                            >

                        </div>

                        <div class="register-field">

                            <label for="skills">Skills</label>

                            <input
                                type="text"
                                id="skills"
                                name="skills"
                                value="<?= registerEscape($skills) ?>"
                                placeholder="PHP, MySQL, Java"
                            >

                        </div>

                    </div>

                </section>

                <!-- Company information -->

                <section
                    id="companyFields"
                    class="register-section"
                    hidden
                >

                    <p class="register-section-title">
                        Company Information
                    </p>

                    <div class="register-field">

                        <label for="company_name">
                            Company Name
                        </label>

                        <input
                            type="text"
                            id="company_name"
                            name="company_name"
                            value="<?= registerEscape($companyName) ?>"
                            placeholder="Enter company name"
                            maxlength="150"
                        >

                    </div>

                    <div class="register-field">

                        <label for="location">Company Location</label>

                        <input
                            type="text"
                            id="location"
                            name="location"
                            value="<?= registerEscape($location) ?>"
                            placeholder="City or office location"
                            maxlength="150"
                        >

                    </div>

                    <div class="register-field">

                        <label for="website">Company Website</label>

                        <input
                            type="url"
                            id="website"
                            name="website"
                            value="<?= registerEscape($website) ?>"
                            placeholder="https://example.com"
                            maxlength="255"
                        >

                    </div>

                    <div class="register-field">

                        <label for="company_description">
                            Company Description
                        </label>

                        <textarea
                            id="company_description"
                            name="company_description"
                            placeholder="Briefly describe your company"
                        ><?= registerEscape($companyDescription) ?></textarea>

                    </div>

                </section>

                <button
                    type="submit"
                    class="register-submit"
                >
                    Create Account
                </button>

                <div class="register-bottom">
                    <p>
                        Already have an account?
                        <a href="login.php">Login</a>
                    </p>
                </div>

                <a href="index.php" class="register-home">
                    &larr; Back to Home
                </a>

            </form>

        </section>

    </main>

</div>

<!-- One password-toggle implementation only: validation.js -->
<script src="js/validation.js?v=4"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const roleSelect = document.getElementById('role');
    const studentFields = document.getElementById('studentFields');
    const companyFields = document.getElementById('companyFields');
    const companyName = document.getElementById('company_name');

    function updateAccountFields() {
        const isCompany = roleSelect.value === 'company';

        studentFields.hidden = isCompany;
        companyFields.hidden = !isCompany;

        if (companyName) {
            companyName.required = isCompany;
        }
    }

    roleSelect.addEventListener('change', updateAccountFields);
    updateAccountFields();

    /*
     * Validate password confirmation before submitting.
     * Password visibility is deliberately handled only by validation.js.
     */
    const form = document.getElementById('registerForm');
    const password = document.getElementById('password');
    const confirmPassword = document.getElementById('confirm_password');

    if (form && password && confirmPassword) {
        form.addEventListener('submit', function (event) {
            if (password.value !== confirmPassword.value) {
                event.preventDefault();

                confirmPassword.setCustomValidity(
                    'Passwords do not match.'
                );

                confirmPassword.reportValidity();
                confirmPassword.focus();
            } else {
                confirmPassword.setCustomValidity('');
            }
        });

        confirmPassword.addEventListener('input', function () {
            confirmPassword.setCustomValidity('');
        });
    }
});
</script>

</body>
</html>
