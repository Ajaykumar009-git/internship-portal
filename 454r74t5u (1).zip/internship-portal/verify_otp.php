
<?php

session_start();

require_once __DIR__ . '/config/database.php';

/*
|--------------------------------------------------------------------------
| Helper: escape output
|--------------------------------------------------------------------------
*/
function verifyOtpEscape(mixed $value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Check password-reset session
|--------------------------------------------------------------------------
*/
if (
    !isset($_SESSION['reset_user_id'], $_SESSION['reset_email'])
) {
    header('Location: forgot_password.php');
    exit;
}

$userId = (int) $_SESSION['reset_user_id'];
$email = (string) $_SESSION['reset_email'];

/*
|--------------------------------------------------------------------------
| CSRF token
|--------------------------------------------------------------------------
*/
if (empty($_SESSION['verify_otp_csrf'])) {
    $_SESSION['verify_otp_csrf'] = bin2hex(
        random_bytes(32)
    );
}

$message = '';
$messageType = '';
$otp = '';

/*
|--------------------------------------------------------------------------
| Process OTP verification
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $otp = trim((string) ($_POST['otp'] ?? ''));
    $postedToken = $_POST['csrf_token'] ?? '';

    if (
        !is_string($postedToken) ||
        !isset($_SESSION['verify_otp_csrf']) ||
        !hash_equals(
            $_SESSION['verify_otp_csrf'],
            $postedToken
        )
    ) {
        $message =
            'Your session expired. Refresh the page and try again.';
        $messageType = 'error';
    } elseif (!preg_match('/^\d{6}$/', $otp)) {
        $message = 'Please enter a valid six-digit OTP.';
        $messageType = 'error';
    } else {
        try {
            /*
            |--------------------------------------------------------------------------
            | Find latest OTP record
            |--------------------------------------------------------------------------
            */
            $stmt = $pdo->prepare(
                'SELECT id, otp, expires_at, verified
                 FROM password_resets
                 WHERE user_id = :user_id
                 ORDER BY id DESC
                 LIMIT 1'
            );

            $stmt->execute([
                'user_id' => $userId
            ]);

            $reset = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$reset) {
                $message =
                    'OTP not found. Please request a new OTP.';
                $messageType = 'error';

            } elseif ((int) $reset['verified'] === 1) {
                $message =
                    'This OTP has already been used. Request a new one if needed.';
                $messageType = 'error';

            } else {
                $expiryTime = strtotime(
                    (string) $reset['expires_at']
                );

                if (
                    $expiryTime === false ||
                    $expiryTime <= time()
                ) {
                    $message =
                        'Your OTP has expired. Please request a new OTP.';
                    $messageType = 'error';

                    $delete = $pdo->prepare(
                        'DELETE FROM password_resets
                         WHERE id = :id'
                    );

                    $delete->execute([
                        'id' => (int) $reset['id']
                    ]);

                } elseif (
                    !password_verify(
                        $otp,
                        (string) $reset['otp']
                    )
                ) {
                    /*
                    |--------------------------------------------------------------------------
                    | Limit guesses within the current session
                    |--------------------------------------------------------------------------
                    */
                    $resetId = (int) $reset['id'];

                    if (
                        (int) (
                            $_SESSION['otp_attempt_reset_id'] ?? 0
                        ) !== $resetId
                    ) {
                        $_SESSION['otp_attempt_reset_id'] = $resetId;
                        $_SESSION['otp_failed_attempts'] = 0;
                    }

                    $_SESSION['otp_failed_attempts'] =
                        (int) (
                            $_SESSION['otp_failed_attempts'] ?? 0
                        ) + 1;

                    if ($_SESSION['otp_failed_attempts'] >= 5) {
                        $delete = $pdo->prepare(
                            'DELETE FROM password_resets
                             WHERE id = :id'
                        );

                        $delete->execute([
                            'id' => $resetId
                        ]);

                        unset(
                            $_SESSION['reset_id'],
                            $_SESSION['otp_verified'],
                            $_SESSION['otp_failed_attempts'],
                            $_SESSION['otp_attempt_reset_id']
                        );

                        $message =
                            'Too many incorrect attempts. Please request a new OTP.';
                    } else {
                        $remaining = 5 -
                            (int) $_SESSION['otp_failed_attempts'];

                        $message =
                            "Invalid OTP. You have {$remaining} attempt(s) remaining.";
                    }

                    $messageType = 'error';

                } else {
                    /*
                    |--------------------------------------------------------------------------
                    | Mark OTP as verified
                    |--------------------------------------------------------------------------
                    */
                    $update = $pdo->prepare(
                        'UPDATE password_resets
                         SET verified = 1
                         WHERE id = :id
                           AND user_id = :user_id
                           AND verified = 0'
                    );

                    $update->execute([
                        'id' => (int) $reset['id'],
                        'user_id' => $userId
                    ]);

                    if ($update->rowCount() !== 1) {
                        $message =
                            'This OTP could not be verified. Please request a new one.';
                        $messageType = 'error';
                    } else {
                        /*
                        |--------------------------------------------------------------------------
                        | Prepare the password-reset session
                        |--------------------------------------------------------------------------
                        */
                        session_regenerate_id(true);

                        $_SESSION['otp_verified'] = true;
                        $_SESSION['reset_id'] = (int) $reset['id'];

                        unset(
                            $_SESSION['otp_failed_attempts'],
                            $_SESSION['otp_attempt_reset_id'],
                            $_SESSION['verify_otp_csrf']
                        );

                        header('Location: reset_password.php');
                        exit;
                    }
                }
            }
        } catch (Throwable $exception) {
            error_log(
                'OTP verification error: ' .
                $exception->getMessage()
            );

            $message =
                'Unable to verify the OTP right now. Please try again.';
            $messageType = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta name="theme-color" content="#070b14">

    <title>Verify OTP | Internship Portal</title>

    <link
        rel="stylesheet"
        href="css/style.css?v=20261010"
    >
    <link rel="stylesheet" href="css/neon-glass.css?v=4">

    <style>
        body.verify-page {
            min-height: 100vh;
            margin: 0;
            color: #f5f8ff;

            background:
                radial-gradient(
                    ellipse at 12% 12%,
                    rgba(30, 125, 255, 0.18),
                    transparent 38%
                ),
                radial-gradient(
                    ellipse at 88% 88%,
                    rgba(255, 49, 151, 0.12),
                    transparent 36%
                ),
                #050914;
        }

        .verify-wrapper {
            min-height: 100vh;
            display: grid;
            place-items: center;
            box-sizing: border-box;
            padding: 24px 16px;
        }

        .verify-card {
            position: relative;
            overflow: hidden;

            width: min(100%, 460px);
            box-sizing: border-box;
            padding: 32px;

            border: 1px solid rgba(66, 156, 255, 0.38);
            border-radius: 22px;

            background: linear-gradient(
                145deg,
                rgba(15, 27, 52, 0.97),
                rgba(7, 11, 25, 0.98)
            );

            box-shadow:
                0 0 35px rgba(0, 100, 255, 0.10),
                0 0 70px rgba(255, 35, 120, 0.06),
                0 24px 75px rgba(0, 0, 0, 0.35);
        }

        .verify-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;

            background: linear-gradient(
                90deg,
                #2b8cff,
                #7655ff,
                #ff398a
            );
        }

        .verify-brand {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-bottom: 28px;

            color: #f5f8ff;
            font-weight: 850;
            text-decoration: none;
        }

        .verify-brand-mark {
            display: grid;
            place-items: center;
            width: 42px;
            height: 42px;
            border-radius: 12px;

            color: #fff;
            background: linear-gradient(
                135deg,
                #218fff,
                #7555ff,
                #ff398a
            );
        }

        .verify-heading {
            margin: 0;

            color: #f5f8ff;
            text-align: center;
            font-size: clamp(28px, 5vw, 36px);
            font-weight: 900;
            letter-spacing: -1px;
        }

        .verify-description {
            margin: 14px 0 8px;

            color: #aebed8;
            text-align: center;
            font-size: 13px;
            line-height: 1.8;
        }

        .verify-email {
            display: block;
            margin-bottom: 24px;

            color: #8bdcff;
            text-align: center;
            font-size: 13px;
            overflow-wrap: anywhere;
        }

        .verify-message {
            margin-bottom: 20px;
            padding: 13px 15px;

            border-radius: 11px;
            font-size: 13px;
            line-height: 1.7;
        }

        .verify-message.error {
            color: #ffb1c0;
            background: rgba(255, 40, 80, 0.08);
            border: 1px solid rgba(255, 55, 90, 0.30);
        }

        .verify-field {
            margin-bottom: 20px;
        }

        .verify-field label {
            display: block;
            margin-bottom: 9px;

            color: #e1eaff;
            font-size: 13px;
            font-weight: 750;
        }

        .verify-field input {
            display: block;
            width: 100%;
            min-height: 58px;
            box-sizing: border-box;
            padding: 13px 15px;

            color: #ffffff;
            background: rgba(7, 15, 33, 0.94);

            border: 1px solid rgba(95, 140, 195, 0.30);
            border-radius: 11px;
            outline: none;

            font: inherit;
            font-size: 24px;
            font-weight: 800;
            letter-spacing: 10px;
            text-align: center;

            transition:
                border-color 0.2s ease,
                box-shadow 0.2s ease;
        }

        .verify-field input:focus {
            border-color: rgba(66, 186, 255, 0.88);
            box-shadow: 0 0 0 3px rgba(45, 137, 255, 0.10);
        }

        .verify-submit {
            width: 100%;
            min-height: 52px;
            padding: 13px 18px;

            color: #ffffff;
            font: inherit;
            font-weight: 850;

            border: 1px solid rgba(126, 194, 255, 0.30);
            border-radius: 12px;

            background: linear-gradient(
                100deg,
                #176fff,
                #6550ff,
                #e82f82
            );

            cursor: pointer;

            transition:
                transform 0.2s ease,
                box-shadow 0.2s ease;
        }

        .verify-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(40, 100, 255, 0.23);
        }

        .verify-submit:active {
            transform: scale(0.98);
        }

        .verify-links {
            margin-top: 24px;
            text-align: center;
        }

        .verify-links p {
            margin: 12px 0 0;
            color: #aebed8;
            font-size: 12px;
        }

        .verify-links a {
            color: #8bdcff;
            font-weight: 750;
            text-decoration: none;
        }

        .verify-links a:hover {
            color: #ff86c2;
        }

        a:focus-visible,
        button:focus-visible,
        input:focus-visible {
            outline: 2px solid #8bdcff;
            outline-offset: 3px;
        }

        @media (max-width: 500px) {
            .verify-card {
                padding: 25px 19px;
                border-radius: 18px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: 0.01ms !important;
                transition-duration: 0.01ms !important;
            }
        }
    </style>
</head>

<body class="verify-page">

<main class="verify-wrapper">

    <section class="verify-card">

        <a href="index.php" class="verify-brand">
            <span class="verify-brand-mark">IP</span>
            <span>INTERNSHIP PORTAL</span>
        </a>

        <h1 class="verify-heading">Verify OTP</h1>

        <p class="verify-description">
            Enter the six-digit code sent to your registered email address.
            The code expires after ten minutes.
        </p>

        <strong class="verify-email">
            <?= verifyOtpEscape($email) ?>
        </strong>

        <?php if ($message !== ''): ?>

            <div
                class="verify-message error"
                role="alert"
            >
                <?= verifyOtpEscape($message) ?>
            </div>

        <?php endif; ?>

        <form
            method="POST"
            action="verify_otp.php"
            id="verifyOtpForm"
        >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= verifyOtpEscape(
                    $_SESSION['verify_otp_csrf']
                ) ?>"
            >

            <div class="verify-field">

                <label for="otp">
                    Six-digit OTP
                </label>

                <input
                    type="text"
                    id="otp"
                    name="otp"
                    inputmode="numeric"
                    autocomplete="one-time-code"
                    maxlength="6"
                    pattern="[0-9]{6}"
                    placeholder="000000"
                    value="<?= verifyOtpEscape($otp) ?>"
                    aria-describedby="otpHelp"
                    required
                    autofocus
                >

                <small
                    id="otpHelp"
                    style="
                        display:block;
                        margin-top:9px;
                        color:#879bb9;
                        font-size:11px;
                        line-height:1.7;
                    "
                >
                    Enter the code from your email.
                </small>

            </div>

            <button
                type="submit"
                class="verify-submit"
            >
                Verify OTP
            </button>

        </form>

        <div class="verify-links">

            <p>
                Didn't receive a code?
                <a href="forgot_password.php">Request a new OTP</a>
            </p>

            <p>
                <a href="login.php">Back to Login</a>
            </p>

            <p>
                <a href="index.php">Back to Home</a>
            </p>

        </div>

    </section>

</main>

<script src="js/validation.js?v=4" defer></script>

</body>
</html>
