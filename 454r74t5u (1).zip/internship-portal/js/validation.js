
"use strict";

/* =========================================================
   COLLEGE INTERNSHIP PORTAL
   GLOBAL JAVASCRIPT
   ========================================================= */

document.addEventListener("DOMContentLoaded", function () {
    setupPasswordToggles();
    setupButtonEffects();
    setupFormValidation();
    setupFileValidation();
    setupSubmitProtection();
    setupSmoothLinks();
    setupPageTransitions();
    setupPasswordMatch();
});

/* =========================================================
   SMALL WATER-DROP CLICK EFFECT
   ========================================================= */

function createClickRipple(x, y) {
    const ripple = document.createElement("span");

    ripple.className = "click-bloom";
    ripple.style.left = `${x}px`;
    ripple.style.top = `${y}px`;

    document.body.appendChild(ripple);

    window.setTimeout(function () {
        ripple.remove();
    }, 700);
}

/* Mouse click */

document.addEventListener("click", function (event) {
    createClickRipple(event.clientX, event.clientY);
});

/* Touch */

document.addEventListener(
    "touchstart",
    function (event) {
        if (!event.touches || !event.touches.length) {
            return;
        }

        const touch = event.touches[0];

        createClickRipple(touch.clientX, touch.clientY);
    },
    { passive: true }
);

/* =========================================================
   PASSWORD SHOW / HIDE
   Supports both .password-toggle and data-password-toggle
   ========================================================= */

function setupPasswordToggles() {
    const toggles = document.querySelectorAll(
        ".password-toggle, [data-password-toggle]"
    );

    toggles.forEach(function (toggle) {
        // Prevent duplicate click handlers.
        if (toggle.dataset.passwordToggleInitialized === "true") {
            return;
        }

        toggle.dataset.passwordToggleInitialized = "true";

        let input = null;

        // Preferred: identify the input using its ID.
        const inputId = toggle.getAttribute("data-password-toggle");

        if (inputId) {
            input = document.getElementById(inputId);
        }

        // Fallback: find the input in the surrounding password wrapper.
        if (!input) {
            const wrapper = toggle.closest(".password-wrap");

            if (wrapper) {
                input = wrapper.querySelector("input");
            }
        }

        if (!input) {
            console.warn(
                "Password toggle could not find its input:",
                toggle
            );

            toggle.disabled = true;
            return;
        }

        if (
            input.type !== "password" &&
            input.type !== "text"
        ) {
            console.warn(
                "Password toggle requires a password or text input:",
                input.id
            );

            toggle.disabled = true;
            return;
        }

        function updateToggle() {
            const visible = input.type === "text";

            toggle.textContent = visible ? "Hide" : "Show";

            toggle.setAttribute(
                "aria-label",
                visible ? "Hide password" : "Show password"
            );

            toggle.setAttribute(
                "aria-pressed",
                visible ? "true" : "false"
            );

            if (input.id) {
                toggle.setAttribute("aria-controls", input.id);
            }
        }

        // Initial state.
        updateToggle();

        toggle.addEventListener("click", function (event) {
            event.preventDefault();

            input.type =
                input.type === "password" ? "text" : "password";

            updateToggle();
        });
    });
}

/* =========================================================
   BUTTON PRESS EFFECT
   ========================================================= */

function setupButtonEffects() {
    const buttons = document.querySelectorAll(
        "button, .btn, .nav-button"
    );

    buttons.forEach(function (button) {
        if (button.dataset.buttonEffectsInitialized === "true") {
            return;
        }

        button.dataset.buttonEffectsInitialized = "true";

        button.addEventListener("pointerdown", function () {
            button.classList.add("button-pressed");
        });

        function removePressedState() {
            window.setTimeout(function () {
                button.classList.remove("button-pressed");
            }, 120);
        }

        button.addEventListener("pointerup", removePressedState);
        button.addEventListener("pointercancel", removePressedState);

        button.addEventListener("pointerleave", function () {
            button.classList.remove("button-pressed");
        });
    });
}

/* =========================================================
   BASIC FORM VALIDATION
   ========================================================= */

function setupFormValidation() {
    const forms = document.querySelectorAll("form");

    forms.forEach(function (form) {
        if (form.dataset.validationInitialized === "true") {
            return;
        }

        form.dataset.validationInitialized = "true";

        form.addEventListener("submit", function (event) {
            let valid = true;
            let firstInvalidField = null;

            const requiredFields = form.querySelectorAll("[required]");
            const checkedRadioGroups = new Set();

            requiredFields.forEach(function (field) {
                if (field.disabled) {
                    return;
                }

                // Required checkbox.
                if (field.type === "checkbox") {
                    if (!field.checked) {
                        valid = false;

                        if (!firstInvalidField) {
                            firstInvalidField = field;
                        }

                        field.classList.add("input-error");
                    }

                    return;
                }

                // Required radio group: validate the group only once.
                if (field.type === "radio") {
                    if (checkedRadioGroups.has(field.name)) {
                        return;
                    }

                    checkedRadioGroups.add(field.name);

                    const checked = form.querySelector(
                        'input[type="radio"][name="' +
                        CSS.escape(field.name) +
                        '"]:checked'
                    );

                    if (!checked) {
                        valid = false;

                        if (!firstInvalidField) {
                            firstInvalidField = field;
                        }
                    }

                    return;
                }

                const value = String(field.value ?? "");

                if (!value.trim()) {
                    valid = false;
                    field.classList.add("input-error");

                    if (!firstInvalidField) {
                        firstInvalidField = field;
                    }
                } else {
                    field.classList.remove("input-error");
                }
            });

            if (!valid) {
                event.preventDefault();

                showFormMessage(
                    form,
                    "Please complete all required fields."
                );

                if (firstInvalidField) {
                    firstInvalidField.focus();
                }
            }
        });

        const inputs = form.querySelectorAll(
            "input, textarea, select"
        );

        inputs.forEach(function (input) {
            input.addEventListener("input", function () {
                if (
                    input.type === "checkbox" ||
                    input.type === "radio"
                ) {
                    if (input.checked) {
                        input.classList.remove("input-error");
                    }

                    return;
                }

                if (String(input.value ?? "").trim()) {
                    input.classList.remove("input-error");
                }
            });

            input.addEventListener("change", function () {
                if (
                    input.type === "checkbox" ||
                    input.type === "radio"
                ) {
                    input.classList.remove("input-error");
                }
            });
        });
    });
}

/* =========================================================
   FORM MESSAGE
   ========================================================= */

function showFormMessage(form, message) {
    let box = form.querySelector(".js-form-message");

    if (!box) {
        box = document.createElement("div");

        box.className = "alert alert-error js-form-message";
        box.setAttribute("role", "alert");

        form.prepend(box);
    }

    box.textContent = message;

    box.scrollIntoView({
        behavior: "smooth",
        block: "nearest"
    });
}

/* =========================================================
   FILE UPLOAD VALIDATION
   ========================================================= */

function setupFileValidation() {
    const fileInputs = document.querySelectorAll(
        'input[type="file"]'
    );

    fileInputs.forEach(function (input) {
        if (input.dataset.fileValidationInitialized === "true") {
            return;
        }

        input.dataset.fileValidationInitialized = "true";

        input.addEventListener("change", function () {
            if (!input.files || !input.files.length) {
                return;
            }

            const file = input.files[0];
            const maxSize = 5 * 1024 * 1024;

            const allowedExtensions = [
                "pdf",
                "doc",
                "docx"
            ];

            const parts = file.name.split(".");

            const extension = parts.length > 1
                ? parts.pop().toLowerCase()
                : "";

            if (!allowedExtensions.includes(extension)) {
                input.value = "";

                alert(
                    "Only PDF, DOC and DOCX files are allowed."
                );

                return;
            }

            if (file.size > maxSize) {
                input.value = "";

                alert("The maximum file size is 5 MB.");
            }
        });
    });
}

/* =========================================================
   PREVENT DOUBLE SUBMISSION
   ========================================================= */

function setupSubmitProtection() {
    const forms = document.querySelectorAll("form");

    forms.forEach(function (form) {
        if (form.dataset.submitProtectionInitialized === "true") {
            return;
        }

        form.dataset.submitProtectionInitialized = "true";

        form.addEventListener("submit", function (event) {
            /*
             * Wait until all submit listeners have run.
             * If validation prevents submission, leave the form enabled.
             */
            window.setTimeout(function () {
                if (event.defaultPrevented) {
                    return;
                }

                if (form.dataset.submitted === "true") {
                    return;
                }

                form.dataset.submitted = "true";

                const submitButtons = form.querySelectorAll(
                    'button[type="submit"], input[type="submit"]'
                );

                submitButtons.forEach(function (button) {
                    button.classList.add("is-submitting");

                    if (button.tagName.toLowerCase() === "button") {
                        button.dataset.originalText =
                            button.textContent;

                        button.textContent = "Processing...";
                    }

                    button.disabled = true;
                });
            }, 0);
        });
    });
}

/* =========================================================
   SMOOTH INTERNAL LINKS
   ========================================================= */

function setupSmoothLinks() {
    const links = document.querySelectorAll('a[href^="#"]');

    links.forEach(function (link) {
        if (link.dataset.smoothLinkInitialized === "true") {
            return;
        }

        link.dataset.smoothLinkInitialized = "true";

        link.addEventListener("click", function (event) {
            const targetId = link.getAttribute("href");

            if (!targetId || targetId === "#") {
                return;
            }

            let target;

            try {
                target = document.querySelector(targetId);
            } catch (error) {
                return;
            }

            if (!target) {
                return;
            }

            event.preventDefault();

            target.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });
        });
    });
}

/* =========================================================
   PAGE TRANSITION
   ========================================================= */

function setupPageTransitions() {
    const links = document.querySelectorAll("a[href]");

    links.forEach(function (link) {
        if (link.dataset.pageTransitionInitialized === "true") {
            return;
        }

        link.dataset.pageTransitionInitialized = "true";

        link.addEventListener("click", function (event) {
            if (event.defaultPrevented) {
                return;
            }

            if (
                link.target === "_blank" ||
                link.hasAttribute("download")
            ) {
                return;
            }

            const href = link.getAttribute("href");

            if (
                !href ||
                href.startsWith("#") ||
                href.startsWith("javascript:") ||
                href.startsWith("mailto:") ||
                href.startsWith("tel:")
            ) {
                return;
            }

            if (
                event.ctrlKey ||
                event.metaKey ||
                event.shiftKey ||
                event.altKey
            ) {
                return;
            }

            document.body.classList.add("page-leaving");

            window.setTimeout(function () {
                document.body.classList.remove("page-leaving");
            }, 350);
        });
    });
}

/* =========================================================
   PASSWORD MATCH CHECK
   ========================================================= */

function setupPasswordMatch() {
    const password = document.querySelector(
        'input[name="password"]'
    );

    const confirmPassword = document.querySelector(
        'input[name="confirm_password"]'
    );

    if (!password || !confirmPassword) {
        return;
    }

    function checkMatch() {
        if (!confirmPassword.value) {
            confirmPassword.classList.remove("input-error");
            confirmPassword.setCustomValidity("");
            return;
        }

        if (password.value !== confirmPassword.value) {
            confirmPassword.classList.add("input-error");

            confirmPassword.setCustomValidity(
                "Passwords do not match."
            );
        } else {
            confirmPassword.classList.remove("input-error");
            confirmPassword.setCustomValidity("");
        }
    }

    password.addEventListener("input", checkMatch);
    confirmPassword.addEventListener("input", checkMatch);
}

/* =========================================================
   LIVE SPACE WALLPAPER - canvas background
   Endless animation behind all page content.
   Only background system in this file.
   ========================================================= */

document.addEventListener("DOMContentLoaded", startLiveWallpaper);

function startLiveWallpaper() {
    if (window.liveWallpaperRunning || !document.body) {
        return;
    }

    window.liveWallpaperRunning = true;

    const canvas = document.createElement("canvas");
    canvas.setAttribute("aria-hidden", "true");
    canvas.style.cssText =
        "position:fixed;inset:0;width:100%;height:100%;" +
        "z-index:-2;pointer-events:none;";

    document.body.insertBefore(canvas, document.body.firstChild);

    const ctx = canvas.getContext("2d");
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const isSmall = window.matchMedia("(max-width: 720px)").matches;

    const BASE = "#0c1a3a";
    const STAR_COLOURS = ["#ffffff", "#cfe6ff", "#b6ff3b", "#ffb36b", "#8fb8ff"];

    const NEBULAE = [
        { x: 0.18, y: 0.22, size: 0.62, rgb: "30,90,220",   alpha: 0.55, fx: 0.00011, fy: 0.00008, phase: 0.0, pulse: 0.00045 },
        { x: 0.82, y: 0.30, size: 0.52, rgb: "182,255,59",  alpha: 0.30, fx: 0.00009, fy: 0.00013, phase: 2.0, pulse: 0.00038 },
        { x: 0.40, y: 0.85, size: 0.58, rgb: "255,138,31",  alpha: 0.32, fx: 0.00012, fy: 0.00007, phase: 4.0, pulse: 0.00052 },
        { x: 0.75, y: 0.80, size: 0.48, rgb: "30,90,220",   alpha: 0.34, fx: 0.00008, fy: 0.00010, phase: 1.0, pulse: 0.00041 }
    ];

    const RIBBONS = [
        { rgb: "182,255,59", base: 0.42, amp: 0.05, thick: 0.10, speed: 0.00035, phase: 0.0, strength: 0.26 },
        { rgb: "30,140,255", base: 0.52, amp: 0.06, thick: 0.12, speed: 0.00028, phase: 2.1, strength: 0.28 },
        { rgb: "255,138,31", base: 0.62, amp: 0.04, thick: 0.08, speed: 0.00042, phase: 4.2, strength: 0.24 }
    ];

    let width = 0;
    let height = 0;
    let stars = [];
    let shooting = [];
    let nextShootAt = 1500;
    let clock = 0;
    let lastFrame = performance.now();

    function resize() {
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        const widthChanged = width !== window.innerWidth;

        width = window.innerWidth;
        height = window.innerHeight;

        canvas.width = Math.floor(width * dpr);
        canvas.height = Math.floor(height * dpr);
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

        if (!stars.length || widthChanged) {
            buildStars();
        }
    }

    function buildStars() {
        const count = isSmall ? 160 : 300;
        stars = [];

        for (let i = 0; i < count; i++) {
            const depth = Math.random();

            stars.push({
                x: Math.random() * width,
                y: Math.random() * height,
                depth: depth,
                radius: 0.5 + depth * 1.7,
                colour: STAR_COLOURS[i % STAR_COLOURS.length],
                phase: Math.random() * Math.PI * 2,
                twinkleSpeed: 0.6 + Math.random() * 0.8
            });
        }
    }

    function drawNebula(t) {
        const longest = Math.max(width, height);

        NEBULAE.forEach(function (n) {
            const x = (n.x + Math.sin(t * n.fx + n.phase) * 0.12) * width;
            const y = (n.y + Math.cos(t * n.fy + n.phase) * 0.10) * height;
            const radius = n.size * longest;

            // Colour grows and fades slowly
            const intensity = 0.7 + 0.3 * Math.sin(t * n.pulse + n.phase);
            const alpha = n.alpha * intensity;

            const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
            gradient.addColorStop(0, "rgba(" + n.rgb + "," + alpha + ")");
            gradient.addColorStop(0.45, "rgba(" + n.rgb + "," + (alpha * 0.4) + ")");
            gradient.addColorStop(1, "rgba(" + n.rgb + ",0)");

            ctx.fillStyle = gradient;
            ctx.fillRect(0, 0, width, height);
        });
    }

    function drawAurora(t) {
        const step = 14;

        RIBBONS.forEach(function (r) {
            const top = height * (r.base - r.amp - r.thick);
            const bottom = height * (r.base + r.amp + r.thick);

            // Ribbon brightness swells and settles over time
            const strength = r.strength * (0.8 + 0.2 * Math.sin(t * 0.0004 + r.phase));

            const gradient = ctx.createLinearGradient(0, top, 0, bottom);
            gradient.addColorStop(0, "rgba(" + r.rgb + ",0)");
            gradient.addColorStop(0.5, "rgba(" + r.rgb + "," + strength + ")");
            gradient.addColorStop(1, "rgba(" + r.rgb + ",0)");

            function edgeY(x, offset) {
                const wave =
                    Math.sin(x * 0.0022 + t * r.speed + r.phase) +
                    Math.sin(x * 0.0051 - t * r.speed * 0.7 + r.phase * 1.3) * 0.5;

                return height * (r.base + offset) + wave * height * r.amp;
            }

            ctx.fillStyle = gradient;
            ctx.beginPath();
            ctx.moveTo(0, edgeY(0, 0));

            for (let x = step; x <= width + step; x += step) {
                ctx.lineTo(x, edgeY(x, 0));
            }

            for (let x = width + step; x >= 0; x -= step) {
                ctx.lineTo(x, edgeY(x, r.thick));
            }

            ctx.closePath();
            ctx.fill();
        });
    }

    function drawStars(t, dt) {
        stars.forEach(function (s) {
            if (!reduceMotion) {
                const speed = 0.004 + s.depth * 0.03;

                s.x -= speed * dt;
                s.y += speed * 0.35 * dt;

                if (s.x < -4) {
                    s.x += width + 8;
                }

                if (s.y > height + 4) {
                    s.y -= height + 8;
                }
            }

            const twinkle = 0.55 + 0.45 * Math.sin(t * 0.001 * s.twinkleSpeed + s.phase);

            ctx.globalAlpha = (0.35 + s.depth * 0.55) * twinkle;
            ctx.fillStyle = s.colour;
            ctx.beginPath();
            ctx.arc(s.x, s.y, s.radius, 0, Math.PI * 2);
            ctx.fill();
        });

        ctx.globalAlpha = 1;
    }

    function updateShooting(t, dt) {
        if (t >= nextShootAt) {
            shooting.push({
                x: width * (0.5 + Math.random() * 0.5),
                y: Math.random() * height * 0.45,
                vx: -(0.6 + Math.random() * 0.3),
                vy: 0.3 + Math.random() * 0.2,
                life: 0,
                maxLife: 1100 + Math.random() * 600,
                length: 120 + Math.random() * 120
            });

            nextShootAt = t + 2500 + Math.random() * 6000;
        }

        for (let i = shooting.length - 1; i >= 0; i--) {
            const s = shooting[i];

            s.life += dt;
            s.x += s.vx * dt;
            s.y += s.vy * dt;

            const progress = s.life / s.maxLife;

            if (progress >= 1) {
                shooting.splice(i, 1);
                continue;
            }

            const magnitude = Math.hypot(s.vx, s.vy);
            const dirX = s.vx / magnitude;
            const dirY = s.vy / magnitude;
            const tailX = s.x - dirX * s.length;
            const tailY = s.y - dirY * s.length;
            const alpha = Math.sin(Math.PI * progress);

            const gradient = ctx.createLinearGradient(tailX, tailY, s.x, s.y);
            gradient.addColorStop(0, "rgba(182,255,59,0)");
            gradient.addColorStop(1, "rgba(255,255,255," + alpha + ")");

            ctx.strokeStyle = gradient;
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(tailX, tailY);
            ctx.lineTo(s.x, s.y);
            ctx.stroke();
        }
    }

    function draw(t, dt) {
        ctx.fillStyle = BASE;
        ctx.fillRect(0, 0, width, height);

        drawNebula(t);
        drawAurora(t);
        drawStars(t, dt);

        if (!reduceMotion) {
            updateShooting(t, dt);
        }
    }

    function frame(now) {
        const dt = Math.min(now - lastFrame, 50);

        lastFrame = now;
        clock += dt;

        draw(clock, dt);
        requestAnimationFrame(frame);
    }

    window.addEventListener("resize", function () {
        resize();

        if (reduceMotion) {
            draw(0, 0);
        }
    });

    resize();

    if (reduceMotion) {
        draw(0, 0);
        return;
    }

    requestAnimationFrame(frame);
}
