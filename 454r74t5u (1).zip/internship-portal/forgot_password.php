
<?php


session_start();

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/mail.php';

/*
|--------------------------------------------------------------------------
| HTML escaping
|--------------------------------------------------------------------------
*/
function forgotPasswordEscape(mixed $value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Redirect authenticated users
|--------------------------------------------------------------------------
*/
if (isset($_SESSION['user_id'], $_SESSION['role'])) {
    $role = strtolower(trim((string) $_SESSION['role']));

    if ($role === 'student') {
        header('Location: student/dashboard.php');
        exit;
    }

    if ($role === 'company') {
        header('Location: company/dashboard.php');
        exit;
    }
}

/*
|--------------------------------------------------------------------------
| CSRF token
|--------------------------------------------------------------------------
*/
if (empty($_SESSION['forgot_password_csrf'])) {
    $_SESSION['forgot_password_csrf'] = bin2hex(
        random_bytes(32)
    );
}

$message = '';
$messageType = '';
$email = '';

/*
|--------------------------------------------------------------------------
| Process request
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(
        trim((string) ($_POST['email'] ?? ''))
    );

    $postedToken = $_POST['csrf_token'] ?? '';

    if (
        !is_string($postedToken) ||
        !isset($_SESSION['forgot_password_csrf']) ||
        !hash_equals(
            $_SESSION['forgot_password_csrf'],
            $postedToken
        )
    ) {
        $message =
            'Your session expired. Refresh the page and try again.';
        $messageType = 'error';
    } elseif (
        $email === '' ||
        !filter_var($email, FILTER_VALIDATE_EMAIL) ||
        strlen($email) > 150
    ) {
        $message = 'Please enter a valid registered email address.';
        $messageType = 'error';
    } else {
        try {
            /*
            |--------------------------------------------------------------------------
            | Find the account
            |--------------------------------------------------------------------------
            */
            $stmt = $pdo->prepare(
                'SELECT id, name, email
                 FROM users
                 WHERE email = :email
                 LIMIT 1'
            );

            $stmt->execute([
                'email' => $email
            ]);

            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            /*
            |--------------------------------------------------------------------------
            | Avoid revealing whether an account exists
            |--------------------------------------------------------------------------
            */
            if (!$user) {
                $message =
                    'If this email address is registered, password-reset instructions will be sent. Check your inbox and spam folder.';
                $messageType = 'success';
            } else {
                $userId = (int) $user['id'];

                /*
                |--------------------------------------------------------------------------
                | Limit requests to one per 60 seconds
                |--------------------------------------------------------------------------
                */
                $rateStmt = $pdo->prepare(
                    'SELECT created_at
                     FROM password_resets
                     WHERE user_id = ?
                     ORDER BY id DESC
                     LIMIT 1'
                );

                $rateStmt->execute([$userId]);

                $lastReset = $rateStmt->fetch(PDO::FETCH_ASSOC);

                if ($lastReset && !empty($lastReset['created_at'])) {
                    $lastTime = strtotime(
                        (string) $lastReset['created_at']
                    );

                    if ($lastTime !== false) {
                        $elapsed = time() - $lastTime;

                        if ($elapsed >= 0 && $elapsed < 60) {
                            $remaining = 60 - $elapsed;

                            $message =
                                "Please wait {$remaining} seconds before requesting another OTP.";
                            $messageType = 'error';
                        }
                    }
                }

                /*
                |--------------------------------------------------------------------------
                | Generate and store OTP only if rate limit passed
                |--------------------------------------------------------------------------
                */
                if ($messageType !== 'error') {
                    $otp = (string) random_int(100000, 999999);

                    $otpHash = password_hash(
                        $otp,
                        PASSWORD_DEFAULT
                    );

                    if ($otpHash === false) {
                        throw new RuntimeException(
                            'Unable to generate OTP hash.'
                        );
                    }

                    $expiresAt = date(
                        'Y-m-d H:i:s',
                        time() + 600
                    );

                    /*
                    | Replace any previous reset request.
                    */
                    $pdo->beginTransaction();

                    $deleteStmt = $pdo->prepare(
                        'DELETE FROM password_resets
                         WHERE user_id = ?'
                    );

                    $deleteStmt->execute([$userId]);

                    $insertStmt = $pdo->prepare(
                        'INSERT INTO password_resets
                            (user_id, otp, expires_at, verified)
                         VALUES
                            (:user_id, :otp, :expires_at, 0)'
                    );

                    $insertStmt->execute([
                        'user_id' => $userId,
                        'otp' => $otpHash,
                        'expires_at' => $expiresAt
                    ]);

                    $pdo->commit();

                    /*
                    |--------------------------------------------------------------------------
                    | Send OTP using existing PHPMailer configuration
                    |--------------------------------------------------------------------------
                    */
                    if (!function_exists('sendOTPEmail')) {
                        throw new RuntimeException(
                            'The OTP email function is unavailable.'
                        );
                    }

                    $emailSent = sendOTPEmail(
                        (string) $user['email'],
                        $otp
                    );

                    /*
                    |--------------------------------------------------------------------------
                    | Report actual sending result
                    |--------------------------------------------------------------------------
                    */
                    if (!$emailSent) {
                        /*
                        | Remove the unused OTP if sending failed.
                        */
                        $cleanupStmt = $pdo->prepare(
                            'DELETE FROM password_resets
                             WHERE user_id = ?'
                        );

                        $cleanupStmt->execute([$userId]);

                        unset(
                            $_SESSION['reset_email'],
                            $_SESSION['reset_user_id'],
                            $_SESSION['otp_verified'],
                            $_SESSION['reset_id']
                        );

                        $message =
                            'The email system could not send your OTP. Please try again later or check the mail configuration.';
                        $messageType = 'error';
                    } else {
                        /*
                        | Store reset identity only after the mail
                        | function reports successful submission.
                        */
                        session_regenerate_id(true);

                        $_SESSION['reset_email'] =
                            (string) $user['email'];

                        $_SESSION['reset_user_id'] = $userId;

                        unset(
                            $_SESSION['otp_verified'],
                            $_SESSION['reset_id']
                        );

                        /*
                        | Redirect to the existing OTP verification page.
                        */
                        header('Location: verify_otp.php');
                        exit;
                    }
                }
            }
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log(
                'Forgot password error: ' .
                $exception->getMessage()
            );

            /*
            | Do not display database or SMTP credentials to visitors.
            */
            $message =
                'We could not process the request. Please check the server configuration and try again.';
            $messageType = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta name="theme-color" content="#070b14">

    <title>Forgot Password | Internship Portal</title>

    <link
        rel="stylesheet"
        href="css/style.css?v=20261010"
    >
    <link rel="stylesheet" href="css/neon-glass.css?v=4">

    <style>
        body.forgot-page {
            min-height: 100vh;
            margin: 0;
            color: #f5f8ff;

            background:
                radial-gradient(
                    ellipse at 12% 12%,
                    rgba(30, 125, 255, 0.18),
                    transparent 38%
                ),
                radial-gradient(
                    ellipse at 88% 88%,
                    rgba(255, 49, 151, 0.12),
                    transparent 36%
                ),
                #050914;
        }

        .forgot-wrapper {
            min-height: 100vh;
            display: grid;
            place-items: center;
            box-sizing: border-box;
            padding: 24px 16px;
        }

        .forgot-card {
            position: relative;
            overflow: hidden;

            width: min(100%, 460px);
            box-sizing: border-box;
            padding: 32px;

            border: 1px solid rgba(66, 156, 255, 0.38);
            border-radius: 22px;

            background: linear-gradient(
                145deg,
                rgba(15, 27, 52, 0.97),
                rgba(7, 11, 25, 0.98)
            );

            box-shadow:
                0 0 35px rgba(0, 100, 255, 0.10),
                0 0 70px rgba(255, 35, 120, 0.06),
                0 24px 75px rgba(0, 0, 0, 0.35);
        }

        .forgot-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;

            background: linear-gradient(
                90deg,
                #2b8cff,
                #7655ff,
                #ff398a
            );
        }

        .forgot-brand {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-bottom: 28px;

            color: #f5f8ff;
            font-weight: 850;
            text-decoration: none;
        }

        .forgot-brand-mark {
            display: grid;
            place-items: center;
            width: 42px;
            height: 42px;
            border-radius: 12px;

            color: white;
            background: linear-gradient(
                135deg,
                #218fff,
                #7555ff,
                #ff398a
            );
        }

        .forgot-heading {
            margin: 0;

            color: #f5f8ff;
            text-align: center;
            font-size: clamp(28px, 5vw, 36px);
            font-weight: 900;
            letter-spacing: -1px;
        }

        .forgot-description {
            margin: 14px 0 25px;

            color: #aebed8;
            text-align: center;
            font-size: 13px;
            line-height: 1.8;
        }

        .forgot-message {
            margin-bottom: 20px;
            padding: 13px 15px;

            border-radius: 11px;
            font-size: 13px;
            line-height: 1.7;
            overflow-wrap: anywhere;
        }

        .forgot-message.error {
            color: #ffb1c0;
            background: rgba(255, 40, 80, 0.08);
            border: 1px solid rgba(255, 55, 90, 0.30);
        }

        .forgot-message.success {
            color: #bceeff;
            background: rgba(66, 186, 255, 0.08);
            border: 1px solid rgba(66, 186, 255, 0.28);
        }

        .forgot-field {
            margin-bottom: 20px;
        }

        .forgot-field label {
            display: block;
            margin-bottom: 9px;

            color: #e1eaff;
            font-size: 13px;
            font-weight: 750;
        }

        .forgot-field input {
            display: block;
            width: 100%;
            min-height: 51px;
            box-sizing: border-box;
            padding: 13px 14px;

            color: #ffffff;
            background: rgba(7, 15, 33, 0.94);

            border: 1px solid rgba(95, 140, 195, 0.30);
            border-radius: 11px;
            outline: none;

            font: inherit;
            font-size: 14px;

            transition:
                border-color 0.2s ease,
                box-shadow 0.2s ease;
        }

        .forgot-field input::placeholder {
            color: rgba(190, 201, 225, 0.48);
        }

        .forgot-field input:focus {
            border-color: rgba(66, 186, 255, 0.88);
            box-shadow: 0 0 0 3px rgba(45, 137, 255, 0.10);
        }

        .forgot-submit {
            width: 100%;
            min-height: 52px;
            padding: 13px 18px;

            color: #ffffff;
            font: inherit;
            font-weight: 850;

            border: 1px solid rgba(126, 194, 255, 0.30);
            border-radius: 12px;

            background: linear-gradient(
                100deg,
                #176fff,
                #6550ff,
                #e82f82
            );

            cursor: pointer;

            transition:
                transform 0.2s ease,
                box-shadow 0.2s ease;
        }

        .forgot-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(40, 100, 255, 0.23);
        }

        .forgot-submit:active {
            transform: scale(0.98);
        }

        .forgot-links {
            margin-top: 23px;
            text-align: center;
        }

        .forgot-links a {
            color: #8bdcff;
            font-size: 13px;
            font-weight: 750;
            text-decoration: none;
        }

        .forgot-links a:hover {
            color: #ff86c2;
        }

        .forgot-links p {
            margin: 12px 0 0;
            color: #aebed8;
            font-size: 12px;
        }

        a:focus-visible,
        button:focus-visible,
        input:focus-visible {
            outline: 2px solid #8bdcff;
            outline-offset: 3px;
        }

        @media (max-width: 500px) {
            .forgot-card {
                padding: 25px 19px;
                border-radius: 18px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: 0.01ms !important;
                transition-duration: 0.01ms !important;
            }
        }
    </style>
</head>

<body class="forgot-page">

<main class="forgot-wrapper">

    <section class="forgot-card">

        <a href="index.php" class="forgot-brand">
            <span class="forgot-brand-mark">IP</span>
            <span>INTERNSHIP PORTAL</span>
        </a>

        <h1 class="forgot-heading">
            Forgot Password?
        </h1>

        <p class="forgot-description">
            Enter the email address associated with your account.
            If it is registered, we'll process your password-reset request.
        </p>

        <?php if ($message !== ''): ?>

            <div
                class="forgot-message <?= $messageType === 'success'
                    ? 'success'
                    : 'error' ?>"
                role="<?= $messageType === 'error'
                    ? 'alert'
                    : 'status' ?>"
            >
                <?= forgotPasswordEscape($message) ?>
            </div>

        <?php endif; ?>

        <form
            method="POST"
            action="forgot_password.php"
            id="forgotPasswordForm"
        >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= forgotPasswordEscape(
                    $_SESSION['forgot_password_csrf']
                ) ?>"
            >

            <div class="forgot-field">

                <label for="email">
                    Registered Email Address
                </label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    value="<?= forgotPasswordEscape($email) ?>"
                    placeholder="Enter your registered email"
                    autocomplete="email"
                    maxlength="150"
                    required
                >

            </div>

            <button
                type="submit"
                class="forgot-submit"
            >
                Send Reset OTP
            </button>

        </form>

        <div class="forgot-links">

            <p>
                Remember your password?
                <a href="login.php">Login</a>
            </p>

            <p>
                <a href="index.php">Back to Home</a>
            </p>

        </div>

    </section>

</main>

<script src="js/validation.js?v=4"></script>

</body>
</html>
