
<?php


session_start();

require_once __DIR__ . '/config/database.php';

/*
|--------------------------------------------------------------------------
| Helper: escape HTML output
|--------------------------------------------------------------------------
*/
function loginEscape(mixed $value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Redirect logged-in users
|--------------------------------------------------------------------------
*/
if (isset($_SESSION['user_id'], $_SESSION['role'])) {
    $sessionRole = strtolower(
        trim((string) $_SESSION['role'])
    );

    if ($sessionRole === 'company') {
        header('Location: company/dashboard.php');
        exit;
    }

    if ($sessionRole === 'student') {
        header('Location: student/dashboard.php');
        exit;
    }

    unset(
        $_SESSION['user_id'],
        $_SESSION['name'],
        $_SESSION['email'],
        $_SESSION['role']
    );
}

/*
|--------------------------------------------------------------------------
| CSRF protection
|--------------------------------------------------------------------------
*/
if (empty($_SESSION['login_csrf_token'])) {
    $_SESSION['login_csrf_token'] = bin2hex(
        random_bytes(32)
    );
}

$errors = [];
$email = '';

/*
|--------------------------------------------------------------------------
| Process login form
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(
        trim((string) ($_POST['email'] ?? ''))
    );

    $password = (string) ($_POST['password'] ?? '');

    $postedToken = $_POST['csrf_token'] ?? '';

    /*
    | Validate CSRF token.
    */
    if (
        !is_string($postedToken) ||
        !isset($_SESSION['login_csrf_token']) ||
        !hash_equals(
            $_SESSION['login_csrf_token'],
            $postedToken
        )
    ) {
        $errors[] =
            'Your session expired. Please refresh the page and try again.';
    }

    /*
    | Validate email and password.
    */
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Enter a valid email address.';
    } elseif (strlen($email) > 150) {
        $errors[] = 'The email address is too long.';
    }

    if ($password === '') {
        $errors[] = 'Password is required.';
    } elseif (strlen($password) > 4096) {
        $errors[] = 'The password is too long.';
    }

    /*
    | Authenticate user.
    */
    if (empty($errors)) {
        try {
            $statement = $pdo->prepare(
                'SELECT id, name, email, password, role
                 FROM users
                 WHERE email = :email
                 LIMIT 1'
            );

            $statement->execute([
                'email' => $email
            ]);

            $user = $statement->fetch(PDO::FETCH_ASSOC);

            if (
                !$user ||
                !password_verify(
                    $password,
                    (string) $user['password']
                )
            ) {
                $errors[] = 'Invalid email or password.';
            } else {
                /*
                | Database roles may be stored as Student/Company.
                | Convert them to lowercase for session checks.
                */
                $databaseRole = strtolower(
                    trim((string) $user['role'])
                );

                if (
                    !in_array(
                        $databaseRole,
                        ['student', 'company'],
                        true
                    )
                ) {
                    $errors[] =
                        'This account has an unsupported account type.';
                } else {
                    /*
                    | Regenerate session ID after successful login.
                    */
                    session_regenerate_id(true);

                    $_SESSION['user_id'] = (int) $user['id'];
                    $_SESSION['name'] = (string) $user['name'];
                    $_SESSION['email'] = (string) $user['email'];
                    $_SESSION['role'] = $databaseRole;

                    /*
                    | Rotate login CSRF token.
                    */
                    unset($_SESSION['login_csrf_token']);

                    $_SESSION['csrf_token'] = bin2hex(
                        random_bytes(32)
                    );

                    /*
                    | Redirect by account type.
                    */
                    if ($databaseRole === 'company') {
                        header('Location: company/dashboard.php');
                    } else {
                        header('Location: student/dashboard.php');
                    }

                    exit;
                }
            }
        } catch (Throwable $exception) {
            error_log(
                'Login error: ' . $exception->getMessage()
            );

            $errors[] =
                'Login is temporarily unavailable. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta name="theme-color" content="#070b14">

    <title>Login | Internship Portal</title>

    <link
        rel="stylesheet"
        href="css/style.css?v=20261010"
    >
    <link rel="stylesheet" href="css/neon-glass.css?v=4">

    <style>
        html,
        body {
            width: 100%;
            min-height: 100%;
            margin: 0;
            padding: 0;
        }

        body.login-page {
            min-height: 100vh;
            overflow-x: hidden;

            background:
                radial-gradient(
                    ellipse at 12% 14%,
                    rgba(30, 125, 255, 0.18),
                    transparent 38%
                ),
                radial-gradient(
                    ellipse at 88% 86%,
                    rgba(255, 49, 120, 0.12),
                    transparent 36%
                ),
                #050914;
        }

        .login-wrapper {
            width: 100%;
            min-height: 100vh;

            display: flex;
            align-items: center;
            justify-content: center;

            box-sizing: border-box;
            padding: 32px 20px;
        }

        .login-container {
            width: min(100%, 1080px);
            margin: 0 auto;

            display: grid;

            grid-template-columns:
                minmax(0, 0.95fr)
                minmax(360px, 0.75fr);

            gap: 35px;
            align-items: center;
        }

        /* Intro panel */

        .login-intro {
            padding: 20px;
        }

        .login-intro h1 {
            margin: 0 0 18px;

            color: #f5f8ff;
            font-size: clamp(42px, 5vw, 68px);
            font-weight: 900;
            line-height: 0.98;
            letter-spacing: -0.05em;

            text-shadow:
                0 0 35px rgba(66, 186, 255, 0.14);
        }

        .login-intro p {
            max-width: 460px;
            margin: 0;

            color: #b7c8e5;
            font-size: 15px;
            line-height: 1.8;
        }

        .login-nav {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 12px;
            margin-top: 30px;
        }

        .login-nav a {
            padding: 10px 15px;

            color: #c4d3eb;
            text-decoration: none;
            font-size: 13px;
            font-weight: 700;

            border: 1px solid rgba(84, 157, 255, 0.22);
            border-radius: 10px;

            transition: all 0.25s ease;
        }

        .login-nav a:hover {
            color: #ffffff;
            border-color: rgba(66, 186, 255, 0.60);
            background: rgba(66, 186, 255, 0.09);

            box-shadow:
                0 0 20px rgba(66, 186, 255, 0.10);
        }

        /* Login card */

        .login-card {
            position: relative;
            overflow: hidden;

            width: 100%;
            max-width: 470px;
            margin: 0 auto;
            padding: 35px 30px;

            box-sizing: border-box;

            border: 1px solid rgba(66, 156, 255, 0.38);
            border-radius: 24px;

            background:
                linear-gradient(
                    145deg,
                    rgba(15, 27, 52, 0.96),
                    rgba(7, 11, 25, 0.98)
                );

            box-shadow:
                0 0 35px rgba(0, 100, 255, 0.10),
                0 0 70px rgba(255, 35, 120, 0.06),
                0 24px 75px rgba(0, 0, 0, 0.35);

            animation: loginFadeUp 0.55s ease both;
        }

        .login-card::before {
            content: "";

            position: absolute;
            top: 0;
            left: 0;
            right: 0;

            height: 3px;

            background:
                linear-gradient(
                    90deg,
                    #2b8cff,
                    #7655ff,
                    #ff398a,
                    #2b8cff
                );

            background-size: 250% 100%;

            animation: loginLine 5s linear infinite;
        }

        @keyframes loginLine {
            from {
                background-position: 0% 50%;
            }

            to {
                background-position: 250% 50%;
            }
        }

        @keyframes loginFadeUp {
            from {
                opacity: 0;
                transform: translateY(15px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Card heading */

        .login-header {
            margin-bottom: 28px;
            text-align: center;
        }

        .login-kicker {
            margin: 0 0 9px;

            color: #8bdcff;
            font-size: 12px;
            font-weight: 800;
            letter-spacing: 2px;
            text-transform: uppercase;
        }

        .login-header h2 {
            margin: 0;

            color: #f5f8ff;
            font-size: clamp(36px, 4vw, 48px);
            line-height: 1.02;
            letter-spacing: -0.04em;
        }

        .login-subtitle {
            margin: 15px 0 0;

            color: #aabbd7;
            font-size: 13px;
            line-height: 1.7;
        }

        /* Error messages */

        .login-error {
            margin-bottom: 20px;
            padding: 13px 15px;

            color: #ffb1c0;
            font-size: 13px;
            line-height: 1.6;

            background: rgba(255, 40, 80, 0.08);
            border: 1px solid rgba(255, 55, 90, 0.30);
            border-radius: 11px;
        }

        .login-error ul {
            margin: 0;
            padding-left: 18px;
        }

        /* Form */

        .login-form {
            width: 100%;
        }

        .login-field {
            width: 100%;
            margin-bottom: 19px;
        }

        .login-field label {
            display: block;
            margin-bottom: 9px;

            color: #e1eaff;
            font-size: 13px;
            font-weight: 750;
        }

        .login-field input {
            display: block;

            width: 100%;
            min-height: 52px;
            padding: 13px 14px;

            box-sizing: border-box;

            color: #ffffff;
            background: rgba(7, 15, 33, 0.94);

            border: 1px solid rgba(95, 140, 195, 0.27);
            border-radius: 11px;
            outline: none;

            font: inherit;
            font-size: 14px;

            transition:
                border-color 0.2s ease,
                box-shadow 0.2s ease,
                transform 0.2s ease;
        }

        .login-field input::placeholder {
            color: rgba(190, 201, 225, 0.48);
        }

        .login-field input:focus {
            border-color: rgba(66, 186, 255, 0.88);

            box-shadow:
                0 0 0 3px rgba(45, 137, 255, 0.10),
                0 0 22px rgba(45, 137, 255, 0.12);

            transform: translateY(-1px);
        }

        .login-field input.input-error {
            border-color: #ff648d;
        }

        /* Password visibility control */

        .password-wrap {
            position: relative;
            width: 100%;
        }

        .password-wrap input {
            padding-right: 78px;
        }

        .password-toggle {
            position: absolute;
            top: 50%;
            right: 9px;

            transform: translateY(-50%);

            min-width: 49px;
            padding: 8px 9px;

            color: #8bdcff;
            background: rgba(66, 186, 255, 0.08);

            border: 1px solid rgba(66, 186, 255, 0.19);
            border-radius: 8px;

            font-size: 12px;
            font-weight: 800;

            cursor: pointer;

            transition:
                background 0.2s ease,
                color 0.2s ease,
                border-color 0.2s ease;
        }

        .password-toggle:hover {
            color: #ffffff;

            background: rgba(66, 186, 255, 0.18);
            border-color: rgba(66, 186, 255, 0.55);
        }

        .password-toggle:active {
            transform: translateY(-50%) scale(0.96);
        }

        /* Forgot password */

        .forgot-row {
            display: flex;
            justify-content: flex-end;
            margin: -4px 0 20px;
        }

        .forgot-row a {
            color: #8bdcff;
            text-decoration: none;

            font-size: 12px;
            font-weight: 700;

            transition: color 0.2s ease;
        }

        .forgot-row a:hover {
            color: #ff86c2;
        }

        /* Sign in button */

        .login-submit {
            position: relative;
            overflow: hidden;

            width: 100%;
            min-height: 52px;
            padding: 13px 18px;

            color: #ffffff;

            border: 1px solid rgba(126, 194, 255, 0.30);
            border-radius: 12px;

            background:
                linear-gradient(
                    100deg,
                    #176fff,
                    #6550ff,
                    #e82f82
                );

            background-size: 200% 100%;

            box-shadow:
                0 8px 25px rgba(40, 100, 255, 0.18),
                0 0 20px rgba(235, 45, 120, 0.08);

            font: inherit;
            font-weight: 800;

            cursor: pointer;

            transition:
                transform 0.2s ease,
                box-shadow 0.2s ease,
                background-position 0.4s ease;
        }

        .login-submit:hover {
            transform: translateY(-2px);
            background-position: 100% 50%;

            box-shadow:
                0 12px 30px rgba(40, 100, 255, 0.25),
                0 0 25px rgba(235, 45, 120, 0.15);
        }

        .login-submit:active {
            transform: scale(0.98);
        }

        .login-submit:disabled {
            opacity: 0.7;
            cursor: wait;
            transform: none;
        }

        /* Bottom links */

        .login-register {
            margin-top: 23px;

            color: #aabbd7;
            text-align: center;
            font-size: 13px;
            line-height: 1.9;
        }

        .login-register a {
            color: #8bdcff;
            font-weight: 750;
            text-decoration: none;
        }

        .login-register a:hover {
            color: #ff86c2;
        }

        .back-home {
            display: block;
            margin-top: 17px;

            color: #aabbd7;
            text-align: center;
            text-decoration: none;
            font-size: 12px;

            transition: color 0.2s ease;
        }

        .back-home:hover {
            color: #ffffff;
        }

        /* Accessibility */

        a:focus-visible,
        button:focus-visible,
        input:focus-visible {
            outline: 2px solid #8bdcff;
            outline-offset: 3px;
        }

        /* Responsive layout */

        @media (max-width: 900px) {
            .login-container {
                grid-template-columns: 1fr;
                max-width: 560px;
            }

            .login-intro {
                display: none;
            }

            .login-card {
                max-width: 560px;
            }
        }

        @media (max-width: 600px) {
            .login-wrapper {
                padding: 16px 12px;
                align-items: flex-start;
            }

            .login-card {
                padding: 28px 19px;
                border-radius: 18px;
            }

            .login-header {
                margin-bottom: 23px;
            }

            .login-header h2 {
                font-size: 38px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: 0.01ms !important;
                transition-duration: 0.01ms !important;
            }
        }
    </style>
</head>

<body class="login-page">

<div class="login-wrapper">

    <div class="login-container">

        <!-- Intro panel -->

        <section class="login-intro">

            <h1>
                Internship<br>
                Portal
            </h1>

            <p>
                Secure access to your internship account.
                Discover opportunities, manage applications,
                and move forward in your career.
            </p>

            <nav class="login-nav" aria-label="Main navigation">

                <a href="index.php">Home</a>

                <a href="register.php">Create Account</a>

            </nav>

        </section>

        <!-- Login card -->

        <main class="login-card">

            <div class="login-header">

                <p class="login-kicker">
                    Secure Access
                </p>

                <h2>
                    Welcome<br>
                    Back
                </h2>

                <p class="login-subtitle">
                    Login with your registered email
                </p>

            </div>

            <?php if (!empty($errors)): ?>

                <div class="login-error" role="alert">

                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li>
                                <?= loginEscape($error) ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>

                </div>

            <?php endif; ?>

            <form
                method="POST"
                action="login.php"
                class="login-form"
                id="loginForm"
            >

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= loginEscape(
                        $_SESSION['login_csrf_token']
                    ) ?>"
                >

                <!-- Email -->

                <div class="login-field">

                    <label for="email">
                        Email Address
                    </label>

                    <input
                        type="email"
                        id="email"
                        name="email"
                        value="<?= loginEscape($email) ?>"
                        placeholder="Enter your email address"
                        autocomplete="email"
                        maxlength="150"
                        required
                    >

                </div>

                <!-- Password -->

                <div class="login-field">

                    <label for="password">
                        Password
                    </label>

                    <div class="password-wrap">

                        <input
                            type="password"
                            id="password"
                            name="password"
                            placeholder="Enter your password"
                            autocomplete="current-password"
                            required
                        >

                        <button
                            type="button"
                            class="password-toggle"
                            data-password-toggle="password"
                            aria-controls="password"
                            aria-label="Show password"
                        >
                            Show
                        </button>

                    </div>

                </div>

                <!-- Forgot password -->

                <div class="forgot-row">

                    <a href="forgot_password.php">
                        Forgot Password?
                    </a>

                </div>

                <!-- Submit -->

                <button
                    type="submit"
                    class="login-submit"
                    id="loginSubmit"
                >
                    Sign In
                </button>

                <!-- Registration link -->

                <div class="login-register">

                    Don't have an account?

                    <br>

                    <a href="register.php">
                        Create an account
                    </a>

                </div>

                <a href="index.php" class="back-home">
                    &larr; Back to Home
                </a>

            </form>

        </main>

    </div>

</div>

<!-- Password toggling is handled by validation.js only.
     Do not add a second click handler in this file. -->
<script src="js/validation.js?v=4"></script>

</body>
</html>
