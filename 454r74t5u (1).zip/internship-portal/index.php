<?php
session_start();

if (isset($_SESSION['user_id'])) {
    $dashboard = $_SESSION['role'] === 'student'
        ? 'student/dashboard.php'
        : 'company/dashboard.php';
} else {
    $dashboard = 'login.php';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>College Internship Portal</title>

    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/neon-glass.css?v=4">
    <script src="js/validation.js?v=4" defer></script>
</head>

<body>

<div class="page-shell">

    <header class="site-header">

        <a href="index.php" class="brand">
            <span class="brand-mark">IP</span>

            <span class="brand-text">
                <strong>INTERNSHIP</strong>
                <small>COLLEGE PORTAL</small>
            </span>
        </a>

        <nav class="main-nav">

            <a href="index.php" class="nav-link active">
                Home
            </a>

            <?php if (isset($_SESSION['user_id'])): ?>

                <a href="<?= htmlspecialchars($dashboard) ?>" class="nav-link">
                    Dashboard
                </a>

                <a href="logout.php" class="nav-link nav-danger">
                    Logout
                </a>

            <?php else: ?>

                <a href="login.php"  class="nav-link active">
                    Login
                </a>

                <a href="register.php" class="nav-button">
                    Register
                </a>

            <?php endif; ?>

        </nav>

    </header>


    <main class="home-page">

        <section class="hero-section">

            <div class="hero-content">

                <div class="hero-badge">
                    <span></span>
                    INTERNSHIP APPLICATION PLATFORM
                </div>

                <h1>
                    Build Your
                    <span>Career</span>
                    Through Real Opportunities
                </h1>

                <p class="hero-description">
                    Discover internships, build your professional profile,
                    apply to opportunities, and track your applications
                    from one platform.
                </p>

                <div class="hero-actions">

                    <?php if (isset($_SESSION['user_id'])): ?>

                        <a href="<?= htmlspecialchars($dashboard) ?>" class="btn btn-primary">
                            Open Dashboard
                        </a>

                    <?php else: ?>

                        <a href="register.php" class="btn btn-primary">
                            Get Started
                        </a>

                        <a href="login.php" class="btn btn-primary">
                            Sign In
                        </a>

                    <?php endif; ?>

                </div>

            </div>


            <div class="hero-visual">

                <div class="orbit orbit-one"></div>
                <div class="orbit orbit-two"></div>

                <div class="portal-core">

                    <div class="core-icon">
                        IP
                    </div>

                    <div class="core-title">
                        INTERNSHIP
                    </div>

                    <div class="core-status">
                        <span></span>
                        PLATFORM ONLINE
                    </div>

                </div>

                <div class="floating-card card-top">
                    <small>OPPORTUNITIES</small>
                    <strong>Explore</strong>
                </div>

                <div class="floating-card card-bottom">
                    <small>APPLICATIONS</small>
                    <strong>Track</strong>
                </div>

            </div>

        </section>


        <section class="feature-grid">

            <article class="feature-card">

                <div class="feature-number">
                    01
                </div>

                <div>
                    <h3>Student Profile</h3>

                    <p>
                        Create your profile with education,
                        skills and resume information.
                    </p>
                </div>

            </article>


            <article class="feature-card">

                <div class="feature-number">
                    02
                </div>

                <div>
                    <h3>Find Internships</h3>

                    <p>
                        Search and filter internship opportunities
                        based on your interests and skills.
                    </p>
                </div>

            </article>


            <article class="feature-card">

                <div class="feature-number">
                    03
                </div>

                <div>
                    <h3>Track Applications</h3>

                    <p>
                        Monitor your application status from
                        submission through final selection.
                    </p>
                </div>

            </article>


            <article class="feature-card">

                <div class="feature-number">
                    04
                </div>

                <div>
                    <h3>Company Portal</h3>

                    <p>
                        Companies can publish internships,
                        review applicants and manage selections.
                    </p>
                </div>

            </article>

        </section>


        <section class="workflow-section">

            <div class="section-heading">

                <span class="section-label">
                    APPLICATION FLOW
                </span>

                <h2>
                    From Application to Opportunity
                </h2>

            </div>


            <div class="workflow">

                <div class="workflow-step">
                    <span>01</span>
                    <strong>Applied</strong>
                </div>

                <div class="workflow-line"></div>

                <div class="workflow-step">
                    <span>02</span>
                    <strong>Under Review</strong>
                </div>

                <div class="workflow-line"></div>

                <div class="workflow-step">
                    <span>03</span>
                    <strong>Shortlisted</strong>
                </div>

                <div class="workflow-line"></div>

                <div class="workflow-step">
                    <span>04</span>
                    <strong>Interview</strong>
                </div>

                <div class="workflow-line"></div>

                <div class="workflow-step">
                    <span>05</span>
                    <strong>Selected</strong>
                </div>

            </div>

        </section>

    </main>


    <footer class="site-footer">

        <div>
            College Internship Portal
        </div>

        <div>
            Student &nbsp;|&nbsp; Company
        </div>

    </footer>

</div>

</body>
</html>