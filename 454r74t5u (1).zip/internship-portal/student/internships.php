<?php
session_start();

require_once __DIR__ . '/../config/database.php';

if (
    !isset($_SESSION['user_id']) ||
    ($_SESSION['role'] ?? '') !== 'student'
) {
    header('Location: ../login.php');
    exit;
}

function listingEscape($value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

$userId = (int) $_SESSION['user_id'];
$studentId = 0;
$internships = [];
$message = '';
$messageType = 'info';

/*
|--------------------------------------------------------------------------
| CSRF token for application submissions
|--------------------------------------------------------------------------
*/
if (empty($_SESSION['student_apply_csrf'])) {
    $_SESSION['student_apply_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['student_apply_csrf'];

/*
|--------------------------------------------------------------------------
| Display one-time messages from apply.php
|--------------------------------------------------------------------------
*/
if (isset($_SESSION['student_portal_flash'])) {
    $flash = $_SESSION['student_portal_flash'];

    $message = (string) ($flash['message'] ?? '');
    $messageType = (string) ($flash['type'] ?? 'info');

    unset($_SESSION['student_portal_flash']);
}

/*
|--------------------------------------------------------------------------
| Find the logged-in student's profile
|--------------------------------------------------------------------------
*/
try {
    $stmt = $pdo->prepare(
        'SELECT id
         FROM students
         WHERE user_id = ?
         LIMIT 1'
    );

    $stmt->execute([$userId]);
    $studentId = (int) ($stmt->fetchColumn() ?: 0);

    if ($studentId === 0) {
        $message = 'Please complete your student profile before applying.';
        $messageType = 'warning';
    }

} catch (PDOException $e) {
    error_log('Student profile lookup error: ' . $e->getMessage());

    http_response_code(500);
    exit('Unable to load your student profile. Please try again later.');
}

/*
|--------------------------------------------------------------------------
| Search and sorting
|--------------------------------------------------------------------------
*/
$search = trim((string) ($_GET['search'] ?? ''));
$sort = (string) ($_GET['sort'] ?? 'latest');

$sortOptions = [
    'latest' => 'i.created_at DESC, i.id DESC',
    'deadline' => 'i.deadline ASC, i.created_at DESC',
];

if (!isset($sortOptions[$sort])) {
    $sort = 'latest';
}

/*
|--------------------------------------------------------------------------
| Fetch available internships
|--------------------------------------------------------------------------
*/
try {
    $sql = "
        SELECT
            i.id,
            i.title,
            i.skills_required,
            i.deadline,
            i.created_at,
            c.company_name,
            CASE
                WHEN EXISTS (
                    SELECT 1
                    FROM applications a
                    WHERE a.internship_id = i.id
                      AND a.student_id = :student_id
                )
                THEN 1
                ELSE 0
            END AS has_applied
        FROM internships AS i
        LEFT JOIN companies AS c
            ON c.id = i.company_id
        WHERE (
            i.deadline IS NULL
            OR i.deadline >= CURDATE()
        )
    ";

    $params = [
        ':student_id' => $studentId,
    ];

    if ($search !== '') {
        $sql .= "
            AND (
                i.title LIKE :title_search
                OR COALESCE(c.company_name, '') LIKE :company_search
                OR COALESCE(i.skills_required, '') LIKE :skills_search
            )
        ";

        $keyword = '%' . $search . '%';

        $params[':title_search'] = $keyword;
        $params[':company_search'] = $keyword;
        $params[':skills_search'] = $keyword;
    }

    $sql .= ' ORDER BY ' . $sortOptions[$sort];

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    $internships = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log('Student internship listing error: ' . $e->getMessage());

    http_response_code(500);
    exit('Unable to load internships. Please try again later.');
}

$totalInternships = count($internships);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Find Internships | Internship Portal</title>

    <link
        rel="stylesheet"
        href="../css/style.css?v=<?php
            echo (int) @filemtime(__DIR__ . '/../css/style.css');
        ?>"
    >
    <link rel="stylesheet" href="../css/neon-glass.css?v=4">
</head>

<body>

<div class="dashboard-page student-listings-page">

    <!-- Navigation -->
    <nav class="dashboard-nav">

        <a class="nav-brand" href="../index.php">
            Internship Portal
        </a>

        <div class="nav-links">
            <a href="../index.php">Home</a>
            <a href="dashboard.php">Dashboard</a>
            <a href="profile.php">Profile</a>
            <a href="internships.php" class="active" aria-current="page">
                Internships
            </a>
            <a href="applications.php">My Applications</a>
            <a href="../logout.php">Logout</a>
        </div>

    </nav>


    <main class="dashboard-container">

        <!-- Page heading -->
        <section class="dashboard-header student-listings-hero">

            <div>
                <span class="dashboard-label">
                    OPPORTUNITIES
                </span>

                <h1>Find Internships</h1>

                <p>
                    Explore internship opportunities and apply for a role
                    that matches your skills.
                </p>
            </div>

            <div class="student-listings-total">
                <strong><?php echo $totalInternships; ?></strong>

                <span>
                    <?php echo $totalInternships === 1
                        ? 'Active Internship'
                        : 'Active Internships'; ?>
                </span>
            </div>

        </section>


        <!-- Feedback -->
        <?php if ($message !== ''): ?>

            <div
                class="alert <?php
                    echo $messageType === 'success'
                        ? 'alert-success'
                        : (
                            $messageType === 'warning'
                                ? 'alert-warning'
                                : (
                                    $messageType === 'info'
                                        ? 'alert-info'
                                        : 'alert-error'
                                )
                        );
                ?>"
                role="status"
            >
                <?php echo listingEscape($message); ?>

                <?php if ($studentId === 0): ?>
                    <a href="profile.php" class="student-listings-profile-link">
                        Complete Profile
                    </a>
                <?php endif; ?>
            </div>

        <?php endif; ?>


        <!-- Search -->
        <section class="student-listings-search-panel">

            <div class="student-listings-search-heading">
                <div>
                    <h2>Browse Opportunities</h2>
                    <p>Search by internship title, company, or skills.</p>
                </div>
            </div>

            <form
                method="GET"
                action="internships.php"
                class="student-listings-search-form"
            >

                <div class="student-listings-search-input">
                    <label for="search">Search Internships</label>

                    <input
                        id="search"
                        type="text"
                        name="search"
                        placeholder="Enter a title, company, or skill"
                        value="<?php echo listingEscape($search); ?>"
                    >
                </div>

                <div class="student-listings-sort">
                    <label for="sort">Sort By</label>

                    <select id="sort" name="sort">
                        <option
                            value="latest"
                            <?php echo $sort === 'latest' ? 'selected' : ''; ?>
                        >
                            Latest
                        </option>

                        <option
                            value="deadline"
                            <?php echo $sort === 'deadline' ? 'selected' : ''; ?>
                        >
                            Closing Soon
                        </option>
                    </select>
                </div>

                <div class="student-listings-search-buttons">
                    <button type="submit" class="btn btn-primary">
                        Search
                    </button>

                    <a
                        href="internships.php"
                        class="btn btn-secondary"
                    >
                        Clear
                    </a>
                </div>

            </form>

        </section>


        <!-- Internship cards -->
        <?php if (empty($internships)): ?>

            <section class="dashboard-card student-listings-empty">

                <div class="student-listings-empty-icon" aria-hidden="true">
                    IN
                </div>

                <h2>No internships found</h2>

                <p>
                    Try another search term, or clear the search to view
                    all available internships.
                </p>

                <a
                    href="internships.php"
                    class="btn btn-primary"
                >
                    View All Internships
                </a>

            </section>

        <?php else: ?>

            <section
                class="student-listings-grid"
                aria-label="Available internships"
            >

                <?php foreach ($internships as $internship): ?>

                    <?php
                    $internshipId = (int) $internship['id'];

                    $companyName = trim(
                        (string) ($internship['company_name'] ?? '')
                    );

                    if ($companyName === '') {
                        $companyName = 'Company';
                    }

                    $title = (string) ($internship['title'] ?? '');

                    $skillsText = trim(
                        (string) ($internship['skills_required'] ?? '')
                    );

                    $skills = [];

                    if ($skillsText !== '') {
                        $skills = preg_split(
                            '/[,;]+/',
                            $skillsText,
                            -1,
                            PREG_SPLIT_NO_EMPTY
                        ) ?: [];

                        $skills = array_slice($skills, 0, 8);
                    }

                    $deadlineTime = !empty($internship['deadline'])
                        ? strtotime((string) $internship['deadline'])
                        : false;

                    $deadlineDisplay = $deadlineTime !== false
                        ? date('d M Y', $deadlineTime)
                        : 'Not specified';

                    $hasApplied = (int) ($internship['has_applied'] ?? 0) === 1;

                    $companyInitial = strtoupper(
                        substr($companyName, 0, 1)
                    );
                    ?>

                    <article class="student-listing-card">

                        <!-- Company -->
                        <div class="student-listing-company">

                            <div class="student-listing-company-avatar">
                                <?php echo listingEscape($companyInitial); ?>
                            </div>

                            <div class="student-listing-company-details">
                                <span class="student-listing-field-label">
                                    COMPANY
                                </span>

                                <h3>
                                    <?php echo listingEscape($companyName); ?>
                                </h3>
                            </div>

                            <span class="student-listing-badge">
                                Internship
                            </span>

                        </div>


                        <!-- Internship title -->
                        <div class="student-listing-title-area">

                            <h2>
                                <?php echo listingEscape($title); ?>
                            </h2>

                        </div>


                        <!-- Skills only -->
                        <div class="student-listing-skills-area">

                            <span class="student-listing-field-label">
                                SKILLS REQUIRED
                            </span>

                            <?php if (!empty($skills)): ?>

                                <div class="student-listing-skills">

                                    <?php foreach ($skills as $skill): ?>

                                        <span class="student-listing-skill">
                                            <?php
                                            echo listingEscape(trim($skill));
                                            ?>
                                        </span>

                                    <?php endforeach; ?>

                                </div>

                            <?php else: ?>

                                <p class="student-listing-no-skills">
                                    Skills not specified
                                </p>

                            <?php endif; ?>

                        </div>


                        <!-- Deadline only -->
                        <div class="student-listing-deadline">

                            <span class="student-listing-field-label">
                                APPLICATION DEADLINE
                            </span>

                            <strong>
                                <?php echo listingEscape($deadlineDisplay); ?>
                            </strong>

                        </div>


                        <!-- Apply action -->
                        <div class="student-listing-footer">

                            <?php if ($hasApplied): ?>

                                <span class="student-listing-applied">
                                    Already applied
                                </span>

                                <a
                                    href="applications.php"
                                    class="btn btn-secondary student-listing-apply-button"
                                >
                                    View Application
                                </a>

                            <?php elseif ($studentId <= 0): ?>

                                <a
                                    href="profile.php"
                                    class="btn btn-secondary student-listing-apply-button"
                                >
                                    Complete Profile
                                </a>

                            <?php else: ?>

                                <form
                                    method="POST"
                                    action="apply.php"
                                    class="student-listing-apply-form"
                                >

                                    <input
                                        type="hidden"
                                        name="csrf_token"
                                        value="<?php echo listingEscape($csrfToken); ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="internship_id"
                                        value="<?php echo $internshipId; ?>"
                                    >

                                    <button
                                        type="submit"
                                        name="apply_now"
                                        value="1"
                                        class="btn btn-primary student-listing-apply-button"
                                    >
                                        Apply Now
                                    </button>

                                </form>

                            <?php endif; ?>

                        </div>

                    </article>

                <?php endforeach; ?>

            </section>

        <?php endif; ?>

    </main>

</div>

<script src="../js/validation.js?v=4"></script>

</body>
</html>