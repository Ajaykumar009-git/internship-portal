<?php

session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];

$message = '';
$messageType = '';

/*
|--------------------------------------------------------------------------
| Get student
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare(
    "SELECT
        u.name,
        u.email,
        s.id AS student_id,
        s.phone,
        s.college,
        s.course,
        s.skills,
        s.resume
     FROM users u
     INNER JOIN students s
        ON u.id = s.user_id
     WHERE u.id = ?
     LIMIT 1"
);

$stmt->execute([$userId]);

$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$studentId = (int) $student['student_id'];


/*
|--------------------------------------------------------------------------
| Update profile
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['update_profile'])
) {

    $phone = trim($_POST['phone'] ?? '');
    $college = trim($_POST['college'] ?? '');
    $course = trim($_POST['course'] ?? '');
    $skills = trim($_POST['skills'] ?? '');

    if (strlen($phone) > 20) {

        $message = 'Phone number is too long.';
        $messageType = 'error';

    } elseif (strlen($college) > 150) {

        $message = 'College name is too long.';
        $messageType = 'error';

    } elseif (strlen($course) > 150) {

        $message = 'Course name is too long.';
        $messageType = 'error';

    } else {

        try {

            /*
            |--------------------------------------------------------------------------
            | Update student profile
            |--------------------------------------------------------------------------
            */

            $stmt = $pdo->prepare(
                "UPDATE students
                 SET
                    phone = ?,
                    college = ?,
                    course = ?,
                    skills = ?
                 WHERE id = ?
                   AND user_id = ?"
            );

            $stmt->execute([
                $phone !== '' ? $phone : null,
                $college !== '' ? $college : null,
                $course !== '' ? $course : null,
                $skills !== '' ? $skills : null,
                $studentId,
                $userId
            ]);

            $message =
                'Profile updated successfully.';

            $messageType = 'success';

            /*
            |--------------------------------------------------------------------------
            | Refresh student data
            |--------------------------------------------------------------------------
            */

            $stmt = $pdo->prepare(
                "SELECT
                    u.name,
                    u.email,
                    s.id AS student_id,
                    s.phone,
                    s.college,
                    s.course,
                    s.skills,
                    s.resume
                 FROM users u
                 INNER JOIN students s
                    ON u.id = s.user_id
                 WHERE u.id = ?
                 LIMIT 1"
            );

            $stmt->execute([$userId]);

            $student = $stmt->fetch(PDO::FETCH_ASSOC);

        } catch (PDOException $e) {

            error_log(
                'Student profile update error: '
                . $e->getMessage()
            );

            $message =
                'Unable to update your profile.';

            $messageType = 'error';
        }
    }
}


/*
|--------------------------------------------------------------------------
| Resume upload
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['upload_resume'])
) {

    if (
        !isset($_FILES['resume']) ||
        $_FILES['resume']['error'] !== UPLOAD_ERR_OK
    ) {

        $message = 'Please select a valid resume file.';
        $messageType = 'error';

    } else {

        $file = $_FILES['resume'];

        $maxSize = 5 * 1024 * 1024;

        if ($file['size'] > $maxSize) {

            $message =
                'Resume file must be 5 MB or smaller.';

            $messageType = 'error';

        } else {

            $allowedExtensions = [
                'pdf',
                'doc',
                'docx'
            ];

            $originalName =
                basename($file['name']);

            $extension =
                strtolower(
                    pathinfo(
                        $originalName,
                        PATHINFO_EXTENSION
                    )
                );

            if (!in_array(
                $extension,
                $allowedExtensions,
                true
            )) {

                $message =
                    'Only PDF, DOC and DOCX files are allowed.';

                $messageType = 'error';

            } else {

                $uploadDirectory =
                    __DIR__ . '/../uploads/resumes/';

                if (!is_dir($uploadDirectory)) {

                    mkdir(
                        $uploadDirectory,
                        0755,
                        true
                    );
                }

                /*
                |--------------------------------------------------------------------------
                | Generate safe unique filename
                |--------------------------------------------------------------------------
                */

                $safeFilename =
                    'student_'
                    . $studentId
                    . '_'
                    . bin2hex(random_bytes(8))
                    . '.'
                    . $extension;

                $destination =
                    $uploadDirectory
                    . $safeFilename;

                if (
                    move_uploaded_file(
                        $file['tmp_name'],
                        $destination
                    )
                ) {

                    /*
                    |--------------------------------------------------------------------------
                    | Remove previous resume
                    |--------------------------------------------------------------------------
                    */

                    $oldResume =
                        $student['resume'];

                    if (!empty($oldResume)) {

                        $oldFilename =
                            basename($oldResume);

                        $oldPath =
                            $uploadDirectory
                            . $oldFilename;

                        if (
                            is_file($oldPath)
                        ) {

                            unlink($oldPath);
                        }
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | Save new resume
                    |--------------------------------------------------------------------------
                    */

                    $stmt = $pdo->prepare(
                        "UPDATE students
                         SET resume = ?
                         WHERE id = ?
                           AND user_id = ?"
                    );

                    $stmt->execute([
                        $safeFilename,
                        $studentId,
                        $userId
                    ]);


                    /*
                    |--------------------------------------------------------------------------
                    | Update application resume paths
                    |--------------------------------------------------------------------------
                    |
                    | Existing applications that use the student's
                    | resume are also updated.
                    |
                    */

                    $stmt = $pdo->prepare(
                        "UPDATE applications
                         SET resume = ?
                         WHERE student_id = ?"
                    );

                    $stmt->execute([
                        $safeFilename,
                        $studentId
                    ]);


                    $student['resume'] =
                        $safeFilename;

                    $message =
                        'Resume uploaded successfully.';

                    $messageType = 'success';

                } else {

                    $message =
                        'Unable to save the resume file.';

                    $messageType = 'error';
                }
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        My Profile | Internship Portal
    </title>

    <link
        rel="stylesheet"
        href="../css/style.css"
    >
    <link rel="stylesheet" href="../css/neon-glass.css?v=4">

</head>

<body>

<div class="dashboard-page">

    <!-- Navigation -->

    <nav class="dashboard-nav">

        <div class="nav-brand">
            Internship Portal
        </div>

        <div class="nav-links">

            <a href="../index.php">
                Home
            </a>

            <a href="dashboard.php">
                Dashboard
            </a>

            <a
                href="profile.php"
                class="active"
            >
                Profile
            </a>

            <a href="internships.php">
                Internships
            </a>

            <a href="applications.php">
                Applications
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </div>

    </nav>


    <!-- Main -->

    <main class="dashboard-container">

        <section class="dashboard-header">

            <div>

                <span class="dashboard-label">
                    STUDENT PROFILE
                </span>

                <h1>
                    My Profile
                </h1>

                <p>
                    Keep your information updated for internship applications.
                </p>

            </div>

            <a
                href="dashboard.php"
                class="btn btn-secondary"
            >
                Dashboard
            </a>

        </section>


        <?php if ($message !== ''): ?>

            <div
                class="alert
                <?php
                echo $messageType === 'success'
                    ? 'alert-success'
                    : 'alert-error';
                ?>"
            >
                <?php
                echo htmlspecialchars($message);
                ?>
            </div>

        <?php endif; ?>


        <section class="profile-layout">

            <!-- Profile form -->

            <div class="dashboard-card">

                <div class="card-header">

                    <h2>
                        Personal Information
                    </h2>

                </div>


                <form
                    method="POST"
                    action=""
                    class="compact-form"
                >

                    <div class="form-grid">

                        <div class="form-group">

                            <label>
                                Full Name
                            </label>

                            <input
                                type="text"
                                value="<?php
                                echo htmlspecialchars(
                                    $student['name']
                                );
                                ?>"
                                readonly
                            >

                        </div>


                        <div class="form-group">

                            <label>
                                Email
                            </label>

                            <input
                                type="email"
                                value="<?php
                                echo htmlspecialchars(
                                    $student['email']
                                );
                                ?>"
                                readonly
                            >

                        </div>


                        <div class="form-group">

                            <label for="phone">
                                Phone
                            </label>

                            <input
                                type="text"
                                id="phone"
                                name="phone"
                                maxlength="20"
                                value="<?php
                                echo htmlspecialchars(
                                    $student['phone'] ?? ''
                                );
                                ?>"
                                placeholder="Enter phone number"
                            >

                        </div>


                        <div class="form-group">

                            <label for="college">
                                College
                            </label>

                            <input
                                type="text"
                                id="college"
                                name="college"
                                maxlength="150"
                                value="<?php
                                echo htmlspecialchars(
                                    $student['college'] ?? ''
                                );
                                ?>"
                                placeholder="Enter college name"
                            >

                        </div>


                        <div class="form-group">

                            <label for="course">
                                Course
                            </label>

                            <input
                                type="text"
                                id="course"
                                name="course"
                                maxlength="150"
                                value="<?php
                                echo htmlspecialchars(
                                    $student['course'] ?? ''
                                );
                                ?>"
                                placeholder="Example: B.E. Computer Science"
                            >

                        </div>


                        <div class="form-group form-group-full">

                            <label for="skills">
                                Skills
                            </label>

                            <textarea
                                id="skills"
                                name="skills"
                                rows="4"
                                placeholder="Example: PHP, MySQL, HTML, CSS, JavaScript"
                            ><?php
                            echo htmlspecialchars(
                                $student['skills'] ?? ''
                            );
                            ?></textarea>

                        </div>

                    </div>


                    <button
                        type="submit"
                        name="update_profile"
                        class="btn btn-primary"
                    >
                        Save Profile
                    </button>

                </form>

            </div>


            <!-- Resume -->

            <div class="dashboard-card">

                <div class="card-header">

                    <h2>
                        Resume
                    </h2>

                </div>


                <?php if (
                    !empty($student['resume'])
                ): ?>

                    <div class="resume-current">

                        <span>
                            Current Resume
                        </span>

                        <strong>
                            <?php
                            echo htmlspecialchars(
                                basename(
                                    $student['resume']
                                )
                            );
                            ?>
                        </strong>

                        <a
                            href="../uploads/resumes/<?php
                            echo rawurlencode(
                                basename(
                                    $student['resume']
                                )
                            );
                            ?>"
                            target="_blank"
                            rel="noopener noreferrer"
                            class="btn btn-secondary"
                        >
                            View Resume
                        </a>

                    </div>

                <?php else: ?>

                    <div class="empty-state compact-empty">

                        <h3>
                            No resume uploaded
                        </h3>

                        <p>
                            Upload your latest resume to use it when applying.
                        </p>

                    </div>

                <?php endif; ?>


                <form
                    method="POST"
                    action=""
                    enctype="multipart/form-data"
                    class="compact-form"
                >

                    <div class="form-group">

                        <label for="resume">
                            Upload Resume
                        </label>

                        <input
                            type="file"
                            id="resume"
                            name="resume"
                            accept=".pdf,.doc,.docx"
                            required
                        >

                        <small>
                            PDF, DOC or DOCX. Maximum 5 MB.
                        </small>

                    </div>


                    <button
                        type="submit"
                        name="upload_resume"
                        class="btn btn-primary"
                    >
                        Upload Resume
                    </button>

                </form>

            </div>

        </section>

    </main>

</div>


<script src="../js/validation.js?v=4"></script>

</body>

</html>