<?php
session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'student') {
    header('Location: ../login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];

$stmt = $pdo->prepare(
    "SELECT students.id AS id, users.name AS name
     FROM students
     INNER JOIN users ON students.user_id = users.id
     WHERE students.user_id = ?
     LIMIT 1"
);
$stmt->execute([$userId]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$studentId = (int) $student['id'];
$message = '';
$messageType = '';

if (isset($_GET['applied']) && $_GET['applied'] === '1') {
    $message = 'Your internship application was submitted successfully.';
    $messageType = 'success';
}

// Get this student's application history.
$stmt = $pdo->prepare(
    "SELECT
        a.id,
        a.status,
        a.resume,
        a.applied_at,
        a.updated_at,
        i.id AS internship_id,
        i.title,
        i.description,
        i.location,
        i.stipend,
        i.duration,
        i.deadline,
        c.company_name
     FROM applications a
     INNER JOIN internships i ON a.internship_id = i.id
     INNER JOIN companies c ON i.company_id = c.id
     WHERE a.student_id = ?
     ORDER BY a.applied_at DESC, a.id DESC"
);
$stmt->execute([$studentId]);
$applications = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Application statistics.
$stmt = $pdo->prepare(
    "SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN status = 'Under Review' THEN 1 ELSE 0 END) AS under_review,
        SUM(CASE WHEN status = 'Shortlisted' THEN 1 ELSE 0 END) AS shortlisted,
        SUM(CASE WHEN status = 'Interview' THEN 1 ELSE 0 END) AS interviews,
        SUM(CASE WHEN status = 'Selected' THEN 1 ELSE 0 END) AS selected,
        SUM(CASE WHEN status = 'Rejected' THEN 1 ELSE 0 END) AS rejected
     FROM applications
     WHERE student_id = ?"
);
$stmt->execute([$studentId]);
$stats = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

$totalApplications = (int) ($stats['total'] ?? 0);
$underReview = (int) ($stats['under_review'] ?? 0);
$shortlisted = (int) ($stats['shortlisted'] ?? 0);
$interviews = (int) ($stats['interviews'] ?? 0);
$selectedCount = (int) ($stats['selected'] ?? 0);
$rejected = (int) ($stats['rejected'] ?? 0);

function applicationDate(?string $dateValue): string
{
    if (empty($dateValue)) {
        return '—';
    }

    $timestamp = strtotime($dateValue);

    return $timestamp === false
        ? '—'
        : date('d M Y', $timestamp);
}

function applicationStatusClass(string $status): string
{
    return 'status-' . strtolower(
        trim(
            (string) preg_replace('/[^a-zA-Z0-9]+/', '-', $status),
            '-'
        )
    );
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Applications | Internship Portal</title>

    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/neon-glass.css?v=4">

    <style>
        /* Styles are limited to this page. */

        .applications-page .applications-list {
            display: grid;
            grid-template-columns: minmax(0, 1fr);
            gap: 18px;
            width: 100%;
        }

        .applications-page .application-card {
            display: block;
            width: 100%;
            min-width: 0;
            box-sizing: border-box;
            padding: clamp(18px, 2.2vw, 28px);
            border: 1px solid rgba(105, 153, 216, 0.24);
            border-radius: 18px;
            background: linear-gradient(
                135deg,
                rgba(17, 31, 53, 0.96),
                rgba(10, 20, 37, 0.96)
            );
            box-shadow: 0 12px 28px rgba(0, 0, 0, 0.14);
            overflow: hidden;
        }

        .applications-page .application-card-main {
            display: flex !important;
            align-items: flex-start;
            justify-content: space-between;
            gap: 18px;
            flex-wrap: wrap;
            margin-bottom: 22px;
        }

        .applications-page .application-title-block {
            flex: 1 1 240px;
            min-width: 0;
        }

        .applications-page .internship-company {
            display: inline-block;
            margin-bottom: 7px;
            color: #63C7FF;
            font-size: 0.8rem;
            font-weight: 700;
            letter-spacing: 0.04em;
            overflow-wrap: anywhere;
        }

        .applications-page .application-card-main h2 {
            margin: 0;
            color: #F3F6FF;
            font-size: clamp(1.25rem, 2.4vw, 1.7rem);
            line-height: 1.3;
            font-weight: 750;
            overflow-wrap: anywhere;
        }

        .applications-page .application-status {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            flex: 0 0 auto;
            min-height: 34px;
            padding: 7px 13px;
            border: 1px solid rgba(102, 199, 255, 0.32);
            border-radius: 999px;
            background: rgba(60, 156, 222, 0.14);
            color: #83D5FF;
            font-size: 0.84rem;
            font-weight: 700;
            white-space: nowrap;
        }

        .applications-page .application-status.status-under-review {
            color: #FBBF65;
            background: rgba(245, 158, 11, 0.13);
            border-color: rgba(245, 158, 11, 0.3);
        }

        .applications-page .application-status.status-shortlisted,
        .applications-page .application-status.status-selected {
            color: #6EE7B7;
            background: rgba(16, 185, 129, 0.13);
            border-color: rgba(16, 185, 129, 0.3);
        }

        .applications-page .application-status.status-interview {
            color: #C4B5FD;
            background: rgba(139, 92, 246, 0.15);
            border-color: rgba(139, 92, 246, 0.32);
        }

        .applications-page .application-status.status-rejected {
            color: #FDA4AF;
            background: rgba(244, 63, 94, 0.13);
            border-color: rgba(244, 63, 94, 0.3);
        }

        /* Put application information into separate boxes. */
        .applications-page .application-meta {
            display: grid !important;
            grid-template-columns: repeat(5, minmax(0, 1fr));
            gap: 12px;
            width: 100%;
            margin: 0;
        }

        .applications-page .application-meta-item {
            display: flex;
            flex-direction: column;
            justify-content: center;
            gap: 7px;
            min-width: 0;
            box-sizing: border-box;
            padding: 14px 15px;
            border: 1px solid rgba(115, 149, 192, 0.17);
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.035);
        }

        .applications-page .application-meta-item > span {
            color: #92A8C5;
            font-size: 0.76rem;
            font-weight: 700;
            letter-spacing: 0.035em;
            text-transform: uppercase;
        }

        .applications-page .application-meta-item > strong {
            color: #F1F5FF;
            font-size: 0.96rem;
            line-height: 1.45;
            font-weight: 650;
            overflow-wrap: anywhere;
        }

        .applications-page .application-card-actions {
            display: flex !important;
            align-items: center;
            justify-content: flex-end;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 18px;
            padding-top: 16px;
            border-top: 1px solid rgba(115, 149, 192, 0.17);
        }

        .applications-page .application-card-actions .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 42px;
            padding: 10px 17px;
            border-radius: 10px;
            text-decoration: none;
        }

        .applications-page .empty-state {
            padding: 34px 20px;
            text-align: center;
        }

        .applications-page .empty-state h3 {
            margin-top: 0;
        }

        /* Tablet screens */
        @media (max-width: 1100px) {
            .applications-page .application-meta {
                grid-template-columns: repeat(3, minmax(0, 1fr));
            }
        }

        /* Mobile screens */
        @media (max-width: 700px) {
            .applications-page .application-meta {
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 9px;
            }

            .applications-page .application-meta-item {
                padding: 12px;
            }

            .applications-page .application-card-main {
                gap: 12px;
                margin-bottom: 16px;
            }

            .applications-page .application-card-actions {
                justify-content: stretch;
            }

            .applications-page .application-card-actions .btn {
                flex: 1 1 150px;
            }
        }

        @media (max-width: 420px) {
            .applications-page .application-meta {
                grid-template-columns: minmax(0, 1fr);
            }

            .applications-page .application-status {
                white-space: normal;
            }
        }
    </style>
</head>

<body>
<div class="dashboard-page applications-page">

    <!-- Navigation -->
    <nav class="dashboard-nav">
        <div class="nav-brand">Internship Portal</div>

        <div class="nav-links">
            <a href="../index.php">Home</a>
            <a href="dashboard.php">Dashboard</a>
            <a href="profile.php">Profile</a>
            <a href="internships.php">Internships</a>
            <a href="applications.php" class="active">Applications</a>
            <a href="../logout.php">Logout</a>
        </div>
    </nav>

    <main class="dashboard-container">

        <!-- Page heading -->
        <section class="dashboard-header">
            <div>
                <span class="dashboard-label">APPLICATION TRACKING</span>
                <h1>My Applications</h1>
                <p>Track the current status of your internship applications.</p>
            </div>

            <a href="internships.php" class="btn btn-primary">
                Find Internships
            </a>
        </section>

        <!-- Success message -->
        <?php if ($message !== ''): ?>
            <div class="alert <?php echo $messageType === 'success' ? 'alert-success' : 'alert-error'; ?>">
                <?php
                echo htmlspecialchars(
                    $message,
                    ENT_QUOTES,
                    'UTF-8'
                );
                ?>
            </div>
        <?php endif; ?>

        <!-- Application statistics -->
        <section class="stats-grid">

            <div class="stat-card">
                <span class="stat-label">TOTAL</span>
                <strong class="stat-number">
                    <?php echo $totalApplications; ?>
                </strong>
            </div>

            <div class="stat-card">
                <span class="stat-label">UNDER REVIEW</span>
                <strong class="stat-number">
                    <?php echo $underReview; ?>
                </strong>
            </div>

            <div class="stat-card">
                <span class="stat-label">SHORTLISTED</span>
                <strong class="stat-number">
                    <?php echo $shortlisted; ?>
                </strong>
            </div>

            <div class="stat-card">
                <span class="stat-label">INTERVIEW</span>
                <strong class="stat-number">
                    <?php echo $interviews; ?>
                </strong>
            </div>

            <div class="stat-card">
                <span class="stat-label">SELECTED</span>
                <strong class="stat-number">
                    <?php echo $selectedCount; ?>
                </strong>
            </div>

            <div class="stat-card">
                <span class="stat-label">REJECTED</span>
                <strong class="stat-number">
                    <?php echo $rejected; ?>
                </strong>
            </div>

        </section>

        <!-- Application History -->
        <section class="dashboard-card">

            <div class="card-header">
                <h2>Application History</h2>
                <span>
                    <?php echo $totalApplications; ?> application(s)
                </span>
            </div>

            <?php if (empty($applications)): ?>

                <div class="empty-state">
                    <h3>No applications yet</h3>
                    <p>You have not applied for any internships yet.</p>

                    <a href="internships.php" class="btn btn-primary">
                        Browse Internships
                    </a>
                </div>

            <?php else: ?>

                <div class="applications-list">

                    <?php foreach ($applications as $application): ?>

                        <article class="application-card">

                            <!-- Internship title and status -->
                            <div class="application-card-main">

                                <div class="application-title-block">

                                    <span class="internship-company">
                                        <?php
                                        echo htmlspecialchars(
                                            (string) $application['company_name'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        );
                                        ?>
                                    </span>

                                    <h2>
                                        <?php
                                        echo htmlspecialchars(
                                            (string) $application['title'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        );
                                        ?>
                                    </h2>

                                </div>

                                <span class="application-status <?php
                                    echo htmlspecialchars(
                                        applicationStatusClass(
                                            (string) ($application['status'] ?? 'Applied')
                                        ),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    );
                                ?>">
                                    <?php
                                    echo htmlspecialchars(
                                        (string) ($application['status'] ?? 'Applied'),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    );
                                    ?>
                                </span>

                            </div>

                            <!-- Details displayed in separate boxes -->
                            <div class="application-meta">

                                <div class="application-meta-item">
                                    <span>Location</span>
                                    <strong>
                                        <?php
                                        echo htmlspecialchars(
                                            (string) ($application['location'] ?: 'Not specified'),
                                            ENT_QUOTES,
                                            'UTF-8'
                                        );
                                        ?>
                                    </strong>
                                </div>

                                <div class="application-meta-item">
                                    <span>Stipend</span>
                                    <strong>
                                        ₹<?php
                                        echo number_format(
                                            (float) ($application['stipend'] ?? 0),
                                            2
                                        );
                                        ?>
                                    </strong>
                                </div>

                                <div class="application-meta-item">
                                    <span>Duration</span>
                                    <strong>
                                        <?php
                                        echo htmlspecialchars(
                                            (string) ($application['duration'] ?: 'Not specified'),
                                            ENT_QUOTES,
                                            'UTF-8'
                                        );
                                        ?>
                                    </strong>
                                </div>

                                <div class="application-meta-item">
                                    <span>Applied on</span>
                                    <strong>
                                        <?php
                                        echo htmlspecialchars(
                                            applicationDate($application['applied_at'] ?? null),
                                            ENT_QUOTES,
                                            'UTF-8'
                                        );
                                        ?>
                                    </strong>
                                </div>

                                <div class="application-meta-item">
                                    <span>Last updated</span>
                                    <strong>
                                        <?php
                                        echo htmlspecialchars(
                                            applicationDate($application['updated_at'] ?? null),
                                            ENT_QUOTES,
                                            'UTF-8'
                                        );
                                        ?>
                                    </strong>
                                </div>

                            </div>

                            <!-- Action buttons -->
                            <div class="application-card-actions">

                                <?php if (!empty($application['resume'])): ?>

                                    <a
                                        href="../uploads/resumes/<?php
                                            echo rawurlencode(
                                                basename((string) $application['resume'])
                                            );
                                        ?>"
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        class="btn btn-secondary"
                                    >
                                        View Resume
                                    </a>

                                <?php endif; ?>

                                <a href="internships.php" class="btn btn-secondary">
                                    Browse More
                                </a>

                            </div>

                        </article>

                    <?php endforeach; ?>

                </div>

            <?php endif; ?>

        </section>

        <!-- Application Workflow -->
        <section class="dashboard-card">

            <div class="card-header">
                <h2>Application Workflow</h2>
            </div>

            <div class="workflow">

                <div class="workflow-step">
                    <span>01</span>
                    <strong>Applied</strong>
                </div>

                <div class="workflow-line"></div>

                <div class="workflow-step">
                    <span>02</span>
                    <strong>Under Review</strong>
                </div>

                <div class="workflow-line"></div>

                <div class="workflow-step">
                    <span>03</span>
                    <strong>Shortlisted</strong>
                </div>

                <div class="workflow-line"></div>

                <div class="workflow-step">
                    <span>04</span>
                    <strong>Interview</strong>
                </div>

                <div class="workflow-line"></div>

                <div class="workflow-step">
                    <span>05</span>
                    <strong>Selected</strong>
                </div>

            </div>

        </section>

    </main>
</div>

<script src="../js/validation.js?v=4"></script>
</body>
</html>