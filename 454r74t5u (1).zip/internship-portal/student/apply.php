<?php
session_start();

require_once __DIR__ . '/../config/database.php';

if (
    !isset($_SESSION['user_id']) ||
    ($_SESSION['role'] ?? '') !== 'student'
) {
    header('Location: ../login.php');
    exit;
}

function studentApplyEscape($value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Shared CSRF token
|--------------------------------------------------------------------------
*/
if (empty($_SESSION['student_apply_csrf'])) {
    $_SESSION['student_apply_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['student_apply_csrf'];
$userId = (int) $_SESSION['user_id'];

$message = '';
$messageType = 'info';
$student = null;
$internship = null;
$internshipId = 0;
$alreadyApplied = false;
$canApply = false;

/*
|--------------------------------------------------------------------------
| Load the student's database profile using user_id
|--------------------------------------------------------------------------
*/
try {
    $stmt = $pdo->prepare(
        'SELECT id, resume
         FROM students
         WHERE user_id = ?
         LIMIT 1'
    );

    $stmt->execute([$userId]);
    $student = $stmt->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log('Apply page student lookup error: ' . $e->getMessage());

    http_response_code(500);
    exit('Unable to load your student profile. Please try again later.');
}

if (!$student) {
    $message = 'Your student profile was not found. Please complete your profile before applying.';
    $messageType = 'error';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $_SESSION['student_portal_flash'] = [
            'message' => $message,
            'type' => 'warning'
        ];

        header('Location: internships.php');
        exit;
    }
}

/*
|--------------------------------------------------------------------------
| Process an application submission
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $submittedToken = (string) ($_POST['csrf_token'] ?? '');

    $postedId = filter_var(
        $_POST['internship_id'] ?? null,
        FILTER_VALIDATE_INT
    );

    if (!$student) {
        // The profile warning is already set above.

    } elseif (
        $submittedToken === '' ||
        !hash_equals($csrfToken, $submittedToken)
    ) {
        $message = 'Your request could not be verified. Return to internships and try again.';
        $messageType = 'error';

    } elseif (!$postedId || $postedId < 1) {
        $message = 'Invalid internship selected.';
        $messageType = 'error';

    } else {
        $internshipId = (int) $postedId;

        try {
            $pdo->beginTransaction();

            /*
             * Lock the selected internship and verify it still exists.
             */
            $stmt = $pdo->prepare(
                'SELECT id, title, deadline
                 FROM internships
                 WHERE id = ?
                 FOR UPDATE'
            );

            $stmt->execute([$internshipId]);

            $selectedInternship = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$selectedInternship) {
                $pdo->rollBack();

                $message = 'This internship no longer exists.';
                $messageType = 'error';

            } else {
                $deadlineTime = !empty($selectedInternship['deadline'])
                    ? strtotime((string) $selectedInternship['deadline'])
                    : false;

                if (
                    $deadlineTime !== false &&
                    $deadlineTime < strtotime('today')
                ) {
                    $pdo->rollBack();

                    $message = 'The application deadline for this internship has passed.';
                    $messageType = 'error';

                } else {
                    /*
                     * Prevent duplicate applications.
                     */
                    $stmt = $pdo->prepare(
                        'SELECT 1
                         FROM applications
                         WHERE internship_id = ?
                           AND student_id = ?
                         LIMIT 1'
                    );

                    $stmt->execute([
                        $internshipId,
                        (int) $student['id']
                    ]);

                    if ($stmt->fetchColumn()) {
                        $pdo->rollBack();

                        $_SESSION['student_portal_flash'] = [
                            'message' => 'You have already applied for this internship.',
                            'type' => 'info'
                        ];

                        header('Location: internships.php');
                        exit;
                    }

                    /*
                     * Inspect the existing applications table.
                     * Use only known, supported columns.
                     */
                    $stmt = $pdo->query('SHOW COLUMNS FROM applications');

                    $columnRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

                    $availableColumns = [];

                    foreach ($columnRows as $columnRow) {
                        $availableColumns[
                            (string) $columnRow['Field']
                        ] = true;
                    }

                    if (
                        !isset($availableColumns['internship_id']) ||
                        !isset($availableColumns['student_id']) ||
                        !isset($availableColumns['status'])
                    ) {
                        throw new RuntimeException(
                            'The applications table is missing a required column.'
                        );
                    }

                    /*
                     * Construct an insert for columns available in this
                     * schema. Column names come only from this fixed allowlist.
                     */
                    $insertColumns = [
                        'internship_id',
                        'student_id',
                        'status'
                    ];

                    $insertValues = [
                        '?',
                        '?',
                        '?'
                    ];

                    $insertParams = [
                        $internshipId,
                        (int) $student['id'],
                        'Applied'
                    ];

                    if (isset($availableColumns['resume'])) {
                        $insertColumns[] = 'resume';
                        $insertValues[] = '?';

                        $insertParams[] = (string) (
                            $student['resume'] ?? ''
                        );
                    }

                    if (isset($availableColumns['applied_at'])) {
                        $insertColumns[] = 'applied_at';
                        $insertValues[] = 'CURRENT_TIMESTAMP';
                    }

                    if (isset($availableColumns['updated_at'])) {
                        $insertColumns[] = 'updated_at';
                        $insertValues[] = 'CURRENT_TIMESTAMP';
                    }

                    $quotedColumns = array_map(
                        static function ($column) {
                            return '`' . $column . '`';
                        },
                        $insertColumns
                    );

                    $insertSql =
                        'INSERT INTO applications (' .
                        implode(', ', $quotedColumns) .
                        ') VALUES (' .
                        implode(', ', $insertValues) .
                        ')';

                    $stmt = $pdo->prepare($insertSql);
                    $stmt->execute($insertParams);

                    $pdo->commit();

                    $_SESSION['student_portal_flash'] = [
                        'message' => 'Application submitted successfully!',
                        'type' => 'success'
                    ];

                    header('Location: internships.php');
                    exit;
                }
            }

        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log('Student application submission error: ' . $e->getMessage());

            // A unique constraint can catch a duplicate submitted concurrently.
            if ($e->getCode() === '23000') {
                $message = 'You may have already applied for this internship. Check My Applications.';
                $messageType = 'info';
            } else {
                $message = 'Unable to submit your application. Please try again later.';
                $messageType = 'error';
            }

        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log('Student application processing error: ' . $e->getMessage());

            $message = 'An unexpected error occurred while applying. Please try again later.';
            $messageType = 'error';
        }
    }

    /*
     * Return to the listing with a friendly message after a failed request.
     */
    if ($message !== '') {
        $_SESSION['student_portal_flash'] = [
            'message' => $message,
            'type' => $messageType
        ];

        header('Location: internships.php');
        exit;
    }
}

/*
|--------------------------------------------------------------------------
| Load internship details for the confirmation screen (GET)
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    $requestedId = filter_var(
        $_GET['id'] ?? $_GET['internship_id'] ?? null,
        FILTER_VALIDATE_INT
    );

    if (!$requestedId || $requestedId < 1) {
        $message = 'Please select an internship from the Internships page.';
        $messageType = 'error';

    } else {
        $internshipId = (int) $requestedId;

        try {
            $stmt = $pdo->prepare(
                'SELECT
                    i.id,
                    i.title,
                    i.description,
                    i.skills_required,
                    i.location,
                    i.stipend,
                    i.duration,
                    i.deadline,
                    i.created_at,
                    c.company_name
                 FROM internships AS i
                 LEFT JOIN companies AS c
                    ON c.id = i.company_id
                 WHERE i.id = ?
                 LIMIT 1'
            );

            $stmt->execute([$internshipId]);

            $internship = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$internship) {
                http_response_code(404);

                $message = 'This internship could not be found.';
                $messageType = 'error';

            } elseif ($student) {
                $stmt = $pdo->prepare(
                    'SELECT 1
                     FROM applications
                     WHERE internship_id = ?
                       AND student_id = ?
                     LIMIT 1'
                );

                $stmt->execute([
                    $internshipId,
                    (int) $student['id']
                ]);

                $alreadyApplied = (bool) $stmt->fetchColumn();

                $deadlineTime = !empty($internship['deadline'])
                    ? strtotime((string) $internship['deadline'])
                    : false;

                $isExpired = (
                    $deadlineTime !== false &&
                    $deadlineTime < strtotime('today')
                );

                if ($alreadyApplied) {
                    $message = 'You have already applied for this internship.';
                    $messageType = 'info';

                } elseif ($isExpired) {
                    $message = 'The application deadline for this internship has passed.';
                    $messageType = 'error';

                } else {
                    $canApply = true;
                }
            }

        } catch (PDOException $e) {
            error_log('Apply page internship lookup error: ' . $e->getMessage());

            http_response_code(500);

            $message = 'Unable to load internship details. Please try again later.';
            $messageType = 'error';
        }
    }
}

$companyName = trim(
    (string) ($internship['company_name'] ?? '')
);

if ($companyName === '') {
    $companyName = 'Company';
}

$rawStipend = trim(
    (string) ($internship['stipend'] ?? '')
);

if ($rawStipend !== '' && is_numeric($rawStipend)) {
    $amount = (float) $rawStipend;

    $stipendDisplay = $amount > 0
        ? '₹' . number_format($amount, 2)
        : 'Unpaid';
} else {
    $stipendDisplay = $rawStipend !== ''
        ? $rawStipend
        : 'Not specified';
}

$deadlineTime = !empty($internship['deadline'])
    ? strtotime((string) $internship['deadline'])
    : false;

$deadlineDisplay = $deadlineTime !== false
    ? date('d M Y', $deadlineTime)
    : 'Not specified';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Apply for Internship | Internship Portal</title>

    <link
        rel="stylesheet"
        href="../css/style.css?v=<?php
            echo (int) @filemtime(__DIR__ . '/../css/style.css');
        ?>"
    >
    <link rel="stylesheet" href="../css/neon-glass.css?v=4">
</head>

<body>

<div class="dashboard-page student-apply-page">

    <nav class="dashboard-nav">

        <a class="nav-brand" href="../index.php">
            Internship Portal
        </a>

        <div class="nav-links">
            <a href="../index.php">Home</a>
            <a href="dashboard.php">Dashboard</a>
            <a href="profile.php">Profile</a>
            <a href="internships.php" class="active">Internships</a>
            <a href="applications.php">My Applications</a>
            <a href="../logout.php">Logout</a>
        </div>

    </nav>


    <main class="dashboard-container">

        <section class="dashboard-header student-apply-hero">

            <div>
                <span class="dashboard-label">APPLICATION CENTER</span>

                <h1>Apply for Internship</h1>

                <p>
                    Review the opportunity details before submitting
                    your application.
                </p>
            </div>

            <a
                href="internships.php"
                class="btn btn-secondary"
            >
                Back to Internships
            </a>

        </section>


        <?php if ($message !== ''): ?>

            <div
                class="alert <?php
                    echo $messageType === 'success'
                        ? 'alert-success'
                        : (
                            $messageType === 'warning'
                                ? 'alert-warning'
                                : (
                                    $messageType === 'info'
                                        ? 'alert-info'
                                        : 'alert-error'
                                )
                        );
                ?>"
                role="status"
            >
                <?php echo studentApplyEscape($message); ?>
            </div>

        <?php endif; ?>


        <?php if ($internship): ?>

            <section class="student-apply-layout">

                <article class="dashboard-card student-apply-details">

                    <div class="student-apply-company">
                        <div class="student-company-mark" aria-hidden="true">
                            <?php
                            echo studentApplyEscape(
                                strtoupper(substr($companyName, 0, 1))
                            );
                            ?>
                        </div>

                        <div>
                            <span class="student-company-name">
                                <?php echo studentApplyEscape($companyName); ?>
                            </span>

                            <span class="student-posted-date">
                                Internship opportunity
                            </span>
                        </div>
                    </div>


                    <h2 class="student-apply-title">
                        <?php
                        echo studentApplyEscape($internship['title']);
                        ?>
                    </h2>


                    <div class="student-apply-description">
                        <?php
                        echo nl2br(
                            studentApplyEscape($internship['description'])
                        );
                        ?>
                    </div>


                    <?php if (!empty($internship['skills_required'])): ?>

                        <div class="student-skills-section">
                            <span class="student-meta-label">
                                SKILLS REQUIRED
                            </span>

                            <div class="student-skill-list">

                                <?php
                                $skills = preg_split(
                                    '/[,;]+/',
                                    (string) $internship['skills_required'],
                                    -1,
                                    PREG_SPLIT_NO_EMPTY
                                );
                                ?>

                                <?php foreach (array_slice($skills ?: [], 0, 20) as $skill): ?>

                                    <span class="student-skill-tag">
                                        <?php echo studentApplyEscape(trim($skill)); ?>
                                    </span>

                                <?php endforeach; ?>

                            </div>
                        </div>

                    <?php endif; ?>


                    <div class="student-apply-facts">

                        <div class="student-apply-fact">
                            <span>LOCATION</span>
                            <strong>
                                <?php
                                echo studentApplyEscape(
                                    $internship['location'] ?? 'Not specified'
                                );
                                ?>
                            </strong>
                        </div>

                        <div class="student-apply-fact">
                            <span>STIPEND</span>
                            <strong>
                                <?php echo studentApplyEscape($stipendDisplay); ?>
                            </strong>
                        </div>

                        <div class="student-apply-fact">
                            <span>DURATION</span>
                            <strong>
                                <?php
                                echo studentApplyEscape(
                                    $internship['duration'] ?? 'Not specified'
                                );
                                ?>
                            </strong>
                        </div>

                        <div class="student-apply-fact">
                            <span>DEADLINE</span>
                            <strong>
                                <?php echo studentApplyEscape($deadlineDisplay); ?>
                            </strong>
                        </div>

                    </div>

                </article>


                <aside class="dashboard-card student-apply-confirmation">

                    <span class="dashboard-label">READY TO APPLY?</span>

                    <h2>Submit Your Application</h2>

                    <p>
                        Check the internship details carefully.
                        Once submitted, you can track your application
                        status from My Applications.
                    </p>


                    <?php if ($alreadyApplied): ?>

                        <div class="student-apply-status">
                            You have already applied for this internship.
                        </div>

                        <a
                            href="applications.php"
                            class="btn btn-primary student-submit-application"
                        >
                            View My Applications
                        </a>

                    <?php elseif ($canApply && $student): ?>

                        <form method="POST" action="apply.php">

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?php echo studentApplyEscape($csrfToken); ?>"
                            >

                            <input
                                type="hidden"
                                name="internship_id"
                                value="<?php echo $internshipId; ?>"
                            >

                            <button
                                type="submit"
                                name="apply_now"
                                value="1"
                                class="btn btn-primary student-submit-application"
                            >
                                Confirm and Apply
                            </button>

                        </form>

                        <p class="student-apply-note">
                            Duplicate applications are not allowed.
                        </p>

                    <?php else: ?>

                        <a
                            href="internships.php"
                            class="btn btn-secondary student-submit-application"
                        >
                            Return to Internships
                        </a>

                    <?php endif; ?>

                </aside>

            </section>

        <?php else: ?>

            <section class="dashboard-card student-apply-missing">

                <h2>Internship unavailable</h2>

                <p>
                    Open the Internships page and select an available
                    opportunity to continue.
                </p>

                <a
                    href="internships.php"
                    class="btn btn-primary"
                >
                    Browse Internships
                </a>

            </section>

        <?php endif; ?>

    </main>

</div>

<script src="../js/validation.js?v=4"></script>

</body>
</html>