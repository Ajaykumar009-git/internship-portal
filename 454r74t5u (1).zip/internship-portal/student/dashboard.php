<?php
session_start();

require_once __DIR__ . '/../config/database.php';

/*
|--------------------------------------------------------------------------
| 1. Authentication
|--------------------------------------------------------------------------
*/
$sessionRole = strtolower(
    trim((string) ($_SESSION['role'] ?? ''))
);

if (
    !isset($_SESSION['user_id']) ||
    $sessionRole !== 'student'
) {
    header('Location: ../login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];

/*
|--------------------------------------------------------------------------
| 2. CSRF token
|--------------------------------------------------------------------------
*/
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/*
|--------------------------------------------------------------------------
| 3. Fetch student profile
|--------------------------------------------------------------------------
*/
$stmt = $pdo->prepare(
    "SELECT
        u.name,
        u.email,
        s.id AS student_id,
        s.phone,
        s.college,
        s.course,
        s.skills,
        s.resume
     FROM users u
     INNER JOIN students s ON s.user_id = u.id
     WHERE u.id = :user_id
     LIMIT 1"
);

$stmt->execute(['user_id' => $userId]);

$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    http_response_code(404);
    exit(
        'Student profile not found. Please contact the administrator.'
    );
}

$studentId = (int) $student['student_id'];

/*
|--------------------------------------------------------------------------
| 4. Application statistics
|--------------------------------------------------------------------------
*/
$stmt = $pdo->prepare(
    "SELECT
        COUNT(*) AS total_applications,
        COALESCE(
            SUM(status = 'Shortlisted'),
            0
        ) AS shortlisted,
        COALESCE(
            SUM(status = 'Interview'),
            0
        ) AS interviews,
        COALESCE(
            SUM(status = 'Selected'),
            0
        ) AS selected
     FROM applications
     WHERE student_id = :student_id"
);

$stmt->execute(['student_id' => $studentId]);

$stats = $stmt->fetch(PDO::FETCH_ASSOC);

$totalApplications = (int) ($stats['total_applications'] ?? 0);
$shortlisted = (int) ($stats['shortlisted'] ?? 0);
$interviews = (int) ($stats['interviews'] ?? 0);
$selected = (int) ($stats['selected'] ?? 0);

/*
|--------------------------------------------------------------------------
| 5. Available internships
|--------------------------------------------------------------------------
*/
$stmt = $pdo->query(
    "SELECT COUNT(*)
     FROM internships
     WHERE deadline IS NULL
        OR deadline >= CURDATE()"
);

$availableInternships = (int) $stmt->fetchColumn();

/*
|--------------------------------------------------------------------------
| 6. Recent applications
|--------------------------------------------------------------------------
*/
$stmt = $pdo->prepare(
    "SELECT
        a.id,
        a.status,
        a.applied_at,
        i.title,
        i.location,
        i.stipend,
        i.duration,
        c.company_name
     FROM applications a
     INNER JOIN internships i
        ON i.id = a.internship_id
     INNER JOIN companies c
        ON c.id = i.company_id
     WHERE a.student_id = :student_id
     ORDER BY a.applied_at DESC, a.id DESC
     LIMIT 5"
);

$stmt->execute(['student_id' => $studentId]);

$recentApplications = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| 7. Calculate profile completion
|--------------------------------------------------------------------------
*/
$profileFields = [
    $student['phone'],
    $student['college'],
    $student['course'],
    $student['skills'],
    $student['resume']
];

$completedFields = 0;

foreach ($profileFields as $field) {
    if (trim((string) $field) !== '') {
        $completedFields++;
    }
}

$totalProfileFields = count($profileFields);

$profileCompletion = $totalProfileFields > 0
    ? (int) round(
        ($completedFields / $totalProfileFields) * 100
    )
    : 0;

/*
|--------------------------------------------------------------------------
| 8. Safe HTML output
|--------------------------------------------------------------------------
*/
function studentDashboardEscape(mixed $value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| 9. Application status styling
|--------------------------------------------------------------------------
*/
function studentDashboardStatusClass(string $status): string
{
    return match ($status) {
        'Applied'      => 'status-applied',
        'Under Review' => 'status-review',
        'Shortlisted'  => 'status-shortlisted',
        'Interview'    => 'status-interview',
        'Selected'     => 'status-selected',
        'Rejected'     => 'status-rejected',
        default        => 'status-applied',
    };
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta name="theme-color" content="#070b14">

    <title>Student Dashboard | Internship Portal</title>

    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/neon-glass.css?v=4">

    <script src="../js/validation.js?v=4" defer></script>

    <style>
        /* Dashboard-specific refinements */

        .dashboard-header {
            gap: 24px;
        }

        .dashboard-header .btn {
            flex-shrink: 0;
        }

        .profile-summary {
            margin-top: 18px;
        }

        .profile-summary > div {
            overflow-wrap: anywhere;
        }

        .profile-progress {
            margin-bottom: 14px;
        }
        .application-status {
            display: inline-block;
            padding: 6px 10px;
            border: 1px solid transparent;
            border-radius: 999px;
            font-size: 10px;
            font-weight: 750;
            white-space: nowrap;
        }

        .status-applied {
            color: #8bdcff;
            background: rgba(66, 186, 255, 0.10);
            border-color: rgba(66, 186, 255, 0.27);
        }

        .status-review {
            color: #ffd166;
            background: rgba(255, 209, 102, 0.10);
            border-color: rgba(255, 209, 102, 0.27);
        }

        .status-shortlisted {
            color: #c8a4ff;
            background: rgba(161, 107, 255, 0.11);
            border-color: rgba(161, 107, 255, 0.30);
        }

        .status-interview {
            color: #ff86c2;
            background: rgba(255, 77, 166, 0.10);
            border-color: rgba(255, 77, 166, 0.27);
        }

        .status-selected {
            color: #48f0b3;
            background: rgba(72, 240, 179, 0.10);
            border-color: rgba(72, 240, 179, 0.27);
        }

        .status-rejected {
            color: #ff8497;
            background: rgba(255, 100, 141, 0.10);
            border-color: rgba(255, 100, 141, 0.27);
        }

        .dashboard-logout {
            display: inline-block;
            margin: 0;
        }

        .dashboard-logout button {
            padding: 10px 14px;
            border: 1px solid transparent;
            border-radius: 10px;
            background: transparent;
            color: var(--text-soft);
            font: inherit;
            font-size: 13px;
            font-weight: 650;
            cursor: pointer;
            transition: all .28s ease;
        }

        .dashboard-logout button:hover {
            color: var(--red-bright);
            border-color: var(--border-red);
            background: rgba(255, 77, 166, 0.06);
        }

        @media (max-width: 700px) {
            .dashboard-header .btn {
                width: 100%;
                text-align: center;
            }

            .data-table {
                min-width: 700px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: .01ms !important;
                transition-duration: .01ms !important;
            }
        }
    </style>
</head>

<body>

<div class="dashboard-page">

    <!-- Navigation -->

    <header class="dashboard-nav">

        <a href="../index.php" class="nav-brand">
            <span class="brand-mark">IP</span>
            Internship Portal
        </a>

        <nav class="nav-links" aria-label="Main navigation">

            <a href="../index.php">Home</a>

            <a href="dashboard.php" class="active">
                Dashboard
            </a>

            <a href="profile.php">
                Profile
            </a>

            <a href="internships.php">
                Internships
            </a>

            <a href="applications.php">
                Applications
            </a>

            <form
                action="../logout.php"
                method="POST"
                class="dashboard-logout"
            >
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= studentDashboardEscape(
                        $_SESSION['csrf_token']
                    ) ?>"
                >

                <button type="submit">
                    Logout
                </button>
            </form>

        </nav>

    </header>

    <main class="dashboard-container">

        <!-- Welcome banner -->

        <section class="dashboard-header">

            <div>
                <span class="dashboard-label">
                    STUDENT CONTROL CENTER
                </span>

                <h1>
                    Welcome,
                    <?= studentDashboardEscape($student['name']) ?>
                </h1>

                <p>
                    Discover opportunities, manage your profile,
                    and track your internship applications.
                </p>
            </div>

            <a href="internships.php" class="btn btn-primary">
                Find Internships
            </a>

        </section>

        <!-- Statistics -->

        <section class="stats-grid" aria-label="Application statistics">

            <article class="stat-card blue">
                <span class="stat-label">
                    TOTAL APPLICATIONS
                </span>

                <strong class="stat-number">
                    <?= $totalApplications ?>
                </strong>
            </article>

            <article class="stat-card red">
                <span class="stat-label">
                    SHORTLISTED
                </span>

                <strong class="stat-number">
                    <?= $shortlisted ?>
                </strong>
            </article>

            <article class="stat-card yellow">
                <span class="stat-label">
                    INTERVIEWS
                </span>

                <strong class="stat-number">
                    <?= $interviews ?>
                </strong>
            </article>

            <article class="stat-card green">
                <span class="stat-label">
                    SELECTED
                </span>

                <strong class="stat-number">
                    <?= $selected ?>
                </strong>
            </article>

        </section>

        <!-- Profile and opportunities -->

        <section class="dashboard-grid">

            <!-- Profile card -->

            <article class="dashboard-card">

                <div class="card-header">
                    <h2>My Profile</h2>

                    <a href="profile.php" class="card-link">
                        Edit Profile
                    </a>
                </div>

                <div class="profile-progress">
                    <div
                        class="profile-progress-bar"
                        role="progressbar"
                        aria-label="Profile completion"
                        aria-valuenow="<?= $profileCompletion ?>"
                        aria-valuemin="0"
                        aria-valuemax="100"
                    ></div>
                </div>

                <p>
                    Profile completion:
                    <strong><?= $profileCompletion ?>%</strong>
                </p>

                <div class="profile-summary">

                    <div>
                        <span>Name</span>
                        <strong>
                            <?= studentDashboardEscape(
                                $student['name']
                            ) ?>
                        </strong>
                    </div>

                    <div>
                        <span>Email</span>
                        <strong>
                            <?= studentDashboardEscape(
                                $student['email']
                            ) ?>
                        </strong>
                    </div>

                    <div>
                        <span>College</span>
                        <strong>
                            <?= studentDashboardEscape(
                                $student['college'] ?: 'Not added'
                            ) ?>
                        </strong>
                    </div>

                    <div>
                        <span>Course</span>
                        <strong>
                            <?= studentDashboardEscape(
                                $student['course'] ?: 'Not added'
                            ) ?>
                        </strong>
                    </div>

                    <div>
                        <span>Phone</span>
                        <strong>
                            <?= studentDashboardEscape(
                                $student['phone'] ?: 'Not added'
                            ) ?>
                        </strong>
                    </div>

                    <div>
                        <span>Skills</span>
                        <strong>
                            <?= studentDashboardEscape(
                                $student['skills'] ?: 'Not added'
                            ) ?>
                        </strong>
                    </div>

                    <div>
                        <span>Resume</span>
                        <strong>
                            <?= !empty($student['resume'])
                                ? 'Uploaded'
                                : 'Not uploaded' ?>
                        </strong>
                    </div>

                </div>

                <a href="profile.php" class="btn btn-secondary">
                    Update Profile
                </a>

            </article>

            <!-- Opportunities card -->

            <article class="dashboard-card">

                <div class="card-header">
                    <h2>Internship Opportunities</h2>
                </div>

                <div class="opportunity-number">
                    <?= $availableInternships ?>
                </div>

                <p>
                    Opportunities currently available for you to explore.
                    Find internships that match your interests and skills.
                </p>

                <a
                    href="internships.php"
                    class="btn btn-primary"
                    style="margin-top: 18px;"
                >
                    Explore Internships
                </a>

                <div class="profile-summary" style="margin-top: 22px;">

                    <div>
                        <span>My applications</span>
                        <strong><?= $totalApplications ?></strong>
                    </div>

                    <div>
                        <span>Awaiting review</span>
                        <strong>
                            <?php
                            $underReviewCount = 0;

                            // This count is derived from the status totals below.
                            // A separate query is used for accuracy.
                            $reviewStmt = $pdo->prepare(
                                "SELECT COUNT(*)
                                 FROM applications
                                 WHERE student_id = ?
                                   AND status IN (
                                       'Applied',
                                       'Under Review'
                                   )"
                            );

                            $reviewStmt->execute([$studentId]);

                            $underReviewCount = (int) $reviewStmt->fetchColumn();

                            echo $underReviewCount;
                            ?>
                        </strong>
                    </div>

                </div>

            </article>

        </section>

        <!-- Recent applications -->

        <section class="dashboard-card" style="margin-top: 20px;">

            <div class="card-header">
                <h2>Recent Applications</h2>

                <a href="applications.php" class="card-link">
                    View All
                </a>
            </div>

            <?php if (empty($recentApplications)): ?>

                <div class="empty-state">
                    <h3>No applications yet</h3>

                    <p>
                        Explore internships and apply for opportunities
                        that match your skills.
                    </p>

                    <a href="internships.php" class="btn btn-primary">
                        Browse Internships
                    </a>
                </div>

            <?php else: ?>

                <div class="table-wrapper">

                    <table class="data-table">

                        <thead>
                            <tr>
                                <th>Internship</th>
                                <th>Company</th>
                                <th>Location</th>
                                <th>Stipend</th>
                                <th>Applied On</th>
                                <th>Status</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php foreach ($recentApplications as $application): ?>

                            <tr>
                                <td>
                                    <strong>
                                        <?= studentDashboardEscape(
                                            $application['title']
                                        ) ?>
                                    </strong>

                                    <small>
                                        <?= studentDashboardEscape(
                                            $application['duration']
                                            ?: 'Duration not specified'
                                        ) ?>
                                    </small>
                                </td>

                                <td>
                                    <?= studentDashboardEscape(
                                        $application['company_name']
                                    ) ?>
                                </td>

                                <td>
                                    <?= studentDashboardEscape(
                                        $application['location']
                                        ?: 'Not specified'
                                    ) ?>
                                </td>

                                <td>
                                    ₹<?= number_format(
                                        (float) $application['stipend'],
                                        2
                                    ) ?>
                                </td>

                                <td>
                                    <?php
                                    if (!empty($application['applied_at'])) {
                                        echo studentDashboardEscape(
                                            date(
                                                'd M Y',
                                                strtotime(
                                                    $application['applied_at']
                                                )
                                            )
                                        );
                                    } else {
                                        echo '—';
                                    }
                                    ?>
                                </td>

                                <td>
                                    <span
                                        class="application-status <?= studentDashboardStatusClass(
                                            (string) $application['status']
                                        ) ?>"
                                    >
                                        <?= studentDashboardEscape(
                                            $application['status']
                                        ) ?>
                                    </span>
                                </td>
                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </section>

    </main>

    <footer class="site-footer">
        <p>Internship Portal · Student Dashboard</p>
    </footer>

</div>

</body>
</html>