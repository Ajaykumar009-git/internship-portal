
<?php


use PHPMailer\PHPMailer\PHPMailer;

require_once __DIR__ . '/../vendor/autoload.php';

/**
 * Read an environment variable and return a trimmed string.
 */
function mailConfigValue(string $name, string $default = ''): string
{
    $value = getenv($name);

    if ($value === false) {
        return $default;
    }

    return trim($value);
}

/**
 * Send a password-reset OTP email.
 *
 * @return bool True when the SMTP server accepts the message.
 */
function sendOTPEmail(string $toEmail, string $otp): bool
{
    /*
    |--------------------------------------------------------------------------
    | Validate input
    |--------------------------------------------------------------------------
    */
    if (
        !filter_var($toEmail, FILTER_VALIDATE_EMAIL) ||
        !preg_match('/^\d{6}$/', $otp)
    ) {
        error_log('OTP email: Invalid recipient address or OTP format.');
        return false;
    }

    /*
    |--------------------------------------------------------------------------
    | Read SMTP configuration
    |--------------------------------------------------------------------------
    | Configure these variables in your PHP runtime environment.
    | Never put real passwords directly in this source file.
    */
    $smtpHost = mailConfigValue(
        'SMTP_HOST',
        'smtp.gmail.com'
    );

    $smtpPort = (int) mailConfigValue(
        'SMTP_PORT',
        '587'
    );

    $smtpUsername = mailConfigValue('SMTP_USERNAME');
    $smtpPassword = mailConfigValue('SMTP_PASSWORD');

    $senderEmail = mailConfigValue(
        'SMTP_FROM_EMAIL',
        $smtpUsername
    );

    $senderName = mailConfigValue(
        'SMTP_FROM_NAME',
        'College Internship Portal'
    );

    $encryption = strtolower(
        mailConfigValue('SMTP_ENCRYPTION', 'tls')
    );

    /*
    |--------------------------------------------------------------------------
    | Check required settings
    |--------------------------------------------------------------------------
    */
    if (
        $smtpHost === '' ||
        $smtpPort < 1 ||
        $smtpPort > 65535 ||
        $smtpUsername === '' ||
        $smtpPassword === '' ||
        !filter_var($senderEmail, FILTER_VALIDATE_EMAIL)
    ) {
        error_log(
            'OTP email: SMTP configuration is incomplete or invalid. ' .
            'Check SMTP_HOST, SMTP_PORT, SMTP_USERNAME, SMTP_PASSWORD, ' .
            'and SMTP_FROM_EMAIL.'
        );

        return false;
    }

    /*
    |--------------------------------------------------------------------------
    | Configure PHPMailer
    |--------------------------------------------------------------------------
    */
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();

        $mail->Host = $smtpHost;
        $mail->SMTPAuth = true;

        $mail->Username = $smtpUsername;
        $mail->Password = $smtpPassword;

        $mail->Port = $smtpPort;
        $mail->Timeout = 20;
        $mail->CharSet = 'UTF-8';

        /*
        | Gmail submission usually uses STARTTLS on port 587.
        | Port 465 normally uses implicit TLS (SMTPS).
        */
        if ($encryption === 'tls') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        } elseif ($encryption === 'ssl') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        } else {
            error_log(
                'OTP email: SMTP_ENCRYPTION must be tls or ssl.'
            );

            return false;
        }

        /*
        | Keep diagnostic output out of the web page.
        | PHPMailer errors are recorded in the server error log.
        */
        $mail->SMTPDebug = 0;

        $mail->setFrom(
            $senderEmail,
            $senderName
        );

        $mail->addAddress($toEmail);

        /*
        |--------------------------------------------------------------------------
        | Compose email
        |--------------------------------------------------------------------------
        */
        $safeOtp = htmlspecialchars(
            $otp,
            ENT_QUOTES,
            'UTF-8'
        );

        $safeSenderName = htmlspecialchars(
            $senderName,
            ENT_QUOTES,
            'UTF-8'
        );

        $mail->isHTML(true);

        $mail->Subject =
            'Your Internship Portal Password Reset OTP';

        $mail->Body = '
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Password Reset OTP</title>
        </head>
        <body style="
            margin:0;
            padding:0;
            background:#050914;
            font-family:Arial,sans-serif;
            color:#f5f8ff;
        ">
            <div style="
                max-width:520px;
                margin:30px auto;
                padding:28px;
                background:#0e1930;
                border:1px solid #2762a5;
                border-radius:18px;
            ">
                <h2 style="
                    margin-top:0;
                    color:#8bdcff;
                    text-align:center;
                ">
                    ' . $safeSenderName . '
                </h2>

                <p style="
                    color:#c4d3eb;
                    line-height:1.8;
                ">
                    You requested a password reset.
                    Use the verification code below to continue.
                </p>

                <div style="
                    margin:25px 0;
                    padding:20px 12px;
                    background:#071126;
                    border:1px solid #365e9e;
                    border-radius:12px;
                    color:#ffffff;
                    text-align:center;
                    font-size:32px;
                    font-weight:bold;
                    letter-spacing:9px;
                ">
                    ' . $safeOtp . '
                </div>

                <p style="
                    color:#aebed8;
                    line-height:1.8;
                ">
                    This code expires in 10 minutes.
                    Do not share it with anyone.
                </p>

                <p style="
                    color:#879bb9;
                    font-size:12px;
                    line-height:1.7;
                ">
                    If you did not request this password reset,
                    you can ignore this email.
                </p>
            </div>
        </body>
        </html>';

        $mail->AltBody =
            "Your College Internship Portal password reset OTP is: " .
            $otp .
            "\n\nThis code expires in 10 minutes. " .
            "Do not share it with anyone.";

        /*
        |--------------------------------------------------------------------------
        | Send
        |--------------------------------------------------------------------------
        */
        $sent = $mail->send();

        if (!$sent) {
            error_log(
                'OTP email: PHPMailer did not confirm sending. ' .
                $mail->ErrorInfo
            );

            return false;
        }

        return true;

    } catch (\Throwable $exception) {
        error_log(
            'OTP email failure: ' .
            $exception->getMessage() .
            ' | PHPMailer: ' .
            $mail->ErrorInfo
        );

        return false;
    }
}
