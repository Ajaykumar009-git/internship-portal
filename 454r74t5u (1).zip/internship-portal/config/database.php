<?php


$host = 'db01.dbhost.dev';
$port = 5051;

$username = 'user_454r6ztc8';
$password = 'p454r6ztc8';
$dbname = 'db_454r6ztc8';

$dsn = "mysql:host={$host};port={$port};dbname={$dbname};charset=utf8mb4";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {

    $pdo = new PDO(
        $dsn,
        $username,
        $password,
        $options
    );

} catch (PDOException $e) {

    error_log(
        'Database connection failed: '
        . $e->getMessage()
    );

    die(
        'Database connection failed. Please check the database configuration.'
    );
}