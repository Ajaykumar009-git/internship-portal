
<?php

session_start();

require_once __DIR__ . '/config/database.php';

/*
|--------------------------------------------------------------------------
| HTML escaping
|--------------------------------------------------------------------------
*/
function resetPasswordEscape(mixed $value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

/*
|--------------------------------------------------------------------------
| Require a verified OTP
|--------------------------------------------------------------------------
*/
if (
    empty($_SESSION['otp_verified']) ||
    empty($_SESSION['reset_user_id']) ||
    empty($_SESSION['reset_id'])
) {
    header('Location: forgot_password.php');
    exit;
}

$userId = (int) $_SESSION['reset_user_id'];
$resetId = (int) $_SESSION['reset_id'];

/*
|--------------------------------------------------------------------------
| CSRF token
|--------------------------------------------------------------------------
*/
if (empty($_SESSION['reset_password_csrf'])) {
    $_SESSION['reset_password_csrf'] = bin2hex(
        random_bytes(32)
    );
}

$error = '';
$success = false;

/*
|--------------------------------------------------------------------------
| Process password reset
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedToken = $_POST['csrf_token'] ?? '';

    $password = (string) ($_POST['password'] ?? '');

    $confirmPassword = (string) (
        $_POST['confirm_password'] ?? ''
    );

    if (
        !is_string($postedToken) ||
        !isset($_SESSION['reset_password_csrf']) ||
        !hash_equals(
            $_SESSION['reset_password_csrf'],
            $postedToken
        )
    ) {
        $error =
            'Your session expired. Refresh the page and try again.';

    } elseif (
        strlen($password) < 8 ||
        strlen($password) > 72
    ) {
        $error =
            'Your password must contain between 8 and 72 characters.';

    } elseif (
        !preg_match('/[A-Z]/', $password) ||
        !preg_match('/[a-z]/', $password) ||
        !preg_match('/[0-9]/', $password)
    ) {
        $error =
            'Include at least one uppercase letter, one lowercase letter, and one number.';

    } elseif ($password !== $confirmPassword) {
        $error = 'The passwords do not match.';

    } else {
        try {
            /*
            |--------------------------------------------------------------------------
            | Verify the reset record is valid
            |--------------------------------------------------------------------------
            | The OTP must have been verified, must not be expired,
            | and must belong to the current user and reset session.
            */
            $pdo->beginTransaction();

            $check = $pdo->prepare(
                'SELECT id
                 FROM password_resets
                 WHERE id = :reset_id
                   AND user_id = :user_id
                   AND verified = 1
                   AND expires_at > NOW()
                 LIMIT 1
                 FOR UPDATE'
            );

            $check->execute([
                'reset_id' => $resetId,
                'user_id' => $userId
            ]);

            $resetRecord = $check->fetch(PDO::FETCH_ASSOC);

            if (!$resetRecord) {
                $pdo->rollBack();

                unset(
                    $_SESSION['otp_verified'],
                    $_SESSION['reset_id'],
                    $_SESSION['reset_user_id'],
                    $_SESSION['reset_email'],
                    $_SESSION['reset_password_csrf']
                );

                $error =
                    'Your verified OTP has expired or is no longer valid. Please request a new OTP.';

            } else {
                /*
                |--------------------------------------------------------------------------
                | Hash and save the new password
                |--------------------------------------------------------------------------
                */
                $passwordHash = password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );

                if ($passwordHash === false) {
                    throw new RuntimeException(
                        'Password hashing failed.'
                    );
                }

                $update = $pdo->prepare(
                    'UPDATE users
                     SET password = :password
                     WHERE id = :user_id'
                );

                $update->execute([
                    'password' => $passwordHash,
                    'user_id' => $userId
                ]);

                if ($update->rowCount() !== 1) {
                    /*
                    | rowCount may be zero if the new hash happens
                    | to equal the existing password hash, so verify
                    | that the account still exists before failing.
                    */
                    $accountCheck = $pdo->prepare(
                        'SELECT id
                         FROM users
                         WHERE id = ?
                         LIMIT 1'
                    );

                    $accountCheck->execute([$userId]);

                    if (!$accountCheck->fetchColumn()) {
                        throw new RuntimeException(
                            'The account no longer exists.'
                        );
                    }
                }

                /*
                |--------------------------------------------------------------------------
                | Invalidate the used OTP
                |--------------------------------------------------------------------------
                */
                $delete = $pdo->prepare(
                    'DELETE FROM password_resets
                     WHERE id = :reset_id
                       AND user_id = :user_id'
                );

                $delete->execute([
                    'reset_id' => $resetId,
                    'user_id' => $userId
                ]);

                $pdo->commit();

                /*
                |--------------------------------------------------------------------------
                | Clear password-reset session data
                |--------------------------------------------------------------------------
                */
                unset(
                    $_SESSION['otp_verified'],
                    $_SESSION['reset_id'],
                    $_SESSION['reset_user_id'],
                    $_SESSION['reset_email'],
                    $_SESSION['reset_password_csrf'],
                    $_SESSION['otp_failed_attempts'],
                    $_SESSION['otp_attempt_reset_id']
                );

                session_regenerate_id(true);

                $success = true;
            }

        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log(
                'Password reset error: ' .
                $exception->getMessage()
            );

            $error =
                'We could not reset your password. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <meta name="theme-color" content="#070b14">

    <title>Reset Password | Internship Portal</title>

    <link
        rel="stylesheet"
        href="css/style.css?v=20261010"
    >
    <link rel="stylesheet" href="css/neon-glass.css?v=4">

    <style>
        body.reset-page {
            min-height: 100vh;
            margin: 0;
            color: #f5f8ff;

            background:
                radial-gradient(
                    ellipse at 12% 12%,
                    rgba(30, 125, 255, 0.18),
                    transparent 38%
                ),
                radial-gradient(
                    ellipse at 88% 88%,
                    rgba(255, 49, 151, 0.12),
                    transparent 36%
                ),
                #050914;
        }

        .reset-wrapper {
            min-height: 100vh;
            display: grid;
            place-items: center;
            box-sizing: border-box;
            padding: 24px 16px;
        }

        .reset-card {
            position: relative;
            overflow: hidden;

            width: min(100%, 460px);
            box-sizing: border-box;
            padding: 32px;

            border: 1px solid rgba(66, 156, 255, 0.38);
            border-radius: 22px;

            background: linear-gradient(
                145deg,
                rgba(15, 27, 52, 0.97),
                rgba(7, 11, 25, 0.98)
            );

            box-shadow:
                0 0 35px rgba(0, 100, 255, 0.10),
                0 0 70px rgba(255, 35, 120, 0.06),
                0 24px 75px rgba(0, 0, 0, 0.35);
        }

        .reset-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;

            background: linear-gradient(
                90deg,
                #2b8cff,
                #7655ff,
                #ff398a
            );
        }

        .reset-brand {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-bottom: 28px;

            color: #f5f8ff;
            font-weight: 850;
            text-decoration: none;
        }

        .reset-brand-mark {
            display: grid;
            place-items: center;
            width: 42px;
            height: 42px;
            border-radius: 12px;

            color: #fff;
            background: linear-gradient(
                135deg,
                #218fff,
                #7555ff,
                #ff398a
            );
        }

        .reset-heading {
            margin: 0;

            color: #f5f8ff;
            text-align: center;
            font-size: clamp(28px, 5vw, 36px);
            font-weight: 900;
            letter-spacing: -1px;
        }

        .reset-description {
            margin: 14px 0 25px;

            color: #aebed8;
            text-align: center;
            font-size: 13px;
            line-height: 1.8;
        }

        .reset-message {
            margin-bottom: 20px;
            padding: 13px 15px;

            border-radius: 11px;
            font-size: 13px;
            line-height: 1.7;
            overflow-wrap: anywhere;
        }

        .reset-message.error {
            color: #ffb1c0;
            background: rgba(255, 40, 80, 0.08);
            border: 1px solid rgba(255, 55, 90, 0.30);
        }

        .reset-message.success {
            color: #77f4bd;
            background: rgba(72, 240, 179, 0.08);
            border: 1px solid rgba(72, 240, 179, 0.28);
        }

        .reset-field {
            margin-bottom: 20px;
        }

        .reset-field label {
            display: block;
            margin-bottom: 9px;

            color: #e1eaff;
            font-size: 13px;
            font-weight: 750;
        }

        .reset-password-wrap {
            position: relative;
        }

        .reset-password-wrap input {
            display: block;
            width: 100%;
            min-height: 52px;
            box-sizing: border-box;
            padding: 13px 78px 13px 14px;

            color: #fff;
            background: rgba(7, 15, 33, 0.94);

            border: 1px solid rgba(95, 140, 195, 0.30);
            border-radius: 11px;
            outline: none;

            font: inherit;
            font-size: 14px;

            transition:
                border-color 0.2s ease,
                box-shadow 0.2s ease;
        }

        .reset-password-wrap input:focus {
            border-color: rgba(66, 186, 255, 0.88);
            box-shadow: 0 0 0 3px rgba(45, 137, 255, 0.10);
        }

        .reset-password-wrap input::placeholder {
            color: rgba(190, 201, 225, 0.48);
        }

        .password-toggle {
            position: absolute;
            top: 50%;
            right: 9px;
            transform: translateY(-50%);

            min-width: 50px;
            padding: 8px 9px;

            color: #8bdcff;
            background: rgba(66, 186, 255, 0.08);

            border: 1px solid rgba(66, 186, 255, 0.19);
            border-radius: 8px;

            font-size: 11px;
            font-weight: 850;

            cursor: pointer;

            transition:
                color 0.2s ease,
                background 0.2s ease,
                border-color 0.2s ease;
        }

        .password-toggle:hover {
            color: #fff;
            background: rgba(66, 186, 255, 0.18);
            border-color: rgba(66, 186, 255, 0.55);
        }

        .reset-hint {
            display: block;
            margin-top: 8px;

            color: #879bb9;
            font-size: 11px;
            line-height: 1.7;
        }

        .reset-submit {
            width: 100%;
            min-height: 52px;
            padding: 13px 18px;

            color: #fff;
            font: inherit;
            font-weight: 850;

            border: 1px solid rgba(126, 194, 255, 0.30);
            border-radius: 12px;

            background: linear-gradient(
                100deg,
                #176fff,
                #6550ff,
                #e82f82
            );

            cursor: pointer;

            transition:
                transform 0.2s ease,
                box-shadow 0.2s ease;
        }

        .reset-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(40, 100, 255, 0.23);
        }

        .reset-submit:active {
            transform: scale(0.98);
        }

        .reset-links {
            margin-top: 23px;
            text-align: center;
        }

        .reset-links a {
            color: #8bdcff;
            font-size: 13px;
            font-weight: 750;
            text-decoration: none;
        }

        .reset-links a:hover {
            color: #ff86c2;
        }

        .reset-links p {
            margin: 12px 0 0;
            color: #aebed8;
            font-size: 12px;
        }

        a:focus-visible,
        button:focus-visible,
        input:focus-visible {
            outline: 2px solid #8bdcff;
            outline-offset: 3px;
        }

        @media (max-width: 500px) {
            .reset-card {
                padding: 25px 19px;
                border-radius: 18px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            *,
            *::before,
            *::after {
                animation-duration: 0.01ms !important;
                transition-duration: 0.01ms !important;
            }
        }
    </style>
</head>

<body class="reset-page">

<main class="reset-wrapper">

    <section class="reset-card">

        <a href="index.php" class="reset-brand">
            <span class="reset-brand-mark">IP</span>
            <span>INTERNSHIP PORTAL</span>
        </a>

        <?php if ($success): ?>

            <h1 class="reset-heading">
                Password Updated
            </h1>

            <div class="reset-message success" role="status">
                Your password has been changed successfully.
                You can now sign in using your new password.
            </div>

            <a
                href="login.php"
                class="reset-submit"
                style="
                    display:block;
                    box-sizing:border-box;
                    text-align:center;
                    text-decoration:none;
                "
            >
                Continue to Login
            </a>

        <?php else: ?>

            <h1 class="reset-heading">
                New Password
            </h1>

            <p class="reset-description">
                Create a new password for your account.
            </p>

            <?php if ($error !== ''): ?>

                <div class="reset-message error" role="alert">
                    <?= resetPasswordEscape($error) ?>
                </div>

            <?php endif; ?>

            <form
                method="POST"
                action="reset_password.php"
                id="resetPasswordForm"
            >

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= resetPasswordEscape(
                        $_SESSION['reset_password_csrf']
                    ) ?>"
                >

                <div class="reset-field">

                    <label for="password">
                        New Password
                    </label>

                    <div class="reset-password-wrap">

                        <input
                            type="password"
                            id="password"
                            name="password"
                            placeholder="Enter your new password"
                            minlength="8"
                            maxlength="72"
                            autocomplete="new-password"
                            required
                        >

                        <button
                            type="button"
                            class="password-toggle"
                            data-password-toggle="password"
                            aria-controls="password"
                            aria-label="Show password"
                        >
                            Show
                        </button>

                    </div>

                    <small class="reset-hint">
                        Use 8–72 characters, including uppercase and
                        lowercase letters and at least one number.
                    </small>

                </div>

                <div class="reset-field">

                    <label for="confirm_password">
                        Confirm New Password
                    </label>

                    <div class="reset-password-wrap">

                        <input
                            type="password"
                            id="confirm_password"
                            name="confirm_password"
                            placeholder="Enter the new password again"
                            minlength="8"
                            maxlength="72"
                            autocomplete="new-password"
                            required
                        >

                        <button
                            type="button"
                            class="password-toggle"
                            data-password-toggle="confirm_password"
                            aria-controls="confirm_password"
                            aria-label="Show confirmation password"
                        >
                            Show
                        </button>

                    </div>

                </div>

                <button
                    type="submit"
                    class="reset-submit"
                >
                    Reset Password
                </button>

            </form>

            <div class="reset-links">
                <p>
                    <a href="login.php">Back to Login</a>
                </p>
            </div>

        <?php endif; ?>

    </section>

</main>

<script src="js/validation.js?v=4" defer></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('resetPasswordForm');

    if (!form) {
        return;
    }

    const password = document.getElementById('password');
    const confirmPassword = document.getElementById('confirm_password');

    form.addEventListener('submit', function (event) {
        if (password.value !== confirmPassword.value) {
            event.preventDefault();

            confirmPassword.setCustomValidity(
                'The passwords do not match.'
            );

            confirmPassword.reportValidity();
            confirmPassword.focus();
        } else {
            confirmPassword.setCustomValidity('');
        }
    });

    confirmPassword.addEventListener('input', function () {
        confirmPassword.setCustomValidity('');
    });
});
</script>

</body>
</html>
