<?php

session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'company') {
    header('Location: ../login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];

$message = '';
$messageType = '';

/*
|--------------------------------------------------------------------------
| Get company ID
|--------------------------------------------------------------------------
*/

try {

    $stmt = $pdo->prepare(
        "SELECT id, company_name
         FROM companies
         WHERE user_id = ?
         LIMIT 1"
    );

    $stmt->execute([$userId]);

    $company = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$company) {
        header('Location: dashboard.php');
        exit;
    }

    $companyId = (int) $company['id'];

} catch (PDOException $e) {

    error_log(
        'Company lookup error: ' . $e->getMessage()
    );

    die('Unable to load company information.');
}


/*
|--------------------------------------------------------------------------
| Add internship
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $skillsRequired = trim($_POST['skills_required'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $stipend = trim($_POST['stipend'] ?? '');
    $duration = trim($_POST['duration'] ?? '');
    $deadline = trim($_POST['deadline'] ?? '');

    /*
    |--------------------------------------------------------------------------
    | Validation
    |--------------------------------------------------------------------------
    */

    if (
        $title === '' ||
        $description === '' ||
        $location === '' ||
        $duration === '' ||
        $deadline === ''
    ) {

        $message =
            'Please fill in all required fields.';

        $messageType = 'error';

    } elseif (strlen($title) > 200) {

        $message =
            'Internship title must not exceed 200 characters.';

        $messageType = 'error';

    } elseif (strlen($location) > 150) {

        $message =
            'Location must not exceed 150 characters.';

        $messageType = 'error';

    } elseif (strlen($duration) > 100) {

        $message =
            'Duration must not exceed 100 characters.';

        $messageType = 'error';

    } elseif (!is_numeric($stipend) || (float)$stipend < 0) {

        $message =
            'Please enter a valid stipend amount.';

        $messageType = 'error';

    } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $deadline)) {

        $message =
            'Please enter a valid deadline.';

        $messageType = 'error';

    } else {

        try {

            /*
            |--------------------------------------------------------------------------
            | Make sure deadline is a valid date
            |--------------------------------------------------------------------------
            */

            $deadlineDate = DateTime::createFromFormat(
                'Y-m-d',
                $deadline
            );

            $today = new DateTime('today');

            if (
                !$deadlineDate ||
                $deadlineDate->format('Y-m-d') !== $deadline
            ) {

                $message =
                    'Please enter a valid deadline date.';

                $messageType = 'error';

            } elseif ($deadlineDate < $today) {

                $message =
                    'Deadline cannot be in the past.';

                $messageType = 'error';

            } else {

                /*
                |--------------------------------------------------------------------------
                | Insert internship
                |--------------------------------------------------------------------------
                */

                $stmt = $pdo->prepare(
                    "INSERT INTO internships
                    (
                        company_id,
                        title,
                        description,
                        skills_required,
                        location,
                        stipend,
                        duration,
                        deadline
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
                );

                $stmt->execute([
                    $companyId,
                    $title,
                    $description,
                    $skillsRequired !== ''
                        ? $skillsRequired
                        : null,
                    $location,
                    (float)$stipend,
                    $duration,
                    $deadline
                ]);

                $message =
                    'Internship posted successfully.';

                $messageType = 'success';

                /*
                |--------------------------------------------------------------------------
                | Clear form
                |--------------------------------------------------------------------------
                */

                $title = '';
                $description = '';
                $skillsRequired = '';
                $location = '';
                $stipend = '';
                $duration = '';
                $deadline = '';
            }

        } catch (PDOException $e) {

            error_log(
                'Add internship error: ' . $e->getMessage()
            );

            $message =
                'Unable to create the internship. Please try again.';

            $messageType = 'error';
        }
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Add Internship | Internship Portal
    </title>

    <link
        rel="stylesheet"
        href="../css/style.css"
    >
    <link rel="stylesheet" href="../css/neon-glass.css?v=4">

</head>

<body>

<div class="dashboard-page">

    <!-- Navigation -->

    <nav class="dashboard-nav">

        <div class="nav-brand">
            Internship Portal
        </div>

        <div class="nav-links">

            <a href="../index.php">
                Home
            </a>

            <a href="dashboard.php">
                Dashboard
            </a>

            <a
                href="add_internship.php"
                class="active"
            >
                Add Internship
            </a>

            <a href="internships.php">
                My Internships
            </a>

            <a href="applicants.php">
                Applicants
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </div>

    </nav>


    <!-- Main -->

    <main class="dashboard-container">

        <section class="dashboard-header">

            <div>

                <span class="dashboard-label">
                    INTERNSHIP MANAGEMENT
                </span>

                <h1>
                    Add Internship
                </h1>

                <p>
                    Create a new internship opportunity.
                </p>

            </div>

            <a
                href="dashboard.php"
                class="btn btn-secondary"
            >
                Dashboard
            </a>

        </section>


        <!-- Form Card -->

        <section class="dashboard-card">

            <?php if ($message !== ''): ?>

                <div
                    class="alert
                    <?php echo $messageType === 'success'
                        ? 'alert-success'
                        : 'alert-error'; ?>"
                >
                    <?php
                    echo htmlspecialchars($message);
                    ?>
                </div>

            <?php endif; ?>


            <form
                method="POST"
                action=""
                class="portal-form"
            >

                <div class="form-grid">


                    <!-- Title -->

                    <div class="form-group full-width">

                        <label for="title">
                            Internship Title
                        </label>

                        <input
                            type="text"
                            id="title"
                            name="title"
                            maxlength="200"
                            placeholder="Example: Full Stack Web Development Intern"
                            value="<?php
                            echo htmlspecialchars(
                                $title ?? ''
                            );
                            ?>"
                            required
                        >

                    </div>


                    <!-- Location -->

                    <div class="form-group">

                        <label for="location">
                            Location
                        </label>

                        <input
                            type="text"
                            id="location"
                            name="location"
                            maxlength="150"
                            placeholder="Example: Chennai / Remote"
                            value="<?php
                            echo htmlspecialchars(
                                $location ?? ''
                            );
                            ?>"
                            required
                        >

                    </div>


                    <!-- Duration -->

                    <div class="form-group">

                        <label for="duration">
                            Duration
                        </label>

                        <input
                            type="text"
                            id="duration"
                            name="duration"
                            maxlength="100"
                            placeholder="Example: 3 Months"
                            value="<?php
                            echo htmlspecialchars(
                                $duration ?? ''
                            );
                            ?>"
                            required
                        >

                    </div>


                    <!-- Stipend -->

                    <div class="form-group">

                        <label for="stipend">
                            Stipend
                        </label>

                        <input
                            type="number"
                            id="stipend"
                            name="stipend"
                            min="0"
                            step="0.01"
                            placeholder="Example: 10000"
                            value="<?php
                            echo htmlspecialchars(
                                $stipend ?? ''
                            );
                            ?>"
                            required
                        >

                    </div>


                    <!-- Deadline -->

                    <div class="form-group">

                        <label for="deadline">
                            Application Deadline
                        </label>

                        <input
                            type="date"
                            id="deadline"
                            name="deadline"
                            min="<?php
                            echo date('Y-m-d');
                            ?>"
                            value="<?php
                            echo htmlspecialchars(
                                $deadline ?? ''
                            );
                            ?>"
                            required
                        >

                    </div>


                    <!-- Skills -->

                    <div class="form-group full-width">

                        <label for="skills_required">
                            Skills Required
                        </label>

                        <input
                            type="text"
                            id="skills_required"
                            name="skills_required"
                            maxlength="1000"
                            placeholder="PHP, MySQL, JavaScript, HTML, CSS"
                            value="<?php
                            echo htmlspecialchars(
                                $skillsRequired ?? ''
                            );
                            ?>"
                        >

                    </div>


                    <!-- Description -->

                    <div class="form-group full-width">

                        <label for="description">
                            Internship Description
                        </label>

                        <textarea
                            id="description"
                            name="description"
                            rows="6"
                            placeholder="Describe the internship, responsibilities and requirements..."
                            required
                        ><?php
                        echo htmlspecialchars(
                            $description ?? ''
                        );
                        ?></textarea>

                    </div>

                </div>


                <!-- Actions -->

                <div class="form-actions">

                    <a
                        href="dashboard.php"
                        class="btn btn-secondary"
                    >
                        Cancel
                    </a>

                    <button
                        type="submit"
                        class="btn btn-primary"
                    >
                        Publish Internship
                    </button>

                </div>

            </form>

        </section>

    </main>

</div>

<script src="../js/validation.js?v=4"></script>

</body>

</html>