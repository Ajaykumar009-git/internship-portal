<?php
session_start();

require_once __DIR__ . '/../config/database.php';

/* --------------------------------------------------------------------------
   Authentication
-------------------------------------------------------------------------- */
if (
    !isset($_SESSION['user_id']) ||
    ($_SESSION['role'] ?? '') !== 'company'
) {
    header('Location: ../login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$message = '';
$messageType = '';
$internships = [];

function companyInternshipEscape($value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

/* --------------------------------------------------------------------------
   CSRF token for delete requests
-------------------------------------------------------------------------- */
if (empty($_SESSION['delete_internship_csrf'])) {
    $_SESSION['delete_internship_csrf'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['delete_internship_csrf'];

/* --------------------------------------------------------------------------
   Get the company profile for the logged-in account
-------------------------------------------------------------------------- */
try {
    $stmt = $pdo->prepare(
        'SELECT id, company_name
         FROM companies
         WHERE user_id = ?
         LIMIT 1'
    );

    $stmt->execute([$userId]);
    $company = $stmt->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log('Company profile lookup error: ' . $e->getMessage());

    http_response_code(500);
    exit('Unable to load your company profile. Please try again later.');
}

if (!$company) {
    header('Location: dashboard.php');
    exit;
}

$companyId = (int) $company['id'];

/* --------------------------------------------------------------------------
   Delete an internship only if it belongs to this company and has no
   applications. This prevents application records from being removed.
-------------------------------------------------------------------------- */
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['delete_internship'])
) {
    $submittedToken = (string) ($_POST['csrf_token'] ?? '');

    $internshipId = filter_input(
        INPUT_POST,
        'internship_id',
        FILTER_VALIDATE_INT
    );

    if (
        $submittedToken === '' ||
        !hash_equals($csrfToken, $submittedToken)
    ) {
        $message = 'Your request could not be verified. Refresh the page and try again.';
        $messageType = 'error';

    } elseif (!$internshipId || $internshipId < 1) {
        $message = 'Invalid internship.';
        $messageType = 'error';

    } else {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare(
                'SELECT id
                 FROM internships
                 WHERE id = ?
                   AND company_id = ?
                 FOR UPDATE'
            );

            $stmt->execute([$internshipId, $companyId]);

            $ownedInternship = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$ownedInternship) {
                $pdo->rollBack();

                $message = 'Internship not found or access denied.';
                $messageType = 'error';

            } else {
                $stmt = $pdo->prepare(
                    'SELECT COUNT(*)
                     FROM applications
                     WHERE internship_id = ?'
                );

                $stmt->execute([$internshipId]);

                $applicationCount = (int) $stmt->fetchColumn();

                if ($applicationCount > 0) {
                    $pdo->rollBack();

                    $message = 'This internship has applications and cannot be deleted. Please review the applicants instead.';
                    $messageType = 'error';

                } else {
                    $stmt = $pdo->prepare(
                        'DELETE FROM internships
                         WHERE id = ?
                           AND company_id = ?'
                    );

                    $stmt->execute([
                        $internshipId,
                        $companyId
                    ]);

                    if ($stmt->rowCount() > 0) {
                        $pdo->commit();

                        $_SESSION['internship_flash'] = [
                            'message' => 'Internship deleted successfully.',
                            'type' => 'success',
                        ];

                        header('Location: internships.php');
                        exit;
                    }

                    $pdo->rollBack();

                    $message = 'Internship not found or access denied.';
                    $messageType = 'error';
                }
            }

        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            error_log('Delete internship error: ' . $e->getMessage());

            $message = 'Unable to delete the internship. Please try again.';
            $messageType = 'error';
        }
    }
}

/* --------------------------------------------------------------------------
   Display one-time success message after redirect
-------------------------------------------------------------------------- */
if (isset($_SESSION['internship_flash'])) {
    $flash = $_SESSION['internship_flash'];

    $message = (string) ($flash['message'] ?? '');
    $messageType = (string) ($flash['type'] ?? 'success');

    unset($_SESSION['internship_flash']);
}

/* --------------------------------------------------------------------------
   Get internships posted by this company
-------------------------------------------------------------------------- */
try {
    $stmt = $pdo->prepare(
        "SELECT
            i.id,
            i.title,
            i.description,
            i.skills_required,
            i.location,
            i.stipend,
            i.duration,
            i.deadline,
            i.created_at,
            (
                SELECT COUNT(*)
                FROM applications a
                WHERE a.internship_id = i.id
            ) AS application_count
         FROM internships i
         WHERE i.company_id = ?
         ORDER BY i.created_at DESC, i.id DESC"
    );

    $stmt->execute([$companyId]);
    $internships = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log('Internship listing error: ' . $e->getMessage());

    $message = 'Unable to load internships. Please try again later.';
    $messageType = 'error';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>My Internships | Internship Portal</title>

    <link
        rel="stylesheet"
        href="../css/style.css?v=<?php
            echo (int) @filemtime(__DIR__ . '/../css/style.css');
        ?>"
    >
    <link rel="stylesheet" href="../css/neon-glass.css?v=4">

    <!-- Page-specific styles for reliable Delete button appearance -->
    <style>
        .dashboard-page .table-wrapper .data-table td .ip-table-actions {
            display: flex !important;
            flex-direction: row !important;
            align-items: center !important;
            justify-content: flex-start !important;
            flex-wrap: nowrap !important;
            gap: 10px !important;
            min-width: 190px;
        }

        .dashboard-page .table-wrapper .data-table td .ip-table-actions > a,
        .dashboard-page .table-wrapper .data-table td .ip-table-actions > form {
            display: inline-flex !important;
            flex: 0 0 auto !important;
            align-items: center !important;
            margin: 0 !important;
            padding: 0 !important;
        }

        .dashboard-page .table-wrapper .data-table .ip-delete-button {
            appearance: none !important;
            -webkit-appearance: none !important;

            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;

            width: 88px !important;
            min-width: 88px !important;
            height: 42px !important;
            min-height: 42px !important;

            margin: 0 !important;
            padding: 0 14px !important;

            color: #ffe5ea !important;
            background: linear-gradient(
                135deg,
                #501727,
                #831d3b
            ) !important;

            border: 1px solid #ed5274 !important;
            border-radius: 10px !important;

            font-family: inherit !important;
            font-size: 13px !important;
            font-weight: 750 !important;
            line-height: 1.2 !important;

            white-space: nowrap !important;
            cursor: pointer !important;
            box-sizing: border-box !important;

            box-shadow: 0 4px 14px rgba(230, 45, 85, .16) !important;

            transition:
                background .22s ease,
                color .22s ease,
                border-color .22s ease,
                box-shadow .22s ease,
                transform .22s ease !important;
        }

        .dashboard-page .table-wrapper .data-table .ip-delete-button:hover:not(:disabled) {
            color: #fff !important;

            background: linear-gradient(
                135deg,
                #ff405f,
                #c9184a
            ) !important;

            border-color: #ff9aaa !important;

            box-shadow:
                0 0 10px rgba(255, 64, 95, .38),
                0 0 22px rgba(255, 64, 95, .22) !important;

            transform: translateY(-2px) !important;
        }

        .dashboard-page .table-wrapper .data-table .ip-delete-button:active:not(:disabled) {
            transform: scale(.96) !important;
        }

        .dashboard-page .table-wrapper .data-table .ip-delete-button:disabled {
            color: #a99aa0 !important;
            background: #27212a !important;
            border-color: #49404a !important;
            box-shadow: none !important;
            cursor: not-allowed !important;
            opacity: .65 !important;
            transform: none !important;
        }

        .dashboard-page .table-wrapper .data-table .ip-table-actions .btn-secondary {
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;

            width: 98px;
            min-width: 88px;
            height: 42px;

            margin: 0 !important;
            white-space: nowrap;
            box-sizing: border-box;
        }

        .dashboard-page .table-wrapper .data-table td.ip-action-cell,
        .dashboard-page .table-wrapper .data-table th.ip-action-heading {
            min-width: 215px;
            vertical-align: middle;
        }

        @media (max-width: 700px) {
            .dashboard-page .table-wrapper .data-table {
                min-width: 1050px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            .dashboard-page .table-wrapper .data-table .ip-delete-button {
                transition: none !important;
            }
        }
    </style>
</head>

<body>

<div class="dashboard-page">

    <!-- Navigation -->
    <nav class="dashboard-nav">

        <div class="nav-brand">
            Internship Portal
        </div>

        <div class="nav-links">

            <a href="../index.php">Home</a>

            <a href="dashboard.php">Dashboard</a>

            <a href="add_internship.php">Add Internship</a>

            <a href="internships.php" class="active">
                My Internships
            </a>

            <a href="applicants.php">Applicants</a>

            <a href="../logout.php">Logout</a>

        </div>

    </nav>


    <!-- Main content -->
    <main class="dashboard-container">

        <section class="dashboard-header">

            <div>

                <span class="dashboard-label">
                    INTERNSHIP MANAGEMENT
                </span>

                <h1>My Internships</h1>

                <p>
                    Manage your posted internship opportunities.
                </p>

            </div>

            <a
                href="add_internship.php"
                class="btn btn-primary"
            >
                Add Internship
            </a>

        </section>


        <!-- Feedback message -->
        <?php if ($message !== ''): ?>

            <div
                class="alert <?php
                    echo $messageType === 'success'
                        ? 'alert-success'
                        : 'alert-error';
                ?>"
                role="status"
            >
                <?php echo companyInternshipEscape($message); ?>
            </div>

        <?php endif; ?>


        <!-- Empty state -->
        <?php if (empty($internships)): ?>

            <section class="dashboard-card">

                <div class="empty-state">

                    <h2>No internships yet</h2>

                    <p>
                        Create your first internship opportunity.
                    </p>

                    <a
                        href="add_internship.php"
                        class="btn btn-primary"
                    >
                        Add Internship
                    </a>

                </div>

            </section>

        <?php else: ?>

            <!-- Internship table -->
            <section class="dashboard-card">

                <div class="card-header">

                    <h2>Posted Internships</h2>

                    <span>
                        <?php echo count($internships); ?> total
                    </span>

                </div>


                <div class="table-wrapper">

                    <table class="data-table">

                        <thead>
                            <tr>
                                <th>Internship</th>
                                <th>Location</th>
                                <th>Stipend</th>
                                <th>Duration</th>
                                <th>Deadline</th>
                                <th>Applications</th>
                                <th class="ip-action-heading">Action</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php foreach ($internships as $internship): ?>

                            <?php
                            $internshipId = (int) $internship['id'];

                            $applicationCount = (int) (
                                $internship['application_count'] ?? 0
                            );

                            $deadlineTime = !empty($internship['deadline'])
                                ? strtotime((string) $internship['deadline'])
                                : false;

                            $isExpired = (
                                $deadlineTime !== false &&
                                $deadlineTime < strtotime('today')
                            );

                            $deadlineDisplay = $deadlineTime !== false
                                ? date('d M Y', $deadlineTime)
                                : 'Not specified';

                            $rawStipend = trim(
                                (string) ($internship['stipend'] ?? '')
                            );

                            if (
                                $rawStipend !== '' &&
                                is_numeric($rawStipend)
                            ) {
                                $stipendAmount = (float) $rawStipend;

                                $stipendDisplay = $stipendAmount > 0
                                    ? '₹' . number_format($stipendAmount, 2)
                                    : 'Unpaid';
                            } else {
                                $stipendDisplay = $rawStipend !== ''
                                    ? $rawStipend
                                    : 'Unpaid';
                            }
                            ?>

                            <tr>

                                <!-- Internship title and skills -->
                                <td>

                                    <strong>
                                        <?php
                                        echo companyInternshipEscape(
                                            $internship['title']
                                        );
                                        ?>
                                    </strong>

                                    <?php if (!empty($internship['skills_required'])): ?>

                                        <small>
                                            <?php
                                            echo companyInternshipEscape(
                                                $internship['skills_required']
                                            );
                                            ?>
                                        </small>

                                    <?php elseif (!empty($internship['description'])): ?>

                                        <small>
                                            <?php
                                            $description = trim(
                                                (string) $internship['description']
                                            );

                                            if (function_exists('mb_strimwidth')) {
                                                $description = mb_strimwidth(
                                                    $description,
                                                    0,
                                                    85,
                                                    '…'
                                                );
                                            } else {
                                                $description = substr(
                                                    $description,
                                                    0,
                                                    85
                                                );
                                            }

                                            echo companyInternshipEscape(
                                                $description
                                            );
                                            ?>
                                        </small>

                                    <?php endif; ?>

                                </td>


                                <!-- Location -->
                                <td>
                                    <?php
                                    echo companyInternshipEscape(
                                        $internship['location'] ?? 'Not specified'
                                    );
                                    ?>
                                </td>


                                <!-- Stipend -->
                                <td>
                                    <?php
                                    echo companyInternshipEscape(
                                        $stipendDisplay
                                    );
                                    ?>
                                </td>


                                <!-- Duration -->
                                <td>
                                    <?php
                                    echo companyInternshipEscape(
                                        $internship['duration'] ?? 'Not specified'
                                    );
                                    ?>
                                </td>


                                <!-- Deadline -->
                                <td>

                                    <span class="<?php
                                        echo $isExpired
                                            ? 'status-rejected'
                                            : 'status-active';
                                    ?>">

                                        <?php
                                        echo companyInternshipEscape(
                                            $deadlineDisplay
                                        );
                                        ?>

                                    </span>

                                </td>


                                <!-- Number of applications -->
                                <td>

                                    <a
                                        href="applicants.php?internship_id=<?php
                                            echo $internshipId;
                                        ?>"
                                        class="application-count"
                                    >
                                        <?php echo $applicationCount; ?>
                                    </a>

                                </td>


                                <!-- Action buttons -->
                                <td class="ip-action-cell">

                                    <div class="table-actions ip-table-actions">

                                        <a
                                            href="applicants.php?internship_id=<?php
                                                echo $internshipId;
                                            ?>"
                                            class="btn btn-small btn-secondary"
                                        >Applicants</a>


                                        <form
                                            method="POST"
                                            action="internships.php"
                                            onsubmit="return confirm('Delete this internship? This action cannot be undone. Internships with applications cannot be deleted.');"
                                        >

                                            <input
                                                type="hidden"
                                                name="csrf_token"
                                                value="<?php
                                                    echo companyInternshipEscape(
                                                        $csrfToken
                                                    );
                                                ?>"
                                            >

                                            <input
                                                type="hidden"
                                                name="internship_id"
                                                value="<?php echo $internshipId; ?>"
                                            >

                                            <button
                                                type="submit"
                                                name="delete_internship"
                                                value="1"
                                                class="btn btn-small ip-delete-button"
                                                <?php if ($applicationCount > 0): ?>
                                                    disabled
                                                    title="This internship has applications and cannot be deleted."
                                                <?php endif; ?>
                                            >Delete</button>

                                        </form>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            </section>

        <?php endif; ?>

    </main>

</div>

<script src="../js/validation.js?v=4"></script>

</body>
</html>