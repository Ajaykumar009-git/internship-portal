
<?php
session_start();

require_once __DIR__ . '/../config/database.php';

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/
$sessionRole = strtolower(
    trim((string) ($_SESSION['role'] ?? ''))
);

if (
    !isset($_SESSION['user_id']) ||
    $sessionRole !== 'company'
) {
    header('Location: ../login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];

/*
|--------------------------------------------------------------------------
| CSRF token for logout
|--------------------------------------------------------------------------
*/
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/*
|--------------------------------------------------------------------------
| Company profile
|--------------------------------------------------------------------------
*/
$stmt = $pdo->prepare(
    "SELECT
        u.name AS contact_name,
        u.email,
        c.id AS company_id,
        c.company_name,
        c.company_description,
        c.website,
        c.location
     FROM users u
     INNER JOIN companies c ON c.user_id = u.id
     WHERE u.id = ?
     LIMIT 1"
);

$stmt->execute([$userId]);
$company = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$company) {
    http_response_code(404);
    exit(
        'Company profile not found. Please check your company registration.'
    );
}

$companyId = (int) $company['company_id'];

/*
|--------------------------------------------------------------------------
| Dashboard statistics
|--------------------------------------------------------------------------
*/
$stmt = $pdo->prepare(
    "SELECT COUNT(*)
     FROM internships
     WHERE company_id = ?"
);
$stmt->execute([$companyId]);
$totalInternships = (int) $stmt->fetchColumn();

$stmt = $pdo->prepare(
    "SELECT COUNT(*)
     FROM applications a
     INNER JOIN internships i ON i.id = a.internship_id
     WHERE i.company_id = ?"
);
$stmt->execute([$companyId]);
$totalApplications = (int) $stmt->fetchColumn();

$stmt = $pdo->prepare(
    "SELECT COUNT(*)
     FROM applications a
     INNER JOIN internships i ON i.id = a.internship_id
     WHERE i.company_id = ?
       AND a.status IN ('Applied', 'Under Review')"
);
$stmt->execute([$companyId]);
$pendingApplications = (int) $stmt->fetchColumn();

$stmt = $pdo->prepare(
    "SELECT COUNT(*)
     FROM applications a
     INNER JOIN internships i ON i.id = a.internship_id
     WHERE i.company_id = ?
       AND a.status = 'Shortlisted'"
);
$stmt->execute([$companyId]);
$shortlistedApplications = (int) $stmt->fetchColumn();

/*
|--------------------------------------------------------------------------
| Recent internships
|--------------------------------------------------------------------------
*/
$stmt = $pdo->prepare(
    "SELECT
        id,
        title,
        location,
        stipend,
        duration,
        deadline,
        created_at
     FROM internships
     WHERE company_id = ?
     ORDER BY created_at DESC, id DESC
     LIMIT 5"
);

$stmt->execute([$companyId]);
$recentInternships = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Recent applicants
|--------------------------------------------------------------------------
*/
$stmt = $pdo->prepare(
    "SELECT
        a.id AS application_id,
        a.status,
        a.applied_at,
        u.name AS student_name,
        u.email AS student_email,
        i.id AS internship_id,
        i.title AS internship_title
     FROM applications a
     INNER JOIN internships i
        ON i.id = a.internship_id
     INNER JOIN students s
        ON s.id = a.student_id
     INNER JOIN users u
        ON u.id = s.user_id
     WHERE i.company_id = ?
     ORDER BY a.applied_at DESC, a.id DESC
     LIMIT 5"
);

$stmt->execute([$companyId]);
$recentApplicants = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/
function companyDashboardEscape(mixed $value): string
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

function companyDashboardStatusClass(string $status): string
{
    return match ($status) {
        'Applied'      => 'status-applied',
        'Under Review' => 'status-review',
        'Shortlisted'  => 'status-shortlisted',
        'Interview'    => 'status-interview',
        'Selected'     => 'status-selected',
        'Rejected'     => 'status-rejected',
        default        => 'status-applied',
    };
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#070b14">

    <title>Company Dashboard | Internship Portal</title>

    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/neon-glass.css?v=4">
    <script src="../js/validation.js?v=4" defer></script>
</head>

<body>

<div class="dashboard-page">

    <!-- Navigation -->

    <header class="dashboard-nav">

        <a href="../index.php" class="nav-brand">
            <span class="brand-mark">IP</span>
            Internship Portal
        </a>

        <nav class="nav-links" aria-label="Company navigation">

            <a href="../index.php">Home</a>

            <a href="dashboard.php" class="active">
                Dashboard
            </a>

            <a href="add_internship.php">
                Post Internship
            </a>

            <a href="internships.php">
                My Internships
            </a>

            <a href="applicants.php">
                Applicants
            </a>

            <form
                action="../logout.php"
                method="POST"
                style="display:inline; margin:0;"
            >
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= companyDashboardEscape(
                        $_SESSION['csrf_token']
                    ) ?>"
                >

                <button
                    type="submit"
                    style="
                        padding:10px 14px;
                        border:1px solid transparent;
                        border-radius:10px;
                        background:transparent;
                        color:var(--text-soft);
                        font:inherit;
                        font-size:13px;
                        font-weight:650;
                        cursor:pointer;
                        transition:all .28s ease;
                    "
                >
                    Logout
                </button>
            </form>

        </nav>

    </header>

    <main class="dashboard-container">

        <!-- Welcome banner -->

        <section class="dashboard-header">

            <div>
                <span class="dashboard-label">
                    COMPANY CONTROL CENTER
                </span>

                <h1>
                    Welcome,
                    <?= companyDashboardEscape(
                        $company['company_name']
                    ) ?>
                </h1>

                <p>
                    Manage your internship listings, review applicants,
                    and track recruitment activity from one dashboard.
                </p>
            </div>

            <a href="add_internship.php" class="btn btn-primary">
                + Post Internship
            </a>

        </section>

        <!-- Statistics -->

        <section
            class="stats-grid"
            aria-label="Company statistics"
        >

            <article class="stat-card blue">
                <span class="stat-label">
                    TOTAL INTERNSHIPS
                </span>

                <strong class="stat-number">
                    <?= $totalInternships ?>
                </strong>
            </article>

            <article class="stat-card red">
                <span class="stat-label">
                    TOTAL APPLICATIONS
                </span>

                <strong class="stat-number">
                    <?= $totalApplications ?>
                </strong>
            </article>

            <article class="stat-card yellow">
                <span class="stat-label">
                    NEEDS REVIEW
                </span>

                <strong class="stat-number">
                    <?= $pendingApplications ?>
                </strong>
            </article>

            <article class="stat-card green">
                <span class="stat-label">
                    SHORTLISTED
                </span>

                <strong class="stat-number">
                    <?= $shortlistedApplications ?>
                </strong>
            </article>

        </section>

        <!-- Company profile and quick actions -->

        <section class="dashboard-grid">

            <article class="dashboard-card">

                <div class="card-header">
                    <h2>Company Information</h2>
                </div>

                <div class="profile-summary">

                    <div>
                        <span>Company</span>

                        <strong>
                            <?= companyDashboardEscape(
                                $company['company_name']
                            ) ?>
                        </strong>
                    </div>

                    <div>
                        <span>Contact Person</span>

                        <strong>
                            <?= companyDashboardEscape(
                                $company['contact_name']
                            ) ?>
                        </strong>
                    </div>

                    <div>
                        <span>Email</span>

                        <strong>
                            <?= companyDashboardEscape(
                                $company['email']
                            ) ?>
                        </strong>
                    </div>

                    <div>
                        <span>Location</span>

                        <strong>
                            <?= companyDashboardEscape(
                                $company['location'] ?: 'Not added'
                            ) ?>
                        </strong>
                    </div>

                    <div>
                        <span>Website</span>

                        <strong>
                            <?php if (!empty($company['website'])): ?>
                                <?= companyDashboardEscape(
                                    $company['website']
                                ) ?>
                            <?php else: ?>
                                Not added
                            <?php endif; ?>
                        </strong>
                    </div>

                </div>

            </article>

            <article class="dashboard-card">

                <div class="card-header">
                    <h2>Recruitment Actions</h2>
                </div>

                <p>
                    Manage internship openings and review the students
                    who have applied to your company.
                </p>

                <div
                    style="
                        display:grid;
                        gap:12px;
                        margin-top:20px;
                    "
                >
                    <a
                        href="add_internship.php"
                        class="btn btn-primary"
                    >
                        + Create Internship
                    </a>

                    <a
                        href="internships.php"
                        class="btn btn-secondary"
                    >
                        Manage Internships
                    </a>

                    <a
                        href="applicants.php"
                        class="btn btn-secondary"
                    >
                        Review Applicants
                    </a>
                </div>

            </article>

        </section>

        <!-- Recent internships -->

        <section class="dashboard-card" style="margin-bottom:20px;">

            <div class="card-header">
                <h2>Recent Internships</h2>

                <a href="internships.php" class="card-link">
                    View All
                </a>
            </div>

            <?php if (empty($recentInternships)): ?>

                <div class="empty-state">

                    <h3>No internships posted yet</h3>

                    <p>
                        Create your first internship opening to start
                        receiving applications from students.
                    </p>

                    <a
                        href="add_internship.php"
                        class="btn btn-primary"
                    >
                        Post Your First Internship
                    </a>

                </div>

            <?php else: ?>

                <div class="table-wrapper">

                    <table class="data-table">

                        <thead>
                            <tr>
                                <th>Internship</th>
                                <th>Location</th>
                                <th>Stipend</th>
                                <th>Duration</th>
                                <th>Deadline</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php foreach ($recentInternships as $internship): ?>

                            <tr>
                                <td>
                                    <strong>
                                        <?= companyDashboardEscape(
                                            $internship['title']
                                        ) ?>
                                    </strong>
                                </td>

                                <td>
                                    <?= companyDashboardEscape(
                                        $internship['location']
                                        ?: 'Not specified'
                                    ) ?>
                                </td>

                                <td>
                                    ₹<?= number_format(
                                        (float) $internship['stipend'],
                                        2
                                    ) ?>
                                </td>

                                <td>
                                    <?= companyDashboardEscape(
                                        $internship['duration']
                                        ?: 'Not specified'
                                    ) ?>
                                </td>

                                <td>
                                    <?= !empty($internship['deadline'])
                                        ? companyDashboardEscape(
                                            date(
                                                'd M Y',
                                                strtotime(
                                                    $internship['deadline']
                                                )
                                            )
                                        )
                                        : 'No deadline' ?>
                                </td>

                                <td>
                                    <a href="applicants.php">
                                        View Applicants
                                    </a>
                                </td>
                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </section>

        <!-- Recent applicants -->

        <section class="dashboard-card">

            <div class="card-header">
                <h2>Recent Applicants</h2>

                <a href="applicants.php" class="card-link">
                    View All Applicants
                </a>
            </div>

            <?php if (empty($recentApplicants)): ?>

                <div class="empty-state">

                    <h3>No applicants yet</h3>

                    <p>
                        Applicants will appear here when students
                        apply for your internship openings.
                    </p>

                </div>

            <?php else: ?>

                <div class="table-wrapper">

                    <table class="data-table">

                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Email</th>
                                <th>Internship</th>
                                <th>Applied On</th>
                                <th>Status</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php foreach ($recentApplicants as $applicant): ?>

                            <tr>
                                <td>
                                    <strong>
                                        <?= companyDashboardEscape(
                                            $applicant['student_name']
                                        ) ?>
                                    </strong>
                                </td>

                                <td>
                                    <?= companyDashboardEscape(
                                        $applicant['student_email']
                                    ) ?>
                                </td>

                                <td>
                                    <?= companyDashboardEscape(
                                        $applicant['internship_title']
                                    ) ?>
                                </td>

                                <td>
                                    <?= !empty($applicant['applied_at'])
                                        ? companyDashboardEscape(
                                            date(
                                                'd M Y',
                                                strtotime(
                                                    $applicant['applied_at']
                                                )
                                            )
                                        )
                                        : '—' ?>
                                </td>

                                <td>
                                    <span
                                        class="application-status <?= companyDashboardStatusClass(
                                            (string) $applicant['status']
                                        ) ?>"
                                    >
                                        <?= companyDashboardEscape(
                                            $applicant['status']
                                        ) ?>
                                    </span>
                                </td>
                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </section>

    </main>

    <footer class="site-footer">
        <p>Internship Portal · Company Dashboard</p>
    </footer>

</div>

</body>
</html>
