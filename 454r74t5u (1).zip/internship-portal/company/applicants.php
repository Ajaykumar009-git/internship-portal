<?php

session_start();

require_once __DIR__ . '/../config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'company') {
    header('Location: ../login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];

$message = '';
$messageType = '';

/*
|--------------------------------------------------------------------------
| Get company
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare(
    "SELECT id, company_name
     FROM companies
     WHERE user_id = ?
     LIMIT 1"
);

$stmt->execute([$userId]);

$company = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$company) {
    header('Location: dashboard.php');
    exit;
}

$companyId = (int) $company['id'];

/*
|--------------------------------------------------------------------------
| Update application status
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['update_status'])
) {

    $applicationId = (int) ($_POST['application_id'] ?? 0);
    $newStatus = trim($_POST['status'] ?? '');

    $allowedStatuses = [
        'Under Review',
        'Shortlisted',
        'Interview',
        'Selected',
        'Rejected'
    ];

    if ($applicationId <= 0) {

        $message = 'Invalid application.';
        $messageType = 'error';

    } elseif (!in_array($newStatus, $allowedStatuses, true)) {

        $message = 'Invalid application status.';
        $messageType = 'error';

    } else {

        try {

            /*
            |--------------------------------------------------------------------------
            | Update only applications belonging to this company
            |--------------------------------------------------------------------------
            */

            $stmt = $pdo->prepare(
                "UPDATE applications a

                 INNER JOIN internships i
                    ON a.internship_id = i.id

                 SET a.status = ?

                 WHERE a.id = ?
                   AND i.company_id = ?"
            );

            $stmt->execute([
                $newStatus,
                $applicationId,
                $companyId
            ]);

            if ($stmt->rowCount() > 0) {

                $message =
                    'Application status updated successfully.';

                $messageType = 'success';

            } else {

                $message =
                    'Application not found or status is already unchanged.';

                $messageType = 'error';
            }

        } catch (PDOException $e) {

            error_log(
                'Application status error: '
                . $e->getMessage()
            );

            $message =
                'Unable to update application status.';

            $messageType = 'error';
        }
    }
}

/*
|--------------------------------------------------------------------------
| Selected internship filter
|--------------------------------------------------------------------------
*/

$selectedInternship = (int) (
    $_GET['internship_id'] ?? 0
);

/*
|--------------------------------------------------------------------------
| Get company's internships for filter
|--------------------------------------------------------------------------
*/

$internships = [];

try {

    $stmt = $pdo->prepare(
        "SELECT
            id,
            title
         FROM internships
         WHERE company_id = ?
         ORDER BY created_at DESC"
    );

    $stmt->execute([
        $companyId
    ]);

    $internships = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    error_log(
        'Company internships filter error: '
        . $e->getMessage()
    );
}


/*
|--------------------------------------------------------------------------
| Get applicants
|--------------------------------------------------------------------------
*/

$applicants = [];

try {

    $sql = "
        SELECT
            a.id AS application_id,
            a.resume AS application_resume,
            a.status,
            a.applied_at,
            a.updated_at,

            i.id AS internship_id,
            i.title AS internship_title,

            s.id AS student_id,
            s.phone,
            s.college,
            s.course,
            s.skills,
            s.resume AS student_resume,

            u.name AS student_name,
            u.email AS student_email

        FROM applications a

        INNER JOIN internships i
            ON a.internship_id = i.id

        INNER JOIN students s
            ON a.student_id = s.id

        INNER JOIN users u
            ON s.user_id = u.id

        WHERE i.company_id = ?
    ";

    $params = [
        $companyId
    ];

    if ($selectedInternship > 0) {

        $sql .= "
            AND i.id = ?
        ";

        $params[] = $selectedInternship;
    }

    $sql .= "
        ORDER BY a.applied_at DESC
    ";

    $stmt = $pdo->prepare($sql);

    $stmt->execute($params);

    $applicants = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    error_log(
        'Applicants loading error: '
        . $e->getMessage()
    );

    $message =
        'Unable to load applicants.';

    $messageType = 'error';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Applicants | Internship Portal
    </title>

    <link
        rel="stylesheet"
        href="../css/style.css"
    >
    <link rel="stylesheet" href="../css/neon-glass.css?v=4">

</head>

<body>

<div class="dashboard-page">

    <!-- Navigation -->

    <nav class="dashboard-nav">

        <div class="nav-brand">
            Internship Portal
        </div>

        <div class="nav-links">

            <a href="../index.php">
                Home
            </a>

            <a href="dashboard.php">
                Dashboard
            </a>

            <a href="add_internship.php">
                Add Internship
            </a>

            <a href="internships.php">
                My Internships
            </a>

            <a
                href="applicants.php"
                class="active"
            >
                Applicants
            </a>

            <a href="../logout.php">
                Logout
            </a>

        </div>

    </nav>


    <!-- Main -->

    <main class="dashboard-container">

        <section class="dashboard-header">

            <div>

                <span class="dashboard-label">
                    APPLICATION MANAGEMENT
                </span>

                <h1>
                    Applicants
                </h1>

                <p>
                    Review applications and update candidate status.
                </p>

            </div>

            <a
                href="dashboard.php"
                class="btn btn-secondary"
            >
                Dashboard
            </a>

        </section>


        <?php if ($message !== ''): ?>

            <div
                class="alert
                <?php echo $messageType === 'success'
                    ? 'alert-success'
                    : 'alert-error'; ?>"
            >
                <?php
                echo htmlspecialchars($message);
                ?>
            </div>

        <?php endif; ?>


        <!-- Filter -->

        <section class="dashboard-card">

            <form
                method="GET"
                action=""
                class="filter-form"
            >

                <div class="form-group">

                    <label for="internship_id">
                        Filter by Internship
                    </label>

                    <select
                        id="internship_id"
                        name="internship_id"
                    >

                        <option value="0">
                            All Internships
                        </option>

                        <?php foreach (
                            $internships
                            as $internship
                        ): ?>

                            <option
                                value="<?php
                                echo (int)
                                    $internship['id'];
                                ?>"
                                <?php
                                echo
                                    $selectedInternship
                                    === (int)
                                    $internship['id']
                                    ? 'selected'
                                    : '';
                                ?>
                            >
                                <?php
                                echo htmlspecialchars(
                                    $internship['title']
                                );
                                ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <div class="filter-actions">

                    <button
                        type="submit"
                        class="btn btn-primary"
                    >
                        Apply Filter
                    </button>

                    <a
                        href="applicants.php"
                        class="btn btn-secondary"
                    >
                        Clear
                    </a>

                </div>

            </form>

        </section>


        <!-- Applicants -->

        <section class="dashboard-card">

            <div class="card-header">

                <h2>
                    Applications
                </h2>

                <span>
                    <?php echo count($applicants); ?>
                    applicant(s)
                </span>

            </div>


            <?php if (empty($applicants)): ?>

                <div class="empty-state">

                    <h3>
                        No applications found
                    </h3>

                    <p>
                        Applications will appear here when students apply.
                    </p>

                </div>

            <?php else: ?>

                <div class="table-wrapper">

                    <table class="data-table">

                        <thead>

                            <tr>

                                <th>
                                    Student
                                </th>

                                <th>
                                    Internship
                                </th>

                                <th>
                                    Education
                                </th>

                                <th>
                                    Skills
                                </th>

                                <th>
                                    Applied
                                </th>

                                <th>
                                    Status
                                </th>

                                <th>
                                    Action
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach (
                            $applicants
                            as $applicant
                        ): ?>

                            <tr>

                                <!-- Student -->

                                <td>

                                    <strong>
                                        <?php
                                        echo htmlspecialchars(
                                            $applicant[
                                                'student_name'
                                            ]
                                        );
                                        ?>
                                    </strong>

                                    <small>
                                        <?php
                                        echo htmlspecialchars(
                                            $applicant[
                                                'student_email'
                                            ]
                                        );
                                        ?>
                                    </small>

                                    <?php if (
                                        !empty(
                                            $applicant['phone']
                                        )
                                    ): ?>

                                        <small>
                                            <?php
                                            echo htmlspecialchars(
                                                $applicant['phone']
                                            );
                                            ?>
                                        </small>

                                    <?php endif; ?>

                                </td>


                                <!-- Internship -->

                                <td>

                                    <?php
                                    echo htmlspecialchars(
                                        $applicant[
                                            'internship_title'
                                        ]
                                    );
                                    ?>

                                </td>


                                <!-- Education -->

                                <td>

                                    <?php if (
                                        !empty(
                                            $applicant['college']
                                        )
                                    ): ?>

                                        <strong>
                                            <?php
                                            echo htmlspecialchars(
                                                $applicant[
                                                    'college'
                                                ]
                                            );
                                            ?>
                                        </strong>

                                    <?php endif; ?>

                                    <?php if (
                                        !empty(
                                            $applicant['course']
                                        )
                                    ): ?>

                                        <small>
                                            <?php
                                            echo htmlspecialchars(
                                                $applicant[
                                                    'course'
                                                ]
                                            );
                                            ?>
                                        </small>

                                    <?php endif; ?>

                                    <?php if (
                                        empty(
                                            $applicant['college']
                                        )
                                        &&
                                        empty(
                                            $applicant['course']
                                        )
                                    ): ?>

                                        <small>
                                            Not provided
                                        </small>

                                    <?php endif; ?>

                                </td>


                                <!-- Skills -->

                                <td>

                                    <?php
                                    echo htmlspecialchars(
                                        $applicant['skills']
                                            ?: 'Not provided'
                                    );
                                    ?>

                                </td>


                                <!-- Applied -->

                                <td>

                                    <?php
                                    echo htmlspecialchars(
                                        date(
                                            'd M Y',
                                            strtotime(
                                                $applicant[
                                                    'applied_at'
                                                ]
                                            )
                                        )
                                    );
                                    ?>

                                </td>


                                <!-- Status -->

                                <td>

                                    <span
                                        class="application-status status-<?php
                                        echo strtolower(
                                            str_replace(
                                                ' ',
                                                '-',
                                                $applicant['status']
                                            )
                                        );
                                        ?>"
                                    >
                                        <?php
                                        echo htmlspecialchars(
                                            $applicant['status']
                                        );
                                        ?>
                                    </span>

                                </td>


                                <!-- Action -->

                                <td>

                                    <form
                                        method="POST"
                                        action=""
                                        class="status-form"
                                    >

                                        <input
                                            type="hidden"
                                            name="application_id"
                                            value="<?php
                                            echo (int)
                                                $applicant[
                                                    'application_id'
                                                ];
                                            ?>"
                                        >

                                        <select
                                            name="status"
                                            aria-label="Application status"
                                        >

                                            <option
                                                value="Under Review"
                                                <?php
                                                echo $applicant[
                                                    'status'
                                                ] === 'Under Review'
                                                    ? 'selected'
                                                    : '';
                                                ?>
                                            >
                                                Under Review
                                            </option>

                                            <option
                                                value="Shortlisted"
                                                <?php
                                                echo $applicant[
                                                    'status'
                                                ] === 'Shortlisted'
                                                    ? 'selected'
                                                    : '';
                                                ?>
                                            >
                                                Shortlisted
                                            </option>

                                            <option
                                                value="Interview"
                                                <?php
                                                echo $applicant[
                                                    'status'
                                                ] === 'Interview'
                                                    ? 'selected'
                                                    : '';
                                                ?>
                                            >
                                                Interview
                                            </option>

                                            <option
                                                value="Selected"
                                                <?php
                                                echo $applicant[
                                                    'status'
                                                ] === 'Selected'
                                                    ? 'selected'
                                                    : '';
                                                ?>
                                            >
                                                Selected
                                            </option>

                                            <option
                                                value="Rejected"
                                                <?php
                                                echo $applicant[
                                                    'status'
                                                ] === 'Rejected'
                                                    ? 'selected'
                                                    : '';
                                                ?>
                                            >
                                                Rejected
                                            </option>

                                        </select>

                                        <button
                                            type="submit"
                                            name="update_status"
                                            class="btn btn-small btn-primary"
                                        >
                                            Update
                                        </button>

                                    </form>


                                    <?php

                                    $resumePath =
                                        $applicant[
                                            'application_resume'
                                        ]
                                        ?: $applicant[
                                            'student_resume'
                                        ];

                                    ?>

                                    <?php if (
                                        !empty($resumePath)
                                    ): ?>

                                        <a
                                            href="../uploads/resumes/<?php
                                            echo rawurlencode(
                                                basename(
                                                    $resumePath
                                                )
                                            );
                                            ?>"
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            class="resume-link"
                                        >
                                            View Resume
                                        </a>

                                    <?php endif; ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            <?php endif; ?>

        </section>

    </main>

</div>

<script src="../js/validation.js?v=4"></script>

</body>

</html>